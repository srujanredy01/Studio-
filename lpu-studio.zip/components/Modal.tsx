
import React from 'react';
import { XIcon } from './icons/ShareIcons';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
    maxWidthClass?: string;
}

export const Modal: React.FC<ModalProps> = ({ 
    isOpen, 
    onClose, 
    title,
    children,
    maxWidthClass = 'max-w-sm' 
}) => {
    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-slide-in-bottom" 
            onClick={onClose}
            aria-modal="true"
            role="dialog"
            aria-labelledby="modal-title"
        >
            <div 
                className={`glass-effect rounded-xl shadow-2xl w-full m-4 ${maxWidthClass}`} 
                onClick={(e) => e.stopPropagation()}
            >
                 <div className="flex justify-between items-center p-4 border-b border-white/20 dark:border-white/10">
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white" id="modal-title">{title}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-white rounded-full p-1 transition-colors" aria-label="Close modal">
                        <XIcon className="w-5 h-5" />
                    </button>
                </div>
                <div className="p-6">
                    {children}
                </div>
            </div>
        </div>
    );
};
