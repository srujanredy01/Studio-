
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { NewsArticle, ResourceFile, CodingTopic } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { XIcon } from './icons/ShareIcons';
import { TrashIcon } from './icons/ActionIcons';
import { trackEvent } from '../analytics';
import { useAppContext } from '../context/DataContext';

interface AISearchModalProps {
    isOpen: boolean;
    onClose: () => void;
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
    setSelectedCodingTopic: (topic: CodingTopic) => void;
}

const Spinner: React.FC = () => (
    <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
);

interface GroundingChunk {
    web?: {
        uri: string;
        title: string;
    };
}

const HISTORY_KEY = 'aiSearchHistory';
const MAX_HISTORY_ITEMS = 10;

export const AISearchModal: React.FC<AISearchModalProps> = ({
    isOpen,
    onClose,
    setCurrentView,
    setSelectedCodingTopic,
}) => {
    const { resources, codingTopics, newsArticles } = useAppContext();
    const [query, setQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [response, setResponse] = useState<string | null>(null);
    const [sources, setSources] = useState<GroundingChunk[]>([]);
    const [searchHistory, setSearchHistory] = useState<string[]>([]);
    const [groundedContent, setGroundedContent] = useState<{ type: 'resource' | 'coding'; id: string | number; name: string } | null>(null);
    
    // State for handling animations
    const [isClosing, setIsClosing] = useState(false);
    const [shouldRender, setShouldRender] = useState(isOpen);

    useEffect(() => {
        try {
            const storedHistory = window.localStorage.getItem(HISTORY_KEY);
            if (storedHistory) {
                setSearchHistory(JSON.parse(storedHistory));
            }
        } catch (e) {
            console.error("Failed to load search history:", e);
        }
    }, []);

    useEffect(() => {
        if (isOpen) {
            setShouldRender(true);
            setIsClosing(false);
        } else {
            setIsClosing(true);
            const timer = setTimeout(() => {
                setShouldRender(false);
                // Reset state after animation is complete
                setQuery('');
                setIsLoading(false);
                setError(null);
                setResponse(null);
                setSources([]);
                setGroundedContent(null);
            }, 300); // Must match animation duration
            return () => clearTimeout(timer);
        }
    }, [isOpen]);
    
    const renderMarkdown = (text: string): string => {
        // Process inline styles first
        let processedText = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
            .replace(/\*(.*?)\*/g, '<em>$1</em>'); // Italic

        // Split into blocks by one or more empty lines
        const blocks = processedText.split(/\n\s*\n/);
    
        const htmlBlocks = blocks.map(block => {
            const trimmedBlock = block.trim();
            if (!trimmedBlock) return '';
    
            const lines = trimmedBlock.split('\n');
            
            // Check for headings
            if (lines[0].startsWith('### ')) return `<h3>${lines[0].substring(4)}</h3>`;
            if (lines[0].startsWith('## ')) return `<h2>${lines[0].substring(3)}</h2>`;
            if (lines[0].startsWith('# ')) return `<h1>${lines[0].substring(2)}</h1>`;
            
            // Check if the block is an unordered list
            const isUnorderedList = lines.every(line => line.trim().startsWith('* ') || line.trim().startsWith('- '));
            if (isUnorderedList) {
                const listItems = lines.map(line => `<li>${line.trim().substring(2)}</li>`).join('');
                return `<ul>${listItems}</ul>`;
            }

            // Check if the block is an ordered list
            const isOrderedList = lines.every(line => line.trim().match(/^\d+\.\s/));
            if(isOrderedList) {
                const listItems = lines.map(line => `<li>${line.trim().replace(/^\d+\.\s/, '')}</li>`).join('');
                return `<ol>${listItems}</ol>`;
            }

            // Otherwise, it's a paragraph. Preserve internal line breaks.
            return `<p>${lines.join('<br />')}</p>`;
        });
    
        return htmlBlocks.join('');
    };


    const handleSearch = async (searchQuery: string = query) => {
        if (!searchQuery.trim()) return;

        setIsLoading(true);
        setError(null);
        setResponse(null);
        setSources([]);
        setGroundedContent(null);
        trackEvent('featureUse', 'ai_search', { query: searchQuery });
        
        const findRelevantContent = (sq: string) => {
            const q = sq.toLowerCase();
            const relevantResources = resources
                .filter(r => r.name.toLowerCase().includes(q))
                .map(r => ({ type: 'resource' as const, id: r.id, name: r.name }));

            const relevantCodingTopics = codingTopics
                .filter(t => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q))
                .map(t => ({ type: 'coding' as const, id: t.id, name: t.name }));

            return { relevantResources, relevantCodingTopics };
        };

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

            const resourceNames = resources.map(r => r.name).join(', ');
            const topicNames = codingTopics.map(t => t.name).join(', ');
            const newsTitles = newsArticles.map(n => n.title).join(', ');

            const { relevantResources, relevantCodingTopics } = findRelevantContent(searchQuery);

            const internalContentContext = [];
            if (relevantResources.length > 0) {
                internalContentContext.push(`- Relevant Resources found: ${relevantResources.map(r => `"${r.name}" (id: ${r.id})`).join(', ')}`);
            }
            if (relevantCodingTopics.length > 0) {
                internalContentContext.push(`- Relevant Coding Topics found: ${relevantCodingTopics.map(t => `"${t.name}" (id: ${t.id})`).join(', ')}`);
            }
            
            const systemInstruction = `
                You are Studio AI, a helpful assistant for the LPU Studio website.
                Your primary goal is to answer user questions based on the website's content provided below.
                If your answer is based on one of the "Relevant Internal Content" items, you MUST append a special tag at the VERY END of your response. The tag format is: [GROUNDED_ON:type:id:name]. For example: [GROUNDED_ON:resource:6:Data Structures & Algorithms].
                If the question is about recent events, news, or something that cannot be answered from the provided content, use your web search tool. When you use web search, you MUST cite your sources in the text.
                Keep your answers concise, friendly, and helpful. Format your response using basic Markdown.

                **LPU Studio Website Content:**
                - Available Resources: ${resourceNames}
                - Coding Topics Covered: ${topicNames}
                - Recent News Articles: ${newsTitles}

                **Potentially Relevant Internal Content for the current query:**
                ${internalContentContext.length > 0 ? internalContentContext.join('\n') : 'None found.'}
            `;

            const genAIResponse: GenerateContentResponse = await ai.models.generateContent({
                model: "gemini-2.5-pro",
                contents: searchQuery,
                config: {
                    systemInstruction,
                    tools: [{googleSearch: {}}],
                },
            });

            let responseText = genAIResponse.text;
            const groundingChunks = genAIResponse.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

            const groundingTagRegex = /\[GROUNDED_ON:(resource|coding):([^:]+):([^\]]+)\]$/;
            const match = responseText.match(groundingTagRegex);

            if (match) {
                responseText = responseText.replace(groundingTagRegex, '').trim();
                const [_, type, id, name] = match;
                const parsedId = type === 'resource' ? parseInt(id, 10) : id;
                setGroundedContent({ type: type as 'resource' | 'coding', id: parsedId, name });
            }
            
            setResponse(responseText);
            setSources(groundingChunks as GroundingChunk[]);
            
            setSearchHistory(prevHistory => {
                const newHistory = [searchQuery.trim(), ...prevHistory.filter(item => item.toLowerCase() !== searchQuery.trim().toLowerCase())].slice(0, MAX_HISTORY_ITEMS);
                try {
                    window.localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
                } catch (error) {
                    console.error("Failed to save search history:", error);
                }
                return newHistory;
            });

        } catch (e) {
            console.error("AI Search Error:", e);
            setError("Sorry, something went wrong while searching. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleHistoryClick = (historyQuery: string) => {
        setQuery(historyQuery);
        handleSearch(historyQuery);
    };

    const handleClearHistory = () => {
        setSearchHistory([]);
        try {
            window.localStorage.removeItem(HISTORY_KEY);
        } catch (error) {
            console.error("Failed to clear search history:", error);
        }
    };
    
    const handleGroundedLinkClick = (content: { type: 'resource' | 'coding'; id: string | number; name: string }) => {
        if (content.type === 'resource') {
            setCurrentView('resources');
        } else if (content.type === 'coding') {
            const topic = codingTopics.find(t => t.id === content.id);
            if (topic) {
                setSelectedCodingTopic(topic);
                setCurrentView('coding');
            }
        }
        onClose(); // Close the modal after clicking the link
    };

    if (!shouldRender) return null;

    return (
        <div className={`fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50 p-4 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`} onClick={onClose}>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes fade-out {
                    from { opacity: 1; }
                    to { opacity: 0; }
                }
                .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
                .animate-fade-out { animation: fade-out 0.3s ease-out forwards; }
                
                @keyframes scale-in {
                    from { opacity: 0; transform: scale(0.95); }
                    to { opacity: 1; transform: scale(1); }
                }
                @keyframes scale-out {
                    from { opacity: 1; transform: scale(1); }
                    to { opacity: 0; transform: scale(0.95); }
                }
                .content-animation {
                    animation-duration: 0.3s;
                    animation-timing-function: ease-out;
                    animation-fill-mode: forwards;
                }
                .animate-scale-in { animation-name: scale-in; }
                .animate-scale-out { animation-name: scale-out; }
            `}</style>
            <div className={`bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all content-animation ${isClosing ? 'animate-scale-out' : 'animate-scale-in'}`} onClick={(e) => e.stopPropagation()}>
                <div className="p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                            <SparklesIcon className="w-6 h-6 text-purple-500" />
                            Studio AI Search
                        </h3>
                        <button onClick={onClose} className="p-1 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors">
                            <XIcon className="w-6 h-6" />
                        </button>
                    </div>

                    <form onSubmit={(e) => { e.preventDefault(); handleSearch(); }}>
                        <div className="relative">
                            <input
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Ask about resources, coding topics, or recent news..."
                                className="w-full bg-gray-100 dark:bg-gray-700 rounded-full py-3 pl-5 pr-14 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                            />
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="absolute right-1.5 top-1/2 -translate-y-1/2 h-9 w-9 bg-purple-600 text-white rounded-full flex items-center justify-center hover:bg-purple-700 transition-colors disabled:bg-gray-400"
                                aria-label="Submit search"
                            >
                                {isLoading ? <Spinner /> : <SparklesIcon className="w-5 h-5" />}
                            </button>
                        </div>
                    </form>

                    <div className="mt-6 min-h-[250px] max-h-[50vh] overflow-y-auto pr-2">
                        {error && (
                            <div className="text-center text-red-500 bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
                                {error}
                            </div>
                        )}
                        {response && (
                            <div className="space-y-4">
                                <div
                                    className="prose prose-sm dark:prose-invert max-w-none text-gray-700 dark:text-gray-200"
                                    dangerouslySetInnerHTML={{ __html: renderMarkdown(response) }}
                                />
                                {groundedContent && (
                                    <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
                                        <p className="text-sm text-purple-800 dark:text-purple-200">
                                            This answer is based on LPU Studio content. Go to: 
                                            <button
                                                onClick={() => handleGroundedLinkClick(groundedContent)}
                                                className="font-semibold underline ml-1 hover:text-purple-600 dark:hover:text-purple-100"
                                            >
                                                {groundedContent.name}
                                            </button>
                                        </p>
                                    </div>
                                )}
                                {sources.length > 0 && (
                                    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                                        <h4 className="text-xs font-bold uppercase text-gray-500 dark:text-gray-400 mb-2">Sources</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {sources.map((source, index) => source.web && (
                                                <a
                                                    key={index}
                                                    href={source.web.uri}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="text-xs bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 px-2 py-1 rounded-md transition-colors truncate"
                                                    title={source.web.title}
                                                >
                                                    {source.web.title}
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                        
                        {searchHistory.length > 0 && !response && !isLoading && !error && (
                            <div className="border-t border-gray-200 dark:border-gray-700 mt-4 pt-4">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400">Recent Searches</h4>
                                    <button onClick={(e) => { e.stopPropagation(); handleClearHistory(); }} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1">
                                        <TrashIcon className="w-3 h-3"/> Clear
                                    </button>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {searchHistory.map((item, index) => (
                                        <button
                                            key={index}
                                            onClick={(e) => { e.stopPropagation(); handleHistoryClick(item); }}
                                            className="bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 px-3 py-1 rounded-full text-sm transition-colors"
                                        >
                                            {item}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};