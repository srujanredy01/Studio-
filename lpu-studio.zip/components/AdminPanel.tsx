
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import type { CodingTopic, NewsArticle, Year, User, TeamMember, AnalyticsEvent, CodingTopicDifficulty, Subject, SubjectFile, FileType } from '../types';
import { ConfirmationModal } from './ConfirmationModal';
import { Modal } from './Modal';
import { TrashIcon } from './icons/ActionIcons';
import { SunIcon, MoonIcon } from './icons/ThemeIcons';
import { AnalyticsChart } from './AnalyticsChart';
import { PdfFileIcon, PresentationFileIcon, DocumentFileIcon, SpreadsheetFileIcon } from './FileIcons';

type AdminPanelProps = {
    subjects: Subject[];
    setSubjects: React.Dispatch<React.SetStateAction<Subject[]>>;
    codingTopics: CodingTopic[];
    setCodingTopics: React.Dispatch<React.SetStateAction<CodingTopic[]>>;
    newsArticles: NewsArticle[];
    setNewsArticles: React.Dispatch<React.SetStateAction<NewsArticle[]>>;
    teamMembers: TeamMember[];
    setTeamMembers: React.Dispatch<React.SetStateAction<TeamMember[]>>;
    isAdminAuthenticated: boolean;
    onLogin: () => void;
    onLogout: () => void;
    user: User;
    allUsers: User[];
    setAllUsers: React.Dispatch<React.SetStateAction<User[]>>;
    setUser: React.Dispatch<React.SetStateAction<User>>;
};

type ActiveTab = 'subjects' | 'coding' | 'news' | 'users' | 'team' | 'analytics' | 'profile';

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_SECONDS = 30;

// Session Timeout Constants
const INACTIVITY_TIMEOUT_DURATION = 15 * 60 * 1000; // 15 minutes
const WARNING_DURATION = 60 * 1000; // 1 minute warning

const getAddItemButtonText = (tab: ActiveTab): string => {
    switch(tab) {
        case 'subjects': return 'Add New Subject';
        case 'coding': return 'Add New Coding Topic';
        case 'news': return 'Add New News Article';
        case 'team': return 'Add New Team Member';
        case 'users': return 'Add New User';
        default: return '';
    }
};

const EditIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
    </svg>
);

const FileIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
    </svg>
);

const getFileIcon = (type: FileType, props: React.SVGProps<SVGSVGElement>) => {
    switch (type) {
        case 'pdf': return <PdfFileIcon {...props} />;
        case 'presentation': return <PresentationFileIcon {...props} />;
        case 'document': return <DocumentFileIcon {...props} />;
        case 'spreadsheet': return <SpreadsheetFileIcon {...props} />;
        default: return <DocumentFileIcon {...props} />;
    }
};


const ActivityTable: React.FC<{
    title: string;
    headers: string[];
    data: any[];
    renderRow: (item: any, index: number) => React.ReactNode;
}> = ({ title, headers, data, renderRow }) => (
    <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">{title}</h3>
        {data.length > 0 ? (
            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead className="text-left text-gray-600 dark:text-gray-300">
                        <tr>
                            {headers.map(h => <th key={h} className="pb-2 font-semibold pr-4">{h}</th>)}
                        </tr>
                    </thead>
                    <tbody className="text-gray-700 dark:text-gray-200">
                        {data.map(renderRow)}
                    </tbody>
                </table>
            </div>
        ) : (
            <p className="text-gray-500 dark:text-gray-400">No activity data available.</p>
        )}
    </div>
);


export const AdminPanel: React.FC<AdminPanelProps> = ({
    subjects, setSubjects,
    codingTopics, setCodingTopics,
    newsArticles, setNewsArticles,
    teamMembers, setTeamMembers,
    isAdminAuthenticated, onLogin, onLogout,
    user, allUsers, setAllUsers, setUser
}) => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('subjects');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedAdminYear, setSelectedAdminYear] = useState<'All' | Year>('All');
    const [selectedAdminSemester, setSelectedAdminSemester] = useState<'All' | 1 | 2>('All');

    // Login state
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

     // Brute-force protection state
    const [failedAttempts, setFailedAttempts] = useState<number>(() => {
        const storedAttempts = sessionStorage.getItem('failedAttempts');
        return storedAttempts ? parseInt(storedAttempts, 10) : 0;
    });
    const [lockoutEndTime, setLockoutEndTime] = useState<number | null>(() => {
        const storedLockoutTime = sessionStorage.getItem('lockoutEndTime');
        return storedLockoutTime ? parseInt(storedLockoutTime, 10) : null;
    });
    const [remainingLockoutTime, setRemainingLockoutTime] = useState<number>(0);

    // State for modals
    const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
    const [editingSubject, setEditingSubject] = useState<Subject | Partial<Subject> | null>(null);
    const [managingFilesForSubject, setManagingFilesForSubject] = useState<Subject | null>(null);
    const [stagedFiles, setStagedFiles] = useState<Partial<SubjectFile>[]>([]);

    const fileUploadRef = useRef<HTMLInputElement>(null);
    const teamImageFileRef = useRef<HTMLInputElement>(null);

    const [isCodingModalOpen, setIsCodingModalOpen] = useState(false);
    const [editingCodingTopic, setEditingCodingTopic] = useState<CodingTopic | Partial<CodingTopic> | null>(null);
    
    const [isNewsModalOpen, setIsNewsModalOpen] = useState(false);
    const [editingNewsArticle, setEditingNewsArticle] = useState<NewsArticle | Partial<NewsArticle> | null>(null);

    const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);
    const [editingTeamMember, setEditingTeamMember] = useState<TeamMember | Partial<TeamMember> | null>(null);

    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | Partial<User> | null>(null);

    const [itemToDelete, setItemToDelete] = useState<{ type: ActiveTab; id?: number | string; ids?: (number | string)[]; fileId?: number; subjectId?: number; } | null>(null);
    
    // State for save confirmation
    const [isSaveConfirmationOpen, setIsSaveConfirmationOpen] = useState(false);
    const [itemToSave, setItemToSave] = useState<{ type: ActiveTab; data: any } | null>(null);

    // State for multi-selection
    const [selectedIds, setSelectedIds] = useState<Record<string, (string | number)[]>>({
        subjects: [],
        coding: [],
        news: [],
        team: [],
        users: [],
    });
    const selectAllCheckboxRef = useRef<HTMLInputElement>(null);


    // Forgot Password Modal State
    const [isForgotPasswordModalOpen, setIsForgotPasswordModalOpen] = useState(false);
    const [resetEmail, setResetEmail] = useState('');
    const [resetMessage, setResetMessage] = useState('');

    // Session Timeout State
    const [isTimeoutWarningModalOpen, setIsTimeoutWarningModalOpen] = useState(false);
    const [warningCountdown, setWarningCountdown] = useState(WARNING_DURATION / 1000);
    const logoutTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const warningTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const countdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

    // Admin Panel Theme State
    const [adminTheme, setAdminTheme] = useState<'light' | 'dark'>(() => {
        if (typeof window !== 'undefined') {
            return (localStorage.getItem('adminTheme') as 'light' | 'dark') || 'light';
        }
        return 'light';
    });
    
    // Analytics State
    const [analyticsData, setAnalyticsData] = useState<AnalyticsEvent[]>([]);

    // State for password change form
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordMessage, setPasswordMessage] = useState({ type: '', text: '' }); // type: 'success' | 'error'

    const searchPlaceholders: Record<ActiveTab, string> = {
        subjects: 'Search subjects by name...',
        coding: 'Search topics by name or description...',
        news: 'Search articles by title...',
        users: 'Search by Name, ID, Year, or Interests...',
        team: 'Search team members by name or role...',
        analytics: 'Analytics data is not searchable.',
        profile: 'Admin profile settings.',
    };

    useEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('adminTheme', adminTheme);
        }
    }, [adminTheme]);

    const toggleAdminTheme = () => {
        setAdminTheme(prev => (prev === 'light' ? 'dark' : 'light'));
    };


    useEffect(() => {
        setSearchTerm(''); // Reset search term when tab changes
        setSelectedAdminYear('All');
        setSelectedAdminSemester('All');
        // Clear selections when tab changes to avoid confusion
        setSelectedIds({ subjects: [], coding: [], news: [], team: [], users: [] });
    }, [activeTab]);
    
    useEffect(() => {
        let interval: ReturnType<typeof setInterval> | null = null;
        if (lockoutEndTime && lockoutEndTime > Date.now()) {
            const updateRemainingTime = () => {
                const remaining = Math.ceil((lockoutEndTime - Date.now()) / 1000);
                if (remaining > 0) {
                    setRemainingLockoutTime(remaining);
                } else {
                    setLockoutEndTime(null);
                    sessionStorage.removeItem('lockoutEndTime');
                    setFailedAttempts(0);
                    sessionStorage.removeItem('failedAttempts');
                    setRemainingLockoutTime(0);
                    setError('');
                    if (interval) clearInterval(interval);
                }
            };
            updateRemainingTime();
            interval = setInterval(updateRemainingTime, 1000);
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    }, [lockoutEndTime]);
    
    // --- Session Timeout Logic ---
    const resetTimers = useCallback(() => {
        if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
        if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);

        warningTimerRef.current = setTimeout(() => {
            setIsTimeoutWarningModalOpen(true);
        }, INACTIVITY_TIMEOUT_DURATION - WARNING_DURATION);

        logoutTimerRef.current = setTimeout(() => {
            onLogout();
        }, INACTIVITY_TIMEOUT_DURATION);
    }, [onLogout]);

    useEffect(() => {
        if (isAdminAuthenticated) {
            try {
                const storedEvents = window.localStorage.getItem('userAnalytics');
                const events: AnalyticsEvent[] = storedEvents ? JSON.parse(storedEvents) : [];
                setAnalyticsData(events);
            } catch (error) {
                console.error('Failed to load analytics data:', error);
                setAnalyticsData([]);
            }
        }
    }, [isAdminAuthenticated]);

    useEffect(() => {
        if (!isAdminAuthenticated) {
            return;
        }

        const events: (keyof WindowEventMap)[] = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];
        const handleActivity = () => resetTimers();
        
        events.forEach(event => window.addEventListener(event, handleActivity));
        resetTimers();

        return () => {
            events.forEach(event => window.removeEventListener(event, handleActivity));
            if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
            if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
            if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        };
    }, [isAdminAuthenticated, resetTimers]);

    useEffect(() => {
        if (isTimeoutWarningModalOpen) {
            setWarningCountdown(WARNING_DURATION / 1000);
            countdownIntervalRef.current = setInterval(() => {
                setWarningCountdown(prev => {
                    if (prev <= 1) {
                        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } else {
            if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        }
        return () => {
            if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        };
    }, [isTimeoutWarningModalOpen]);

    const handleStayLoggedIn = () => {
        setIsTimeoutWarningModalOpen(false);
        resetTimers();
    };
    // --- End Session Timeout Logic ---


    const handleLoginAttempt = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (lockoutEndTime && lockoutEndTime > Date.now()) {
            const remaining = Math.ceil((lockoutEndTime - Date.now()) / 1000);
            setError(`Too many failed attempts. Please try again in ${remaining} seconds.`);
            return;
        }

        if (!username || !password) {
            setError('Both username and password are required.');
            return;
        }
        
        const storedPassword = sessionStorage.getItem('adminPassword');
        const correctPassword = storedPassword || 'password123';

        if (username === 'admin' && password === correctPassword) {
            setFailedAttempts(0);
            sessionStorage.removeItem('failedAttempts');
            setLockoutEndTime(null);
            sessionStorage.removeItem('lockoutEndTime');
            onLogin();
        } else {
            const newFailedAttempts = failedAttempts + 1;
            setFailedAttempts(newFailedAttempts);
            sessionStorage.setItem('failedAttempts', String(newFailedAttempts));

            if (newFailedAttempts >= MAX_FAILED_ATTEMPTS) {
                const newLockoutEndTime = Date.now() + LOCKOUT_DURATION_SECONDS * 1000;
                setLockoutEndTime(newLockoutEndTime);
                sessionStorage.setItem('lockoutEndTime', String(newLockoutEndTime));
                setError(`Too many failed attempts. Please try again in ${LOCKOUT_DURATION_SECONDS} seconds.`);
            } else {
                const attemptsLeft = MAX_FAILED_ATTEMPTS - newFailedAttempts;
                setError(`Invalid username or password. ${attemptsLeft} ${attemptsLeft === 1 ? 'attempt' : 'attempts'} remaining.`);
            }
        }
    };
    
    const handlePrepareSave = (e: React.FormEvent, type: ActiveTab, data: any) => {
        e.preventDefault();
        if (!data) return;
        setItemToSave({ type, data });
        setIsSaveConfirmationOpen(true);
    };

    const handleConfirmSave = () => {
        if (!itemToSave) return;
        const { type, data } = itemToSave;

        if (type === 'subjects') {
            if ('id' in data) { // Update
                setSubjects(subjects.map(s => s.id === data.id ? data as Subject : s));
            } else { // Create
                const newSubject: Subject = { ...data, id: Date.now(), semester: data.semester || 1, files: [] } as Subject;
                setSubjects([...subjects, newSubject]);
            }
            setIsSubjectModalOpen(false);
            setEditingSubject(null);
        }
        else if (type === 'coding') {
            if ('id' in data && data.id) { // Update
                setCodingTopics(codingTopics.map(c => c.id === data.id ? data as CodingTopic : c));
            } else { // Create
                const newTopic: CodingTopic = { ...data, id: data.name?.toLowerCase().replace(/\s+/g, '') || `topic-${Date.now()}` } as CodingTopic;
                setCodingTopics([...codingTopics, newTopic]);
            }
            setIsCodingModalOpen(false);
            setEditingCodingTopic(null);
        }
        else if (type === 'news') {
            if ('id' in data) { // Update
                setNewsArticles(newsArticles.map(a => a.id === data.id ? data as NewsArticle : a));
            } else { // Create
                const newArticle: NewsArticle = { ...data, id: Date.now() } as NewsArticle;
                setNewsArticles([...newsArticles, newArticle]);
            }
            setIsNewsModalOpen(false);
            setEditingNewsArticle(null);
        }
        else if (type === 'team') {
            if ('id' in data) { // Update
                setTeamMembers(teamMembers.map(m => m.id === data.id ? data as TeamMember : m));
            } else { // Create
                const newMember: TeamMember = { ...data, id: Date.now() } as TeamMember;
                setTeamMembers([...teamMembers, newMember]);
            }
            setIsTeamModalOpen(false);
            setEditingTeamMember(null);
        }
        else if (type === 'users') {
             if (allUsers.some(u => u.idNumber === data.idNumber && u.idNumber !== (editingUser as User)?.idNumber)) {
                alert('A user with this ID number already exists.');
                setItemToSave(null);
                setIsSaveConfirmationOpen(false);
                return;
            }

            if ('idNumber' in (editingUser as User) && (editingUser as User).idNumber) { // Update existing
                setAllUsers(allUsers.map(u => u.idNumber === (editingUser as User).idNumber ? data as User : u));
                 // Check if the edited user is the current user
                if ((editingUser as User).idNumber === user.idNumber) {
                    setUser(data as User);
                }
            } else { // Create new
                const newUser: User = { ...data, loginCount: 0, lastLogin: new Date().toISOString() } as User;
                setAllUsers([...allUsers, newUser]);
            }
            setIsUserModalOpen(false);
            setEditingUser(null);
        }

        setIsSaveConfirmationOpen(false);
        setItemToSave(null);
    };

    const handleCancelSave = () => {
        setIsSaveConfirmationOpen(false);
        setItemToSave(null);
    };


    const confirmDelete = () => {
        if (!itemToDelete) return;
        const { type, id, ids, fileId, subjectId } = itemToDelete;

        if (fileId && subjectId) { // Deleting a single file from a subject
             const updatedSubjects = subjects.map(s => {
                if (s.id === subjectId) {
                    return { ...s, files: s.files.filter(p => p.id !== fileId) };
                }
                return s;
            });
            setSubjects(updatedSubjects);
            setManagingFilesForSubject(prev => prev ? updatedSubjects.find(s => s.id === prev.id) || null : null);
        } else if (ids) { // Bulk delete
            if (type === 'subjects') setSubjects(prev => prev.filter(s => !ids.includes(s.id)));
            else if (type === 'coding') setCodingTopics(prev => prev.filter(c => !ids.includes(c.id)));
            else if (type === 'news') setNewsArticles(prev => prev.filter(a => !ids.includes(a.id)));
            else if (type === 'team') setTeamMembers(prev => prev.filter(m => !ids.includes(m.id)));
            else if (type === 'users') setAllUsers(prev => prev.filter(u => u.idNumber && !ids.includes(u.idNumber)));
            
            setSelectedIds(prev => ({ ...prev, [type]: [] })); // Clear selection after delete
        } else if (id) { // Single delete
            if (type === 'subjects') setSubjects(subjects.filter(s => s.id !== id));
            else if (type === 'coding') setCodingTopics(codingTopics.filter(c => c.id !== id));
            else if (type === 'news') setNewsArticles(newsArticles.filter(a => a.id !== id));
            else if (type === 'team') setTeamMembers(teamMembers.filter(m => m.id !== id));
            else if (type === 'users') setAllUsers(allUsers.filter(u => u.idNumber !== id));
        }
        setItemToDelete(null);
    };

    const handleDeleteSelected = () => {
        const idsToDelete = selectedIds[activeTab];
        if (idsToDelete && idsToDelete.length > 0) {
            setItemToDelete({ type: activeTab, ids: idsToDelete });
        }
    };


     const handlePasswordReset = (e: React.FormEvent) => {
        e.preventDefault();
        if (!resetEmail) {
            setResetMessage('Please enter your email address.');
            return;
        }
        // Simulate sending a reset link
        setResetMessage(`If an account exists for ${resetEmail}, a password reset link has been sent.`);
        
        // Clear email and close modal after a delay
        setTimeout(() => {
            closeForgotPasswordModal();
        }, 3000);
    };

    const closeForgotPasswordModal = () => {
        setIsForgotPasswordModalOpen(false);
        setResetEmail('');
        setResetMessage('');
    };

     const handleExportUserData = () => {
        const headers = ['Name', 'ID Number', 'Year', 'Interests', 'Last Login', 'Login Count'];
        
        const interests = user.interests ? `"${user.interests.join('; ')}"` : ''; // Use semicolon for interests to avoid CSV issues
        const lastLogin = user.lastLogin ? `"${new Date(user.lastLogin).toLocaleString()}"` : 'N/A';
        
        const userData = [
            `"${user.name || 'N/A'}"`,
            `"${user.idNumber || 'N/A'}"`,
            `"${user.year || 'N/A'}"`,
            interests,
            lastLogin,
            user.loginCount || 0
        ].join(',');

        const csvContent = [headers.join(','), userData].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'user_profile_export.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    
    const handleTeamImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (!file.type.startsWith('image/')) {
                alert('Please upload a valid image file (PNG, JPG, etc.).');
                if (teamImageFileRef.current) teamImageFileRef.current.value = "";
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setEditingTeamMember(prev => ({
                    ...prev,
                    imageUrl: reader.result as string,
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleFilesSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (!files || files.length === 0) return;

        const fileTypeMap: { [key: string]: FileType } = {
            'application/pdf': 'pdf',
            'application/vnd.ms-powerpoint': 'presentation',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'presentation',
            'application/msword': 'document',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'document',
            'application/vnd.ms-excel': 'spreadsheet',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'spreadsheet',
        };

        // FIX: Explicitly type `file` as `File` to resolve properties `type`, `name` and allow usage in `createObjectURL`.
        const newStagedFiles = Array.from(files).map((file: File) => {
            const guessedType = fileTypeMap[file.type] || 'document';
            return {
                name: file.name.replace(/\.[^/.]+$/, ""),
                link: URL.createObjectURL(file), // Use Object URL instead of Base64
                type: guessedType,
            };
        });

        setStagedFiles(prev => [...prev, ...newStagedFiles]);

        // Clear the file input so the same files can be selected again if needed
        if (fileUploadRef.current) {
            fileUploadRef.current.value = "";
        }
    };

    const handleUpdateStagedFile = (index: number, field: 'name' | 'type', value: string) => {
        setStagedFiles(prev => {
            const newStagedFiles = [...prev];
            newStagedFiles[index] = { ...newStagedFiles[index], [field]: value };
            return newStagedFiles;
        });
    };

    const handleRemoveStagedFile = (index: number) => {
        setStagedFiles(prev => prev.filter((_, i) => i !== index));
    };

    const handleAddStagedFiles = () => {
        if (!managingFilesForSubject || stagedFiles.length === 0) return;

        const newFiles: SubjectFile[] = stagedFiles.map((sf, index) => ({
            id: Date.now() + index,
            name: sf.name || `Unnamed File ${index + 1}`,
            link: sf.link || '',
            type: sf.type || 'document',
        }));

        const updatedSubjects = subjects.map(s => {
            if (s.id === managingFilesForSubject.id) {
                return { ...s, files: [...s.files, ...newFiles] };
            }
            return s;
        });

        setSubjects(updatedSubjects);
        setManagingFilesForSubject(prev => prev ? updatedSubjects.find(s => s.id === prev.id) || null : null);
        setStagedFiles([]); // Clear stage after adding
    };


     const handleChangePassword = (e: React.FormEvent) => {
        e.preventDefault();
        setPasswordMessage({ type: '', text: '' });

        const storedPassword = sessionStorage.getItem('adminPassword');
        const correctPassword = storedPassword || 'password123';

        if (currentPassword !== correctPassword) {
            setPasswordMessage({ type: 'error', text: 'Current password is incorrect.' });
            return;
        }
        if (!newPassword || newPassword.length < 8) {
             setPasswordMessage({ type: 'error', text: 'New password must be at least 8 characters long.' });
             return;
        }
        if (newPassword !== confirmPassword) {
            setPasswordMessage({ type: 'error', text: 'New passwords do not match.' });
            return;
        }
        if (newPassword === correctPassword) {
            setPasswordMessage({ type: 'error', text: 'New password cannot be the same as the old password.'});
            return;
        }

        sessionStorage.setItem('adminPassword', newPassword);
        setPasswordMessage({ type: 'success', text: 'Password changed successfully! The new password is now active for this session.' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
    };

    const tabClasses = (tabName: ActiveTab) =>
        `px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
            activeTab === tabName
                ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900'
                : 'bg-transparent text-gray-600 hover:bg-black/10 dark:text-gray-300 dark:hover:bg-white/10'
        }`;
    
    const inputClasses = "w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-md py-2 px-3 text-gray-800 dark:text-white focus:ring-1 focus:ring-purple-500 focus:border-purple-500";
    
    const filteredSubjects = useMemo(() => subjects.filter(s =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (selectedAdminYear === 'All' || s.year === selectedAdminYear) &&
        (selectedAdminSemester === 'All' || s.semester === selectedAdminSemester)
    ), [subjects, searchTerm, selectedAdminYear, selectedAdminSemester]);

    const filteredCodingTopics = useMemo(() => codingTopics.filter(c =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.description.toLowerCase().includes(searchTerm.toLowerCase())
    ), [codingTopics, searchTerm]);

    const filteredNewsArticles = useMemo(() => newsArticles.filter(a =>
        a.title.toLowerCase().includes(searchTerm.toLowerCase())
    ), [newsArticles, searchTerm]);

    const filteredTeamMembers = useMemo(() => teamMembers.filter(m =>
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.role.toLowerCase().includes(searchTerm.toLowerCase())
    ), [teamMembers, searchTerm]);

    const filteredUsers = useMemo(() => allUsers.filter(u => {
        if (!u || u.name === 'Guest') return false; // Don't show guest user
        const term = searchTerm.toLowerCase();
        if (term === '') {
            return true;
        }

        const nameMatch = u.name.toLowerCase().includes(term);
        const idMatch = u.idNumber ? u.idNumber.toLowerCase().includes(term) : false;
        const yearMatch = u.year ? u.year.toLowerCase().includes(term) : false;
        const interestsMatch = u.interests ? u.interests.some(interest => interest.toLowerCase().includes(term)) : false;

        // Ensure loginCount is handled as a number for searching.
        const loginCountMatch = u.loginCount !== undefined && String(u.loginCount).includes(term);

        return nameMatch || idMatch || yearMatch || interestsMatch || loginCountMatch;
    }), [allUsers, searchTerm]);

    const currentListMap = useMemo(() => ({
        subjects: filteredSubjects,
        coding: filteredCodingTopics,
        news: filteredNewsArticles,
        team: filteredTeamMembers,
        users: filteredUsers,
        analytics: [],
        profile: [],
    }), [filteredSubjects, filteredCodingTopics, filteredNewsArticles, filteredTeamMembers, filteredUsers]);

    const handleToggleSelectOne = (id: string | number) => {
        setSelectedIds(prev => {
            const currentSelection = prev[activeTab] || [];
            const newSelection = new Set(currentSelection);
            if (newSelection.has(id)) {
                newSelection.delete(id);
            } else {
                newSelection.add(id);
            }
            return { ...prev, [activeTab]: Array.from(newSelection) };
        });
    };

    const handleToggleSelectAll = () => {
        const currentList = currentListMap[activeTab as keyof typeof currentListMap] || [];
        const currentIds = currentList.map(item => item.id || item.idNumber);
        const allSelectedOnPage = currentIds.length > 0 && currentIds.every(id => selectedIds[activeTab]?.includes(id));

        setSelectedIds(prev => {
            const selection = new Set(prev[activeTab] || []);
            if (allSelectedOnPage) {
                currentIds.forEach(id => selection.delete(id));
            } else {
                currentIds.forEach(id => selection.add(id));
            }
            return { ...prev, [activeTab]: Array.from(selection) };
        });
    };
    
    const pageViewData = useMemo(() => {
        const counts = analyticsData
            .filter(e => e.type === 'pageView')
            .reduce((acc: Record<string, number>, curr) => {
                acc[curr.name] = (acc[curr.name] || 0) + 1;
                return acc;
            }, {} as Record<string, number>);
        
        return Object.entries(counts)
            .map(([label, value]) => ({ label, value }))
            .sort((a, b) => b.value - a.value);
    }, [analyticsData]);

    const featureUsageData = useMemo(() => {
        const counts = analyticsData
            .filter(e => e.type === 'featureUse')
            .reduce((acc: Record<string, number>, curr) => {
                acc[curr.name] = (acc[curr.name] || 0) + 1;
                return acc;
            }, {} as Record<string, number>);
        
        return Object.entries(counts)
            .map(([label, value]) => ({ label, value }))
            .sort((a, b) => b.value - a.value);
    }, [analyticsData]);

    const userPageViews = useMemo(() => {
        const activity = analyticsData
            .filter(e => e.type === 'pageView')
            .reduce((acc: Record<string, { userName: string, page: string, count: number }>, curr) => {
                const key = `${curr.userName}-${curr.name}`;
                if (!acc[key]) {
                    acc[key] = { userName: curr.userName || 'Guest', page: curr.name, count: 0 };
                }
                acc[key].count += 1;
                return acc;
            }, {} as Record<string, { userName: string, page: string, count: number }>);
        // FIX: Explicitly type sort parameters to resolve arithmetic operation error.
        return Object.values(activity).sort((a: { count: number; }, b: { count: number; }) => b.count - a.count);
    }, [analyticsData]);

    const downloadActivity = useMemo(() => {
        const activity = analyticsData
            .filter(e => e.type === 'featureUse' && e.name === 'download_resource' && e.payload?.resourceName)
            .reduce((acc: Record<string, { userName: string, resourceName: string, count: number }>, curr) => {
                const key = `${curr.userName}-${curr.payload!.resourceName}`;
                if (!acc[key]) {
                    acc[key] = { userName: curr.userName || 'Guest', resourceName: curr.payload!.resourceName, count: 0 };
                }
                acc[key].count += 1;
                return acc;
            }, {} as Record<string, { userName: string, resourceName: string, count: number }>);
        // FIX: Explicitly type sort parameters to resolve arithmetic operation error.
        return Object.values(activity).sort((a: { count: number; }, b: { count: number; }) => b.count - a.count);
    }, [analyticsData]);

    const saveActivity = useMemo(() => {
        const saveEventNames = ['save_resource', 'save_article', 'save_coding_topic'];
        const activity = analyticsData
            .filter(e => e.type === 'featureUse' && saveEventNames.includes(e.name))
            .reduce((acc: Record<string, { userName: string, itemName: string, itemType: string, count: number }>, curr) => {
                const itemName = curr.payload?.resourceName || curr.payload?.articleTitle || curr.payload?.topicName || 'Unknown';
                const itemType = curr.name.replace('save_', '');
                const key = `${curr.userName}-${itemType}-${itemName}`;

                if (!acc[key]) {
                    acc[key] = { userName: curr.userName || 'Guest', itemName, itemType, count: 0 };
                }
                acc[key].count += 1;
                return acc;
            }, {} as Record<string, { userName: string, itemName: string, itemType: string, count: number }>);
        // FIX: Explicitly type sort parameters to resolve property access on 'unknown' error.
        return Object.values(activity).sort((a: { count: number }, b: { count: number }) => b.count - a.count);
    }, [analyticsData]);

    const currentList = currentListMap[activeTab as keyof typeof currentListMap] || [];
    const currentIds = currentList.map(item => item.id || item.idNumber);
    const selectedOnPageCount = currentIds.filter(id => selectedIds[activeTab]?.includes(id)).length;
    const allSelectedOnPage = currentList.length > 0 && selectedOnPageCount === currentList.length;

    useEffect(() => {
        if (selectAllCheckboxRef.current) {
            selectAllCheckboxRef.current.indeterminate = selectedOnPageCount > 0 && !allSelectedOnPage;
        }
    }, [selectedOnPageCount, allSelectedOnPage]);


    if (!isAdminAuthenticated) {
        const isLockedOut = remainingLockoutTime > 0;
        return (
            <div className={`${adminTheme} min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8`}>
                <div className="w-full max-w-md space-y-8">
                    <div>
                        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
                            Admin Login
                        </h2>
                    </div>
                    <form className="mt-8 space-y-6 glass-effect shadow-lg rounded-xl p-8" onSubmit={handleLoginAttempt}>
                        <div className="rounded-md shadow-sm flex flex-col gap-4">
                            <div>
                                <label htmlFor="username" className="sr-only">Username</label>
                                <input
                                    id="username"
                                    name="username"
                                    type="text"
                                    autoComplete="username"
                                    required
                                    disabled={isLockedOut}
                                    className="appearance-none rounded-md relative block w-full px-3 py-2 border border-black/10 dark:border-white/10 placeholder-gray-500 text-gray-900 dark:text-white bg-black/5 dark:bg-white/5 focus:outline-none focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                                    placeholder="Username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                />
                            </div>
                            <div>
                                <label htmlFor="password-login" className="sr-only">Password</label>
                                <input
                                    id="password-login"
                                    name="password"
                                    type="password"
                                    autoComplete="current-password"
                                    required
                                    disabled={isLockedOut}
                                    className="appearance-none rounded-md relative block w-full px-3 py-2 border border-black/10 dark:border-white/10 placeholder-gray-500 text-gray-900 dark:text-white bg-black/5 dark:bg-white/5 focus:outline-none focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                                    placeholder="Password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>
                        </div>

                         <div className="flex items-center justify-end text-sm">
                            <button
                                type="button"
                                onClick={() => {
                                    setIsForgotPasswordModalOpen(true);
                                    setError(''); // Clear login error
                                }}
                                className="font-medium text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 transition-colors"
                            >
                                Forgot your password?
                            </button>
                        </div>

                        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                        {isLockedOut && <p className="text-yellow-500 text-sm text-center font-medium">Please try again in {remainingLockoutTime} seconds.</p>}

                        <div>
                            <button
                                type="submit"
                                disabled={isLockedOut}
                                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-500 disabled:cursor-not-allowed"
                            >
                                Sign in
                            </button>
                        </div>
                    </form>
                     {isForgotPasswordModalOpen && (
                         <Modal isOpen={isForgotPasswordModalOpen} onClose={closeForgotPasswordModal} title="Reset Password" maxWidthClass="max-w-md">
                            {resetMessage ? (
                                <p className="text-center text-green-600 dark:text-green-400 p-4">{resetMessage}</p>
                            ) : (
                                <form onSubmit={handlePasswordReset} className="space-y-4">
                                    <p className="text-sm text-gray-600 dark:text-gray-300">Enter your email address and we'll send you a link to reset your password.</p>
                                    <div>
                                        <label htmlFor="reset-email" className="sr-only">Email address</label>
                                        <input
                                            id="reset-email"
                                            name="email"
                                            type="email"
                                            autoComplete="email"
                                            required
                                            className={inputClasses.replace('py-2', 'py-3')}
                                            placeholder="Email address"
                                            value={resetEmail}
                                            onChange={(e) => setResetEmail(e.target.value)}
                                        />
                                    </div>
                                    <div className="flex justify-end gap-3 pt-4">
                                        <button type="button" onClick={closeForgotPasswordModal} className="px-4 py-2 font-semibold glass-button">Cancel</button>
                                        <button type="submit" className="px-4 py-2 font-semibold glass-button primary">Send Reset Link</button>
                                    </div>
                                </form>
                            )}
                        </Modal>
                    )}
                </div>
            </div>
        );
    }
    
    return (
        <div className={`${adminTheme} min-h-screen`}>
            <section className="py-16 glass-effect shadow-md">
                <div className="container mx-auto px-6 lg:px-8 relative">
                    <div className="text-center">
                        <h1 className="text-5xl font-bold text-gray-800 dark:text-white">Admin Panel</h1>
                        <p className="mt-4 text-gray-600 dark:text-gray-300">Manage your application's content.</p>
                    </div>
                     <div className="absolute top-1/2 right-6 -translate-y-1/2 flex items-center gap-4">
                        <button
                            onClick={toggleAdminTheme}
                            className="w-10 h-10 rounded-full p-2 flex items-center justify-center text-gray-600 dark:text-gray-300 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
                            aria-label={`Switch to ${adminTheme === 'light' ? 'dark' : 'light'} mode`}
                        >
                            {adminTheme === 'light' ? <SunIcon className="w-6 h-6" /> : <MoonIcon className="w-6 h-6" />}
                        </button>
                        <button
                            onClick={onLogout}
                            className="glass-button"
                        >
                            Logout
                        </button>
                    </div>
                </div>
            </section>
            
            <section className="py-12">
                <div className="container mx-auto px-6 lg:px-8">
                    <div className="mb-8 flex justify-center">
                        <div className="flex flex-wrap justify-center gap-2 p-1 glass-effect rounded-lg">
                            <button onClick={() => setActiveTab('subjects')} className={tabClasses('subjects')}>Subjects & Files</button>
                            <button onClick={() => setActiveTab('coding')} className={tabClasses('coding')}>Coding</button>
                            <button onClick={() => setActiveTab('news')} className={tabClasses('news')}>News</button>
                            <button onClick={() => setActiveTab('team')} className={tabClasses('team')}>Team</button>
                            <button onClick={() => setActiveTab('users')} className={tabClasses('users')}>Users</button>
                            <button onClick={() => setActiveTab('analytics')} className={tabClasses('analytics')}>Analytics</button>
                            <button onClick={() => setActiveTab('profile')} className={tabClasses('profile')}>Profile</button>
                        </div>
                    </div>

                    {activeTab !== 'profile' && (
                        <div className="mb-8 flex flex-col md:flex-row gap-4 items-center">
                            <div className="relative flex-grow w-full">
                                <input
                                    type="text"
                                    placeholder={searchPlaceholders[activeTab]}
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="block w-full glass-effect rounded-full py-3 pl-5 pr-4 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    disabled={activeTab === 'analytics'}
                                />
                            </div>
                            {activeTab === 'subjects' && (
                                <>
                                    <select value={selectedAdminYear} onChange={(e) => setSelectedAdminYear(e.target.value as 'All' | Year)} className="glass-effect rounded-full py-3 pl-4 pr-10">
                                        <option value="All">All Years</option>
                                        <option value="1st year">1st Year</option>
                                        <option value="2nd year">2nd Year</option>
                                        <option value="3rd year">3rd Year</option>
                                        <option value="4th year">4th Year</option>
                                    </select>
                                    <select value={selectedAdminSemester} onChange={(e) => setSelectedAdminSemester(e.target.value === 'All' ? 'All' : parseInt(e.target.value, 10) as 1 | 2)} className="glass-effect rounded-full py-3 pl-4 pr-10">
                                        <option value="All">All Semesters</option>
                                        <option value="1">Semester 1</option>
                                        <option value="2">Semester 2</option>
                                    </select>
                                </>
                            )}
                            <div className="flex items-center gap-4 flex-shrink-0">
                                {selectedIds[activeTab] && selectedIds[activeTab].length > 0 && ['subjects', 'coding', 'news', 'team', 'users'].includes(activeTab) && (
                                    <button
                                        onClick={handleDeleteSelected}
                                        className="glass-button bg-red-500/20 text-red-700 dark:text-red-300 border-red-500/30"
                                    >
                                        Delete Selected ({selectedIds[activeTab].length})
                                    </button>
                                )}
                                {['subjects', 'coding', 'news', 'team', 'users'].includes(activeTab) && (
                                    <button
                                        onClick={() => {
                                            if (activeTab === 'subjects') { setEditingSubject({}); setIsSubjectModalOpen(true); }
                                            if (activeTab === 'coding') { setEditingCodingTopic({}); setIsCodingModalOpen(true); }
                                            if (activeTab === 'news') { setEditingNewsArticle({}); setIsNewsModalOpen(true); }
                                            if (activeTab === 'team') { setEditingTeamMember({}); setIsTeamModalOpen(true); }
                                            if (activeTab === 'users') { setEditingUser({}); setIsUserModalOpen(true); }
                                        }}
                                        className="glass-button primary flex-shrink-0"
                                    >
                                        {getAddItemButtonText(activeTab)}
                                    </button>
                                )}
                                {activeTab === 'users' && (
                                    <button onClick={handleExportUserData} className="glass-button primary">
                                        Export User Data
                                    </button>
                                )}
                            </div>
                        </div>
                    )}
                    
                    {activeTab === 'profile' ? (
                        <div className="max-w-2xl mx-auto glass-effect rounded-lg p-8">
                            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Change Admin Password</h2>
                            <form onSubmit={handleChangePassword} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Current Password</label>
                                    <input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className={inputClasses} required />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">New Password</label>
                                    <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className={inputClasses} required />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Confirm New Password</label>
                                    <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className={inputClasses} required />
                                </div>

                                {passwordMessage.text && (
                                    <p className={`text-sm ${passwordMessage.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                        {passwordMessage.text}
                                    </p>
                                )}

                                <div className="flex justify-end pt-4">
                                    <button type="submit" className="glass-button primary">
                                        Change Password
                                    </button>
                                </div>
                            </form>
                        </div>
                    ) : (
                        <div className="glass-effect rounded-lg overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-700 dark:text-gray-300">
                                <thead className="text-xs text-gray-800 dark:text-gray-200 uppercase bg-black/5 dark:bg-white/5">
                                    {activeTab === 'subjects' && (<tr><th className="p-4"><input type="checkbox" ref={selectAllCheckboxRef} checked={allSelectedOnPage} onChange={handleToggleSelectAll} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></th><th className="px-6 py-3">Subject Name</th><th className="px-6 py-3">Year</th><th className="px-6 py-3">Semester</th><th className="px-6 py-3">Files</th><th className="px-6 py-3">Actions</th></tr>)}
                                    {activeTab === 'coding' && (<tr><th className="p-4"><input type="checkbox" ref={selectAllCheckboxRef} checked={allSelectedOnPage} onChange={handleToggleSelectAll} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></th><th className="px-6 py-3">Name</th><th className="px-6 py-3">Category</th><th className="px-6 py-3">Description</th><th className="px-6 py-3">Actions</th></tr>)}
                                    {activeTab === 'news' && (<tr><th className="p-4"><input type="checkbox" ref={selectAllCheckboxRef} checked={allSelectedOnPage} onChange={handleToggleSelectAll} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></th><th className="px-6 py-3">Title</th><th className="px-6 py-3">Date</th><th className="px-6 py-3">Excerpt</th><th className="px-6 py-3">Actions</th></tr>)}
                                    {activeTab === 'team' && (<tr><th className="p-4"><input type="checkbox" ref={selectAllCheckboxRef} checked={allSelectedOnPage} onChange={handleToggleSelectAll} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></th><th className="px-6 py-3">Name</th><th className="px-6 py-3">Role</th><th className="px-6 py-3">Bio</th><th className="px-6 py-3">Actions</th></tr>)}
                                    {activeTab === 'users' && (<tr><th className="p-4"><input type="checkbox" ref={selectAllCheckboxRef} checked={allSelectedOnPage} onChange={handleToggleSelectAll} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></th><th className="px-6 py-3">Name</th><th className="px-6 py-3">ID</th><th className="px-6 py-3">Year</th><th className="px-6 py-3">Interests</th><th className="px-6 py-3">Last Login</th><th className="px-6 py-3">Login Count</th><th className="px-6 py-3">Actions</th></tr>)}
                                </thead>
                                <tbody>
                                    {activeTab === 'subjects' && filteredSubjects.map(s => (
                                        <tr key={s.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5">
                                            <td className="p-4"><input type="checkbox" checked={selectedIds[activeTab]?.includes(s.id)} onChange={() => handleToggleSelectOne(s.id)} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></td>
                                            <td className="px-6 py-4 font-medium">{s.name}</td>
                                            <td className="px-6 py-4">{s.year}</td>
                                            <td className="px-6 py-4">{s.semester}</td>
                                            <td className="px-6 py-4">{s.files.length}</td>
                                            <td className="px-6 py-4 flex gap-2">
                                                <button onClick={() => { setManagingFilesForSubject(s); setStagedFiles([]); }} className="p-2 text-gray-500 hover:text-purple-600 dark:text-gray-400 dark:hover:text-purple-300" title="Manage Files"><FileIcon className="w-5 h-5"/></button>
                                                <button onClick={() => { setEditingSubject(s); setIsSubjectModalOpen(true); }} className="p-2 text-gray-500 hover:text-purple-600 dark:text-gray-400 dark:hover:text-purple-300" title="Edit Subject"><EditIcon className="w-5 h-5"/></button>
                                                <button onClick={() => setItemToDelete({type: 'subjects', id: s.id})} className="p-2 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400" title="Delete Subject"><TrashIcon className="w-5 h-5"/></button>
                                            </td>
                                        </tr>
                                    ))}
                                    {activeTab === 'coding' && filteredCodingTopics.map(c => (
                                        <tr key={c.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5"><td className="p-4"><input type="checkbox" checked={selectedIds[activeTab]?.includes(c.id)} onChange={() => handleToggleSelectOne(c.id)} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></td><td className="px-6 py-4 font-medium">{c.name}</td><td className="px-6 py-4">{c.category}</td><td className="px-6 py-4 truncate max-w-xs">{c.description}</td><td className="px-6 py-4 flex gap-2"><button onClick={() => { setEditingCodingTopic(c); setIsCodingModalOpen(true); }} className="p-2"><EditIcon className="w-5 h-5"/></button><button onClick={() => setItemToDelete({type: 'coding', id: c.id})} className="p-2"><TrashIcon className="w-5 h-5"/></button></td></tr>
                                    ))}
                                    {activeTab === 'news' && filteredNewsArticles.map(a => (
                                        <tr key={a.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5"><td className="p-4"><input type="checkbox" checked={selectedIds[activeTab]?.includes(a.id)} onChange={() => handleToggleSelectOne(a.id)} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></td><td className="px-6 py-4 font-medium">{a.title}</td><td className="px-6 py-4">{a.date}</td><td className="px-6 py-4 truncate max-w-xs">{a.excerpt}</td><td className="px-6 py-4 flex gap-2"><button onClick={() => { setEditingNewsArticle(a); setIsNewsModalOpen(true); }} className="p-2"><EditIcon className="w-5 h-5"/></button><button onClick={() => setItemToDelete({type: 'news', id: a.id})} className="p-2"><TrashIcon className="w-5 h-5"/></button></td></tr>
                                    ))}
                                    {activeTab === 'team' && filteredTeamMembers.map(m => (
                                        <tr key={m.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5"><td className="p-4"><input type="checkbox" checked={selectedIds[activeTab]?.includes(m.id)} onChange={() => handleToggleSelectOne(m.id)} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></td><td className="px-6 py-4 font-medium">{m.name}</td><td className="px-6 py-4">{m.role}</td><td className="px-6 py-4 truncate max-w-xs">{m.bio}</td><td className="px-6 py-4 flex gap-2"><button onClick={() => { setEditingTeamMember(m); setIsTeamModalOpen(true); }} className="p-2"><EditIcon className="w-5 h-5"/></button><button onClick={() => setItemToDelete({type: 'team', id: m.id})} className="p-2"><TrashIcon className="w-5 h-5"/></button></td></tr>
                                    ))}
                                    {activeTab === 'users' && filteredUsers.map((u, i) => (
                                        <tr key={u.idNumber || i} className="border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5">
                                            <td className="p-4"><input type="checkbox" checked={selectedIds.users?.includes(u.idNumber || '')} onChange={() => handleToggleSelectOne(u.idNumber || '')} className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"/></td>
                                            <td className="px-6 py-4 font-medium">{u.name}</td>
                                            <td className="px-6 py-4">{u.idNumber}</td>
                                            <td className="px-6 py-4">{u.year}</td>
                                            <td className="px-6 py-4">{u.interests?.join(', ')}</td>
                                            <td className="px-6 py-4">{u.lastLogin ? new Date(u.lastLogin).toLocaleString() : 'N/A'}</td>
                                            <td className="px-6 py-4 text-center">{u.loginCount || 0}</td>
                                            <td className="px-6 py-4 flex gap-2">
                                                <button onClick={() => { setEditingUser(u); setIsUserModalOpen(true); }} className="p-2 text-gray-500 hover:text-purple-600 dark:text-gray-400 dark:hover:text-purple-300" title="Edit User"><EditIcon className="w-5 h-5"/></button>
                                                <button onClick={() => setItemToDelete({type: 'users', id: u.idNumber})} className="p-2 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400" title="Delete User"><TrashIcon className="w-5 h-5"/></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {activeTab === 'analytics' && (
                                <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
                                    <AnalyticsChart title="Page Views (Overall)" data={pageViewData} />
                                    <AnalyticsChart title="Feature Usage (Overall)" data={featureUsageData} />
                                    <div className="lg:col-span-2 space-y-8">
                                        <ActivityTable 
                                            title="User Page Views"
                                            headers={['User', 'Page', 'Views']}
                                            data={userPageViews}
                                            renderRow={(item, index) => (
                                                <tr key={index} className="border-t border-gray-200 dark:border-gray-600">
                                                    <td className="py-2 pr-4">{item.userName}</td>
                                                    <td className="py-2 pr-4">{item.page}</td>
                                                    <td className="py-2 pr-4 font-semibold text-right">{item.count}</td>
                                                </tr>
                                            )}
                                        />
                                        <ActivityTable 
                                            title="Resource Downloads"
                                            headers={['User', 'Resource Name', 'Downloads']}
                                            data={downloadActivity}
                                            renderRow={(item, index) => (
                                                <tr key={index} className="border-t border-gray-200 dark:border-gray-600">
                                                    <td className="py-2 pr-4">{item.userName}</td>
                                                    <td className="py-2 pr-4">{item.resourceName}</td>
                                                    <td className="py-2 pr-4 font-semibold text-right">{item.count}</td>
                                                </tr>
                                            )}
                                        />
                                        <ActivityTable 
                                            title="Saved Items"
                                            headers={['User', 'Item Name', 'Type', 'Saves']}
                                            data={saveActivity}
                                            renderRow={(item, index) => (
                                                <tr key={index} className="border-t border-gray-200 dark:border-gray-600">
                                                    <td className="py-2 pr-4">{item.userName}</td>
                                                    <td className="py-2 pr-4">{item.itemName}</td>
                                                    <td className="py-2 pr-4 capitalize">{item.itemType}</td>
                                                    <td className="py-2 pr-4 font-semibold text-right">{item.count}</td>
                                                </tr>
                                            )}
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </section>
            
            {managingFilesForSubject && (
                <Modal isOpen={!!managingFilesForSubject} onClose={() => {setManagingFilesForSubject(null); setStagedFiles([]);}} title={`Manage Files for "${managingFilesForSubject.name}"`} maxWidthClass="max-w-4xl">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Existing Files Column */}
                        <div>
                            <h4 className="font-semibold mb-3 text-gray-800 dark:text-white">Existing Files ({managingFilesForSubject.files.length})</h4>
                            {managingFilesForSubject.files.length > 0 ? (
                                <ul className="space-y-2 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                                    {managingFilesForSubject.files.map(file => (
                                        <li key={file.id} className="flex items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-lg">
                                            <div className="flex items-center gap-3 min-w-0">
                                                {getFileIcon(file.type, { className: "w-5 h-5 flex-shrink-0" })}
                                                <span className="text-gray-700 dark:text-gray-200 truncate pr-4" title={file.name}>{file.name}</span>
                                            </div>
                                            <button onClick={() => setItemToDelete({ type: 'subjects', fileId: file.id, subjectId: managingFilesForSubject.id })} className="p-1 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"><TrashIcon className="w-5 h-5"/></button>
                                        </li>
                                    ))}
                                </ul>
                            ) : <p className="text-sm text-gray-500 dark:text-gray-400">No files have been added to this subject yet.</p>}
                        </div>

                        {/* Add New Files Column */}
                        <div className="border-t md:border-t-0 md:border-l border-gray-200 dark:border-gray-600 pt-6 md:pt-0 md:pl-8">
                            <h4 className="font-semibold mb-3 text-gray-800 dark:text-white">Add New Files</h4>
                             <label className="w-full cursor-pointer glass-button text-center block py-4 border-2 border-dashed border-gray-400 dark:border-gray-500 hover:border-purple-500 hover:bg-black/5 dark:hover:bg-white/5 transition-all">
                                <span>Choose Files to Upload</span>
                                <input type="file" multiple onChange={handleFilesSelected} className="hidden" ref={fileUploadRef} />
                            </label>
                            
                            {stagedFiles.length > 0 && (
                                <div className="mt-6">
                                    <h5 className="font-semibold text-gray-800 dark:text-white mb-2">Staged Files ({stagedFiles.length})</h5>
                                    <ul className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                                        {stagedFiles.map((file, index) => (
                                            <li key={index} className="bg-black/5 dark:bg-white/5 p-3 rounded-lg space-y-2">
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2 min-w-0">
                                                        {getFileIcon(file.type || 'document', { className: "w-5 h-5 flex-shrink-0" })}
                                                        <span className="text-sm text-gray-600 dark:text-gray-400 truncate" title={file.name}>{file.name}</span>
                                                    </div>
                                                    <button onClick={() => handleRemoveStagedFile(index)} className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="w-4 h-4" /></button>
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                     <input 
                                                        type="text" 
                                                        value={file.name || ''} 
                                                        onChange={(e) => handleUpdateStagedFile(index, 'name', e.target.value)} 
                                                        className={inputClasses + ' text-sm'} 
                                                        placeholder="File Name"
                                                    />
                                                    <select 
                                                        value={file.type || 'pdf'} 
                                                        onChange={(e) => handleUpdateStagedFile(index, 'type', e.target.value)} 
                                                        className={inputClasses + ' text-sm'}
                                                    >
                                                        <option value="pdf">PDF</option>
                                                        <option value="presentation">Presentation</option>
                                                        <option value="document">Document</option>
                                                        <option value="spreadsheet">Spreadsheet</option>
                                                    </select>
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                     <div className="flex justify-between items-center mt-4">
                                        <button onClick={() => setStagedFiles([])} className="glass-button">Clear</button>
                                        <button onClick={handleAddStagedFiles} className="glass-button primary">Add {stagedFiles.length} File(s)</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </Modal>
            )}

            {isSubjectModalOpen && editingSubject && (
                <Modal isOpen={isSubjectModalOpen} onClose={() => setIsSubjectModalOpen(false)} title={'id' in editingSubject ? 'Edit Subject' : 'Add Subject'} maxWidthClass="max-w-lg">
                    <form onSubmit={(e) => handlePrepareSave(e, 'subjects', editingSubject)} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">Subject Name</label>
                            <input type="text" value={editingSubject.name || ''} onChange={(e) => setEditingSubject({...editingSubject, name: e.target.value})} className={inputClasses} required />
                        </div>
                        <div><label className="block text-sm font-medium mb-1">Year</label><select value={editingSubject.year || ''} onChange={(e) => setEditingSubject({...editingSubject, year: e.target.value as Year})} className={inputClasses} required><option value="">Select Year</option><option value="1st year">1st Year</option><option value="2nd year">2nd Year</option><option value="3rd year">3rd Year</option><option value="4th year">4th Year</option></select></div>
                        <div><label className="block text-sm font-medium mb-1">Semester</label><select value={editingSubject.semester || ''} onChange={(e) => setEditingSubject({...editingSubject, semester: (parseInt(e.target.value, 10) || 1) as 1 | 2})} className={inputClasses} required><option value="">Select Semester</option><option value="1">1</option><option value="2">2</option></select></div>
                        <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsSubjectModalOpen(false)} className="glass-button">Cancel</button><button type="submit" className="glass-button primary">Save</button></div>
                    </form>
                </Modal>
            )}
             {isCodingModalOpen && editingCodingTopic && (
                 <Modal 
                    isOpen={isCodingModalOpen} 
                    onClose={() => setIsCodingModalOpen(false)} 
                    title={('id' in editingCodingTopic && editingCodingTopic.id) ? `Edit "${editingCodingTopic.name}"` : 'Add New Coding Topic'} 
                    maxWidthClass="max-w-lg"
                 >
                    <form onSubmit={(e) => handlePrepareSave(e, 'coding', editingCodingTopic)} className="space-y-4">
                        <div><label className="block text-sm font-medium mb-1">Name</label><input type="text" value={editingCodingTopic.name || ''} onChange={(e) => setEditingCodingTopic({...editingCodingTopic, name: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Description</label><textarea value={editingCodingTopic.description || ''} onChange={(e) => setEditingCodingTopic({...editingCodingTopic, description: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Category</label><select value={editingCodingTopic.category || ''} onChange={(e) => setEditingCodingTopic({...editingCodingTopic, category: e.target.value as 'language' | 'concept'})} className={inputClasses} required><option value="">Select Category</option><option value="language">Language</option><option value="concept">Concept</option></select></div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Difficulty</label>
                            <select
                                value={editingCodingTopic.difficulty || ''}
                                onChange={(e) => setEditingCodingTopic({ ...editingCodingTopic, difficulty: e.target.value as CodingTopicDifficulty })}
                                className={inputClasses}
                                required
                            >
                                <option value="">Select Difficulty</option>
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate">Intermediate</option>
                                <option value="Advanced">Advanced</option>
                            </select>
                        </div>
                        <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsCodingModalOpen(false)} className="glass-button">Cancel</button><button type="submit" className="glass-button primary">Save</button></div>
                    </form>
                </Modal>
            )}
             {isNewsModalOpen && editingNewsArticle && (
                 <Modal isOpen={isNewsModalOpen} onClose={() => setIsNewsModalOpen(false)} title={'id' in editingNewsArticle ? 'Edit News Article' : 'Add News Article'} maxWidthClass="max-w-lg">
                    <form onSubmit={(e) => handlePrepareSave(e, 'news', editingNewsArticle)} className="space-y-4">
                        <div><label className="block text-sm font-medium mb-1">Title</label><input type="text" value={editingNewsArticle.title || ''} onChange={(e) => setEditingNewsArticle({...editingNewsArticle, title: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Date</label><input type="date" value={editingNewsArticle.date || ''} onChange={(e) => setEditingNewsArticle({...editingNewsArticle, date: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Excerpt</label><textarea value={editingNewsArticle.excerpt || ''} onChange={(e) => setEditingNewsArticle({...editingNewsArticle, excerpt: e.target.value})} className={inputClasses} required /></div>
                        <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsNewsModalOpen(false)} className="glass-button">Cancel</button><button type="submit" className="glass-button primary">Save</button></div>
                    </form>
                </Modal>
            )}
             {isTeamModalOpen && editingTeamMember && (
                <Modal isOpen={isTeamModalOpen} onClose={() => setIsTeamModalOpen(false)} title={'id' in editingTeamMember ? 'Edit Team Member' : 'Add Team Member'} maxWidthClass="max-w-lg">
                    <form onSubmit={(e) => handlePrepareSave(e, 'team', editingTeamMember)} className="space-y-4">
                        <div><label className="block text-sm font-medium mb-1">Name</label><input type="text" value={editingTeamMember.name || ''} onChange={(e) => setEditingTeamMember({...editingTeamMember, name: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Role</label><input type="text" value={editingTeamMember.role || ''} onChange={(e) => setEditingTeamMember({...editingTeamMember, role: e.target.value})} className={inputClasses} required /></div>
                        <div><label className="block text-sm font-medium mb-1">Bio</label><textarea value={editingTeamMember.bio || ''} onChange={(e) => setEditingTeamMember({...editingTeamMember, bio: e.target.value})} className={inputClasses} required /></div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Profile Image</label>
                            <div className="flex items-center gap-4">
                                {editingTeamMember.imageUrl && (
                                    <img src={editingTeamMember.imageUrl} alt="Preview" className="w-20 h-20 rounded-full object-cover border-2 border-gray-300 dark:border-gray-600" />
                                )}
                                <div className="flex-grow space-y-2">
                                    <label className="w-full cursor-pointer glass-button text-center block">
                                        <span>Upload Image</span>
                                        <input type="file" accept="image/*" onChange={handleTeamImageFileChange} className="hidden" ref={teamImageFileRef} />
                                    </label>
                                    <input 
                                        type="text" 
                                        value={editingTeamMember.imageUrl || ''} 
                                        onChange={(e) => setEditingTeamMember({...editingTeamMember, imageUrl: e.target.value})} 
                                        className={inputClasses}
                                        required
                                        placeholder={'Or paste image URL'}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsTeamModalOpen(false)} className="glass-button">Cancel</button><button type="submit" className="glass-button primary">Save</button></div>
                    </form>
                </Modal>
            )}
            {isUserModalOpen && editingUser && (
                <Modal isOpen={isUserModalOpen} onClose={() => setIsUserModalOpen(false)} title={('idNumber' in editingUser && editingUser.idNumber) ? 'Edit User' : 'Add User'} maxWidthClass="max-w-lg">
                    <form onSubmit={(e) => handlePrepareSave(e, 'users', editingUser)} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">Name</label>
                            <input type="text" value={editingUser.name || ''} onChange={(e) => setEditingUser({...editingUser, name: e.target.value})} className={inputClasses} required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Student ID Number</label>
                            <input type="text" value={editingUser.idNumber || ''} onChange={(e) => setEditingUser({...editingUser, idNumber: e.target.value})} className={inputClasses} required disabled={'idNumber' in editingUser && !!editingUser.idNumber} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Year</label>
                            <select value={editingUser.year || ''} onChange={(e) => setEditingUser({...editingUser, year: e.target.value as Year})} className={inputClasses}>
                                <option value="">Select Year</option>
                                <option value="1st year">1st Year</option>
                                <option value="2nd year">2nd Year</option>
                                <option value="3rd year">3rd Year</option>
                                <option value="4th year">4th Year</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1">Interests</label>
                            <input type="text" placeholder="Comma-separated, e.g., AI/ML, Web Dev" value={editingUser.interests?.join(', ') || ''} onChange={(e) => setEditingUser({...editingUser, interests: e.target.value.split(',').map(i => i.trim())})} className={inputClasses} />
                        </div>
                        <div className="flex justify-end gap-3 pt-4">
                            <button type="button" onClick={() => setIsUserModalOpen(false)} className="glass-button">Cancel</button>
                            <button type="submit" className="glass-button primary">Save</button>
                        </div>
                    </form>
                </Modal>
            )}

            <ConfirmationModal
                isOpen={!!itemToDelete}
                onClose={() => setItemToDelete(null)}
                onConfirm={confirmDelete}
                title="Confirm Deletion"
                message={itemToDelete && ('ids' in itemToDelete || 'fileId' in itemToDelete) ? 
                    (itemToDelete.fileId ? "Are you sure you want to delete this file?" : `Are you sure you want to delete these ${itemToDelete.ids?.length} items? This action cannot be undone.`) :
                    "Are you sure you want to delete this item? This action cannot be undone."}
                confirmButtonText="Delete"
            />
            <ConfirmationModal
                isOpen={isSaveConfirmationOpen}
                onClose={handleCancelSave}
                onConfirm={handleConfirmSave}
                title="Confirm Save"
                message="Are you sure you want to save these changes?"
                confirmButtonText="Save"
                confirmButtonClass="bg-purple-600 text-white hover:bg-purple-700"
            />
            {isTimeoutWarningModalOpen && (
                <Modal isOpen={isTimeoutWarningModalOpen} onClose={handleStayLoggedIn} title="Are you still there?">
                    <p className="text-gray-600 dark:text-gray-300 mb-6">You will be logged out due to inactivity in {warningCountdown} seconds.</p>
                    <div className="flex justify-end gap-3">
                        <button onClick={onLogout} className="px-4 py-2 text-sm font-semibold rounded-lg glass-button">Logout</button>
                        <button onClick={handleStayLoggedIn} className="px-4 py-2 text-sm font-semibold rounded-lg glass-button primary">Stay Logged In</button>
                    </div>
                </Modal>
            )}
        </div>
    );
};
