
import React, { useState, useEffect, useRef } from 'react';
import { ThemeToggle } from './ThemeToggle';
import { UserIcon } from './icons/ProfileIcons';
import { SparklesIcon } from './icons/SparklesIcon';
import { MenuIcon, CloseIcon } from './icons/MenuIcons';
import { LogoutIcon } from './icons/UserMenuIcons';
import { BookmarkIcon } from './icons/ActionIcons';
import type { User } from '../types';
import { LockIcon } from './icons/LockIcon';
import { useAppContext } from '../context/DataContext';

interface HeaderProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
    currentView: string;
    theme: 'light' | 'dark';
    toggleTheme: () => void;
    setIsAISearchOpen: (isOpen: boolean) => void;
    hasNewNews: boolean;
    onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ setCurrentView, currentView, theme, toggleTheme, setIsAISearchOpen, hasNewNews, onLogout }) => {
    const { user } = useAppContext();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);

    const dropdownRef = useRef<HTMLDivElement>(null);
    const profileButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll(); // Check on initial render

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    useEffect(() => {
        const originalStyle = window.getComputedStyle(document.body).overflow;
        if (isMobileMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = originalStyle;
        }
        return () => {
            document.body.style.overflow = originalStyle;
        };
    }, [isMobileMenuOpen]);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                dropdownRef.current && !dropdownRef.current.contains(event.target as Node) &&
                profileButtonRef.current && !profileButtonRef.current.contains(event.target as Node)
            ) {
                setIsProfileDropdownOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleDropdownNav = (view: 'profile' | 'saved') => {
        setCurrentView(view);
        setIsProfileDropdownOpen(false);
    };

    const handleLogoutClick = () => {
        onLogout();
        setIsProfileDropdownOpen(false);
    };

    const navLinkClasses = (view: string) => 
        `relative transition-colors pb-1 border-b-2 font-semibold focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 rounded-sm flex items-center gap-1.5 ${
            currentView === view 
                ? 'text-purple-600 dark:text-purple-400 border-purple-600 dark:border-purple-400' 
                : 'text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 border-transparent'
        }`;
    
    const iconButtonClasses = "w-10 h-10 rounded-full p-2 flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-black/10 dark:hover:bg-white/10 transition-colors";

    const handleMobileNavClick = (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => {
        setCurrentView(view);
        setIsMobileMenuOpen(false);
    };

    const mobileNavLinkClasses = (view: string) => 
        `block w-full text-left px-4 py-3 rounded-md text-lg font-medium transition-colors ${
            currentView === view 
                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-200' 
                : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
        }`;

    return (
        <>
            <header className={`sticky top-0 z-30 transition-all duration-300 ${isScrolled ? 'glass-effect shadow-md' : ''}`}>
                <div className="container mx-auto px-6 lg:px-8 flex justify-between items-center h-20">
                    {/* Left Group: Logo + User Info */}
                    <div className="flex items-center gap-4">
                        {/* Logo */}
                        <button onClick={() => setCurrentView('home')} className="flex items-center gap-3 cursor-pointer p-1 rounded-lg transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-transparent focus:ring-purple-500" title="Go to Home (Alt+1)">
                            <img src="https://i.ibb.co/L5xS7v2/lpu-studio-logo.png" alt="LPU Studio Logo" className="h-10 object-contain" />
                            <span className="text-xl font-bold text-gray-800 dark:text-white tracking-wide">LPU Studio</span>
                        </button>
                        {/* User Info */}
                        {user.name !== 'Guest' && (
                            <div className="hidden lg:flex items-center gap-3 border-l-2 border-white/20 dark:border-white/10 pl-4">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 overflow-hidden flex-shrink-0">
                                    {user.profilePicture ? (
                                        <img src={user.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                                    ) : (
                                        <span className="font-bold text-lg">{user.name.charAt(0).toUpperCase()}</span>
                                    )}
                                </div>
                                <div>
                                    <p className="font-semibold text-sm text-gray-800 dark:text-white leading-tight truncate">{user.name}</p>
                                    {user.idNumber && (
                                        <p className="text-xs text-gray-500 dark:text-gray-400 leading-tight">{user.idNumber}</p>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                    
                    {/* Right Group: Nav + Icons */}
                    <div className="hidden md:flex items-center">
                        {/* Navigation */}
                        <nav className="flex items-center gap-8">
                            <button onClick={() => setCurrentView('home')} className={navLinkClasses('home')} title="Go to Home (Alt+1)">Home</button>
                            <button onClick={() => setCurrentView('resources')} className={navLinkClasses('resources')} title="Go to Resources (Alt+2)">Resources</button>
                            <button onClick={() => setCurrentView('coding')} className={navLinkClasses('coding')} title="Go to Coding (Alt+3)">
                                Coding
                                {user.name === 'Guest' && <LockIcon className="w-4 h-4 text-gray-400" />}
                            </button>
                            <button onClick={() => setCurrentView('news')} className={navLinkClasses('news')} title="Go to News (Alt+4)">
                                News
                                {user.name === 'Guest' && <LockIcon className="w-4 h-4 text-gray-400" />}
                                {hasNewNews && (
                                    <span className="absolute -top-1 -right-1 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white/80 dark:ring-gray-800/80"></span>
                                )}
                            </button>
                            <button onClick={() => setCurrentView('saved')} className={navLinkClasses('saved')} title="Go to Saved Items (Alt+5)">Saved</button>
                            <button onClick={() => setCurrentView('about')} className={navLinkClasses('about')} title="Go to About (Alt+6)">About</button>
                        </nav>

                        {/* Divider */}
                        <div className="w-px h-6 bg-white/20 dark:bg-white/10 mx-6"></div>

                        {/* Icons */}
                        <div className="flex items-center gap-2">
                            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
                            <button onClick={() => setIsAISearchOpen(true)} className={iconButtonClasses} aria-label="Open AI Search">
                            <SparklesIcon className="w-6 h-6" />
                            </button>
                            <div className="relative">
                                <button
                                    ref={profileButtonRef}
                                    onClick={() => setIsProfileDropdownOpen(prev => !prev)}
                                    className="w-10 h-10 rounded-full flex items-center justify-center bg-black/5 dark:bg-white/5 text-gray-700 dark:text-gray-300 hover:ring-2 hover:ring-offset-2 hover:ring-offset-transparent hover:ring-purple-500 transition-all overflow-hidden"
                                    aria-label="Open User Profile Menu"
                                    id="user-menu-button"
                                    aria-haspopup="true"
                                    aria-expanded={isProfileDropdownOpen}
                                >
                                    {user.profilePicture ? (
                                        <img src={user.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                                    ) : user.name !== 'Guest' ? (
                                        <span className="font-bold text-lg">{user.name.charAt(0).toUpperCase()}</span>
                                    ) : (
                                        <UserIcon className="w-6 h-6" />
                                    )}
                                </button>
                                {isProfileDropdownOpen && (
                                    <div
                                        ref={dropdownRef}
                                        className="absolute top-full right-0 mt-3 w-64 glass-effect rounded-xl shadow-lg z-40 origin-top-right overflow-hidden animate-slide-in-bottom"
                                        role="menu"
                                        aria-orientation="vertical"
                                        aria-labelledby="user-menu-button"
                                    >
                                        {user.name !== 'Guest' ? (
                                            <>
                                                <div className="px-4 py-3 border-b border-white/20 dark:border-white/10">
                                                    <p className="font-bold text-gray-800 dark:text-white truncate" role="none">{user.name}</p>
                                                    {user.idNumber && <p className="text-sm text-gray-600 dark:text-gray-400" role="none">{user.idNumber}</p>}
                                                </div>
                                                <div className="py-2" role="none">
                                                    <button onClick={() => handleDropdownNav('profile')} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors" role="menuitem" title="Go to Profile (Alt+8)">
                                                        <UserIcon className="w-5 h-5" />
                                                        <span>View Profile</span>
                                                    </button>
                                                    <button onClick={() => handleDropdownNav('saved')} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors" role="menuitem" title="Go to Saved Items (Alt+5)">
                                                        <BookmarkIcon className="w-5 h-5" />
                                                        <span>Saved Items</span>
                                                    </button>
                                                    <div className="my-1 border-t border-white/20 dark:border-white/10"></div>
                                                    <button onClick={handleLogoutClick} className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-500/10 transition-colors" role="menuitem">
                                                        <LogoutIcon className="w-5 h-5" />
                                                        <span>Logout</span>
                                                    </button>
                                                </div>
                                            </>
                                        ) : (
                                            <div className="p-4">
                                                <p className="text-center text-sm text-gray-600 dark:text-gray-400 mb-3">You are browsing as a guest.</p>
                                                <button onClick={() => handleDropdownNav('profile')} className="w-full glass-button primary" title="Go to Profile (Alt+8)">
                                                    Create Profile
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Mobile Menu Button */}
                    <div className="md:hidden">
                        <button
                            onClick={() => setIsMobileMenuOpen(true)}
                            className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white p-2 rounded-md"
                            aria-expanded={isMobileMenuOpen}
                            aria-controls="mobile-menu"
                        >
                            <span className="sr-only">Open main menu</span>
                            <MenuIcon />
                        </button>
                    </div>
                </div>
            </header>

            {/* Mobile Menu Backdrop */}
            <div
                className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-300 ease-in-out md:hidden ${
                    isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
                aria-hidden="true"
            ></div>

            {/* Mobile Menu Panel */}
            <div
                id="mobile-menu"
                className={`fixed top-0 right-0 h-full w-4/5 max-w-xs glass-effect shadow-2xl z-50 transform transition-transform duration-300 ease-in-out md:hidden ${
                    isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
                }`}
                role="dialog"
                aria-modal="true"
                aria-labelledby="mobile-menu-title"
            >
                <div className="p-4 flex flex-col h-full">
                    {/* Menu Header */}
                    <div className="flex justify-between items-center mb-8">
                        <h2 id="mobile-menu-title" className="text-xl font-bold text-gray-800 dark:text-white">Menu</h2>
                        <button
                            onClick={() => setIsMobileMenuOpen(false)}
                            className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white p-2 rounded-md"
                        >
                            <span className="sr-only">Close menu</span>
                            <CloseIcon />
                        </button>
                    </div>

                    {/* Navigation */}
                    <nav className="flex-grow space-y-2">
                        <button onClick={() => handleMobileNavClick('home')} className={mobileNavLinkClasses('home')} title="Go to Home (Alt+1)">Home</button>
                        <button onClick={() => handleMobileNavClick('resources')} className={mobileNavLinkClasses('resources')} title="Go to Resources (Alt+2)">Resources</button>
                        <button onClick={() => handleMobileNavClick('coding')} className={`${mobileNavLinkClasses('coding')} flex items-center gap-2`} title="Go to Coding (Alt+3)">
                            <span>Coding</span>
                            {user.name === 'Guest' && <LockIcon className="w-4 h-4 text-gray-400" />}
                        </button>
                        <button onClick={() => handleMobileNavClick('news')} className={`${mobileNavLinkClasses('news')} flex justify-between items-center`} title="Go to News (Alt+4)">
                            <span className="flex items-center gap-2">
                                <span>News</span>
                                {user.name === 'Guest' && <LockIcon className="w-4 h-4 text-gray-400" />}
                            </span>
                            {hasNewNews && (
                                <span className="block h-2.5 w-2.5 rounded-full bg-red-500"></span>
                            )}
                        </button>
                        <button onClick={() => handleMobileNavClick('saved')} className={mobileNavLinkClasses('saved')} title="Go to Saved Items (Alt+5)">Saved Items</button>
                        <button onClick={() => handleMobileNavClick('about')} className={mobileNavLinkClasses('about')} title="Go to About (Alt+6)">About Us</button>
                        <button onClick={() => handleMobileNavClick('admin')} className={mobileNavLinkClasses('admin')} title="Go to Admin (Alt+7)">Admin</button>
                    </nav>

                    {/* Menu Footer */}
                    <div className="space-y-4">
                        <div className="border-t border-white/20 dark:border-white/10"></div>
                        <button onClick={() => handleMobileNavClick('profile')} className={`${mobileNavLinkClasses('profile')} flex items-center gap-3`} title="Go to Profile (Alt+8)">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-black/5 dark:bg-white/5 text-gray-700 dark:text-gray-300 overflow-hidden flex-shrink-0">
                                {user.profilePicture ? (
                                    <img src={user.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                                ) : user.name !== 'Guest' ? (
                                    <span className="font-bold text-sm">{user.name.charAt(0).toUpperCase()}</span>
                                ) : (
                                    <UserIcon className="w-5 h-5" />
                                )}
                            </div>
                            <span>Your Profile</span>
                        </button>
                        <button onClick={() => { setIsAISearchOpen(true); setIsMobileMenuOpen(false); }} className={`${mobileNavLinkClasses('ai-search')} flex items-center gap-3`}>
                            <SparklesIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                            <span>AI Search</span>
                        </button>
                        <div className="border-t border-white/20 dark:border-white/10"></div>
                        <div className="px-4 py-3 flex justify-between items-center">
                            <span className="font-medium text-gray-700 dark:text-gray-300 text-lg">Theme</span>
                            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};