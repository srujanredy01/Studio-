
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ShareModal } from './ShareModal';
import { ShareIcon } from './icons/ShareIcons';
import { BookmarkIcon } from './icons/ActionIcons';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/ProfileIcons';
import type { NewsArticle, User } from '../types';
import { trackEvent } from '../analytics';
import { getSavedNewsIdsForUser, saveNewsIdsForUser } from '../data/userData';
import { useAppContext } from '../context/DataContext';

const filterOptions = ['All', 'This Week', 'This Month', 'This Year'];
const ARTICLES_PER_PAGE = 10;

interface NewsProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

export const News: React.FC<NewsProps> = ({ setCurrentView }) => {
    const { newsArticles, user } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [activeFilter, setActiveFilter] = useState('All');
    const [filteredArticles, setFilteredArticles] = useState(newsArticles);
    const [savedArticleIds, setSavedArticleIds] = useState<number[]>(() => getSavedNewsIdsForUser(user.idNumber));
    const [shareModalArticle, setShareModalArticle] = useState<NewsArticle | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    // State for AI summaries
    const [summaries, setSummaries] = useState<Record<number, { text?: string; isLoading: boolean; error?: string }>>({});
    const [visibleSummaryId, setVisibleSummaryId] = useState<number | null>(null);

    // Resync saved state when user changes
    useEffect(() => {
        setSavedArticleIds(getSavedNewsIdsForUser(user.idNumber));
    }, [user.idNumber]);

    const toggleSaveArticle = (id: number) => {
        if (user.name === 'Guest' || !user.idNumber) {
            setCurrentView('profile');
            return;
        }

        const currentSaved = getSavedNewsIdsForUser(user.idNumber);
        const isSaving = !currentSaved.includes(id);
        let updatedSaved;
        if (isSaving) {
            updatedSaved = [...currentSaved, id];
        } else {
            updatedSaved = currentSaved.filter(savedId => savedId !== id);
        }
        saveNewsIdsForUser(user.idNumber, updatedSaved);
        setSavedArticleIds(updatedSaved);
        const article = newsArticles.find(a => a.id === id);
        trackEvent('featureUse', isSaving ? 'save_article' : 'unsave_article', { articleId: id, articleTitle: article?.title });
    };

    const handleReadMoreClick = (article: NewsArticle) => {
        if (user.name === 'Guest') {
            setCurrentView('profile');
            return;
        }
        trackEvent('featureUse', 'read_more_article', { articleId: article.id, articleTitle: article.title });
        alert(`Full Article:\n\nTitle: ${article.title}\n\n${article.excerpt}`);
    };

    const handleSummarize = async (article: NewsArticle) => {
        // If the summary for this article is already visible, hide it.
        if (visibleSummaryId === article.id) {
            setVisibleSummaryId(null);
            return;
        }

        // Track the feature usage only when generating a new summary
        trackEvent('featureUse', 'ai_summary', { articleId: article.id, articleTitle: article.title });

        // If the summary has already been generated and cached, just show it.
        if (summaries[article.id]?.text || summaries[article.id]?.error) {
            setVisibleSummaryId(article.id);
            return;
        }

        // Set loading state for this specific article
        setSummaries(prev => ({
            ...prev,
            [article.id]: { isLoading: true }
        }));
        setVisibleSummaryId(null); // Hide any other open summary

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Summarize the following news article excerpt in 1-2 concise sentences. Capture the main point and, if appropriate, add a call to action like "Read more for details.".\n\nTitle: ${article.title}\nExcerpt: ${article.excerpt}`;

            const response: GenerateContentResponse = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
            });
            const summaryText = response.text;
            
            if (!summaryText || summaryText.trim() === '') {
                throw new Error("Model returned an empty summary.");
            }

            setSummaries(prev => ({
                ...prev,
                [article.id]: { text: summaryText, isLoading: false }
            }));
            setVisibleSummaryId(article.id);
        } catch (e) {
            console.error("AI Summary Error:", e);
            const errorMessage = e instanceof Error ? e.message : "Failed to generate summary.";
            setSummaries(prev => ({
                ...prev,
                [article.id]: { error: errorMessage, isLoading: false }
            }));
            setVisibleSummaryId(article.id); // Show the error message
        }
    };


    useEffect(() => {
        let articles = [...newsArticles];
        const now = new Date();

        // Filter by date
        if (activeFilter !== 'All') {
            articles = articles.filter(article => {
                const articleDate = new Date(article.date);
                if (isNaN(articleDate.getTime())) return false;

                switch (activeFilter) {
                    case 'This Week':
                        const oneWeekAgo = new Date();
                        oneWeekAgo.setDate(now.getDate() - 7);
                        return articleDate >= oneWeekAgo;
                    case 'This Month':
                        return articleDate.getMonth() === now.getMonth() && articleDate.getFullYear() === now.getFullYear();
                    case 'This Year':
                        return articleDate.getFullYear() === now.getFullYear();
                    default:
                        return true;
                }
            });
        }

        // Filter by search term
        if (searchTerm.trim() !== '') {
            const lowercasedTerm = searchTerm.toLowerCase();
            articles = articles.filter(article =>
                article.title.toLowerCase().includes(lowercasedTerm) ||
                article.excerpt.toLowerCase().includes(lowercasedTerm)
            );
        }

        setFilteredArticles(articles.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        setCurrentPage(1); // Reset to the first page whenever filters change

    }, [searchTerm, activeFilter, newsArticles]);

    // Pagination Logic
    const totalPages = Math.ceil(filteredArticles.length / ARTICLES_PER_PAGE);
    const startIndex = (currentPage - 1) * ARTICLES_PER_PAGE;
    const endIndex = startIndex + ARTICLES_PER_PAGE;
    const articlesForCurrentPage = filteredArticles.slice(startIndex, endIndex);

    const handleNextPage = () => {
        if (currentPage < totalPages) {
            setCurrentPage(prev => prev + 1);
        }
    };

    const handlePreviousPage = () => {
        if (currentPage > 1) {
            setCurrentPage(prev => prev - 1);
        }
    };


    return (
        <div className="min-h-[calc(100vh-280px)]">
            <section className="py-16">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl font-bold text-gray-800 dark:text-white">News & Updates</h1>
                </div>
            </section>
            
            <section className="py-12">
                <div className="container mx-auto px-6 lg:px-8">
                    {/* Search Bar */}
                    <div className="mb-8 max-w-2xl mx-auto">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <input
                                type="text"
                                placeholder="Search articles by keyword..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="block w-full glass-effect rounded-full py-3 pl-12 pr-4 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            />
                        </div>
                    </div>

                     {/* Filter Buttons */}
                    <div className="mb-12 flex flex-wrap justify-center gap-3">
                         {filterOptions.map(option => (
                           <button
                                key={option}
                                onClick={() => setActiveFilter(option)}
                                className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 glass-button ${
                                    activeFilter === option 
                                        ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 border-transparent'
                                        : ''
                                }`}
                            >
                                {option}
                            </button>
                        ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 min-h-[300px]">
                        {articlesForCurrentPage.length > 0 ? (
                            articlesForCurrentPage.map((article) => {
                                const isSaved = savedArticleIds.includes(article.id);
                                const isRecommended = user.interests?.some(interest => 
                                    article.title.toLowerCase().includes(interest.split('/')[0].toLowerCase().trim()) ||
                                    article.excerpt.toLowerCase().includes(interest.split('/')[0].toLowerCase().trim())
                                ) ?? false;
                                const summaryState = summaries[article.id];

                                return (
                                <div key={article.id} className="relative glass-effect aurora-effect rounded-lg overflow-hidden flex flex-col transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl dark:hover:shadow-xl dark:hover:shadow-purple-500/25">
                                    {isRecommended && (
                                        <span className="absolute top-4 right-4 text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 px-2.5 py-0.5 rounded-full z-10">Recommended</span>
                                    )}
                                    <div className="p-6 flex-grow">
                                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{new Date(article.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-3">{article.title}</h3>
                                        <button
                                            className="text-left text-gray-600 dark:text-gray-300 leading-relaxed hover:text-gray-800 dark:hover:text-gray-100 transition-colors"
                                            onClick={() => handleReadMoreClick(article)}
                                        >
                                            {article.excerpt}
                                        </button>
                                    </div>
                                    <div className="p-4 bg-black/5 dark:bg-white/5 mt-auto flex items-center justify-between flex-wrap gap-2">
                                        <button onClick={() => handleReadMoreClick(article)} className="font-semibold text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 transition-colors">
                                            Read More &rarr;
                                        </button>
                                        <div className="flex items-center gap-1">
                                            <button
                                                onClick={() => handleSummarize(article)}
                                                disabled={summaryState?.isLoading}
                                                className={`flex items-center gap-1.5 px-3 py-1 text-sm rounded-full font-semibold transition-colors disabled:opacity-70 disabled:cursor-wait glass-button`}
                                                aria-label={summaryState?.isLoading ? 'Generating summary' : (visibleSummaryId === article.id ? 'Hide summary' : 'Generate AI summary')}
                                            >
                                                {summaryState?.isLoading ? <SpinnerIcon className="w-4 h-4" /> : <SparklesIcon className="w-4 h-4" />}
                                                {summaryState?.isLoading ? 'Working...' : (visibleSummaryId === article.id ? 'Hide' : 'Summarize')}
                                            </button>
                                            <div className="relative group">
                                                <button 
                                                    onClick={() => toggleSaveArticle(article.id)}
                                                    className={`flex items-center gap-1.5 px-3 py-1 text-sm rounded-full font-semibold transition-colors glass-button ${
                                                        isSaved 
                                                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300' 
                                                            : ''
                                                    }`}
                                                    aria-describedby={`tooltip-save-${article.id}`}
                                                >
                                                    <BookmarkIcon className="w-4 h-4 transition-transform duration-200 group-active:scale-125" filled={isSaved} />
                                                    {isSaved ? 'Saved' : 'Save'}
                                                </button>
                                                <div
                                                    id={`tooltip-save-${article.id}`}
                                                    role="tooltip"
                                                    className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max whitespace-nowrap px-2 py-1 bg-gray-800 dark:bg-black text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 shadow-lg"
                                                >
                                                    {isSaved ? 'Remove from saved' : 'Save for later'}
                                                </div>
                                            </div>
                                            <button
                                                onClick={() => setShareModalArticle(article)}
                                                className="p-2 rounded-full text-gray-500 hover:bg-black/10 hover:text-gray-800 dark:text-gray-400 dark:hover:bg-white/10 dark:hover:text-white transition-colors"
                                                aria-label="Share article"
                                            >
                                                <ShareIcon className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </div>
                                     {visibleSummaryId === article.id && (
                                        <div className="p-6 border-t border-white/20 dark:border-white/10">
                                            {summaryState?.text && (
                                                <div className="bg-purple-500/10 p-4 rounded-lg">
                                                    <h4 className="font-bold text-sm text-gray-700 dark:text-gray-200 flex items-center gap-2 mb-2">
                                                        <SparklesIcon className="w-4 h-4 text-purple-600" />
                                                        AI Summary
                                                    </h4>
                                                    <p className="text-sm text-gray-600 dark:text-gray-300">
                                                        {summaryState.text}
                                                    </p>
                                                </div>
                                            )}
                                            {summaryState?.error && (
                                                <div className="bg-red-50 dark:bg-red-900/50 p-4 rounded-lg text-sm text-red-700 dark:text-red-300">
                                                    {summaryState.error}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                                )
                            })
                        ) : (
                             <div className="text-center col-span-full text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center">
                                <h3 className="text-2xl font-semibold mb-2">No Articles Found</h3>
                                <p>Try adjusting your search or filter criteria.</p>
                            </div>
                        )}
                    </div>

                    {totalPages > 1 && (
                        <div className="mt-12 flex justify-center items-center gap-4">
                            <button
                                onClick={handlePreviousPage}
                                disabled={currentPage === 1}
                                className="px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 glass-button disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                &larr; Previous
                            </button>
                            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                                Page {currentPage} of {totalPages}
                            </span>
                            <button
                                onClick={handleNextPage}
                                disabled={currentPage === totalPages}
                                className="px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 glass-button disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Next &rarr;
                            </button>
                        </div>
                    )}

                </div>
            </section>
            {shareModalArticle && (
                <ShareModal 
                    item={shareModalArticle}
                    onClose={() => setShareModalArticle(null)}
                />
            )}
        </div>
    );
};