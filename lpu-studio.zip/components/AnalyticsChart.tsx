import React from 'react';

interface ChartDataItem {
  label: string;
  value: number;
}

interface AnalyticsChartProps {
  title: string;
  data: ChartDataItem[];
}

export const AnalyticsChart: React.FC<AnalyticsChartProps> = ({ title, data }) => {
    const maxValue = Math.max(...data.map(item => item.value), 0);

    // Capitalize and replace underscores for better readability
    const formatLabel = (label: string) => {
        return label
            .replace(/_/g, ' ')
            .replace(/\b\w/g, char => char.toUpperCase());
    };

    return (
        <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">{title}</h3>
            <div className="space-y-4">
                {data.length > 0 ? (
                    data.map(({ label, value }) => (
                        <div key={label} className="grid grid-cols-3 items-center gap-4 text-sm">
                            <span className="truncate text-gray-600 dark:text-gray-300" title={formatLabel(label)}>
                                {formatLabel(label)}
                            </span>
                            <div className="col-span-2 flex items-center gap-2">
                                <div className="flex-grow bg-gray-200 dark:bg-gray-600 rounded-full h-4 overflow-hidden">
                                    <div
                                        className="bg-gradient-to-r from-purple-500 to-pink-500 h-4 rounded-full transition-all duration-500 ease-out"
                                        style={{ width: `${maxValue > 0 ? (value / maxValue) * 100 : 0}%` }}
                                    ></div>
                                </div>
                                <span className="font-semibold w-8 text-right text-gray-700 dark:text-gray-200">{value}</span>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-gray-500 dark:text-gray-400">No data for this chart.</p>
                )}
            </div>
        </div>
    );
};
