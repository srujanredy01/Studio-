import React, { useState, useEffect, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ConfirmationModal } from './ConfirmationModal';
import { ShareModal } from './ShareModal';
import { Modal } from './Modal';
import { BookmarkIcon, TrashIcon } from './icons/ActionIcons';
import { ShareIcon } from './icons/ShareIcons';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/ProfileIcons';
import type { NewsArticle, ResourceFile, CodingTopic, Year, SavedPracticeProblem, User } from '../types';
import { trackEvent } from '../analytics';
import { 
    getSavedNewsIdsForUser, saveNewsIdsForUser,
    getSavedResourceIdsForUser, saveResourceIdsForUser,
    getSavedCodingTopicIdsForUser, saveCodingTopicIdsForUser,
    getSavedPracticeProblemsForUser, savePracticeProblemsForUser
} from '../data/userData';
import { useAppContext } from '../context/DataContext';

const renderMarkdown = (text: string): string => {
    let processedText = text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    const blocks = processedText.split(/(```[\s\S]*?```)/g).map(block => block.trim()).filter(Boolean);

    const htmlBlocks = blocks.map(block => {
        if (block.startsWith('```')) {
            const language = block.match(/```(\w*)/)?.[1] || '';
            const code = block.replace(/```\w*\n/, '').replace(/```$/, '').trim();
            return `<pre><code class="language-${language} p-4 block overflow-x-auto bg-gray-800 text-white rounded-md">${code.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code></pre>`;
        }
        
        const lines = block.split('\n');
        if (lines[0].startsWith('### ')) return `<h3>${lines[0].substring(4)}</h3>`;
        if (lines[0].startsWith('## ')) return `<h2>${lines[0].substring(3)}</h2>`;
        if (lines[0].startsWith('# ')) return `<h1>${lines[0].substring(2)}</h1>`;
        
        const isUnorderedList = lines.every(line => line.trim().startsWith('* ') || line.trim().startsWith('- '));
        if (isUnorderedList) {
            const listItems = lines.map(line => `<li>${line.trim().substring(2)}</li>`).join('');
            return `<ul>${listItems}</ul>`;
        }

        const isOrderedList = lines.every(line => line.trim().match(/^\d+\.\s/));
        if(isOrderedList) {
            const listItems = lines.map(line => `<li>${line.trim().replace(/^\d+\.\s/, '')}</li>`).join('');
            return `<ol>${listItems}</ol>`;
        }

        return `<p>${lines.join('<br />')}</p>`;
    });

    return htmlBlocks.join('');
};


// Props for the new unified component
interface SavedItemsProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
    setSelectedCodingTopic: (topic: CodingTopic) => void;
}

// Highlight component for search results
const Highlight: React.FC<{ text: string, highlight: string }> = ({ text, highlight }) => {
    if (!highlight.trim()) {
        return <>{text}</>;
    }
    const regex = new RegExp(`(${highlight.replace(/[.*+?^${()}|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return (
        <>
            {parts.map((part, i) =>
                part.toLowerCase() === highlight.toLowerCase() ? (
                    <mark key={i} className="bg-purple-200 dark:bg-purple-500/50 rounded-sm p-0.5 text-black dark:text-white">
                        {part}
                    </mark>
                ) : (
                    part
                )
            )}
        </>
    );
};

const sortOptions = {
    news: [
        { value: 'date-desc', label: 'Date (Newest)' },
        { value: 'date-asc', label: 'Date (Oldest)' },
        { value: 'title-asc', label: 'Title (A-Z)' },
        { value: 'title-desc', label: 'Title (Z-A)' },
    ],
    resource: [
        { value: 'name-asc', label: 'Name (A-Z)' },
        { value: 'name-desc', label: 'Name (Z-A)' },
    ],
    coding: [
        { value: 'name-asc', label: 'Name (A-Z)' },
        { value: 'name-desc', label: 'Name (Z-A)' },
    ],
    practiceProblem: [
        { value: 'topic-asc', label: 'Topic (A-Z)' },
        { value: 'topic-desc', label: 'Topic (Z-A)' },
    ]
};

const dateFilterOptions = ['All', 'This Week', 'This Month', 'This Year'];
const yearOptions: ('All' | Year)[] = ['All', '1st year', '2nd year', '3rd year', '4th year'];
const semesterOptions: ('All' | 1 | 2)[] = ['All', 1, 2];
const codingCategoryOptions: ('all' | 'language' | 'concept')[] = ['all', 'language', 'concept'];


// The main component
export const SavedItems: React.FC<SavedItemsProps> = ({ setCurrentView, setSelectedCodingTopic }) => {
    const { user, newsArticles: allArticles, resources: allResources, codingTopics: allCodingTopics } = useAppContext();
    
    // State for saved items
    const [savedArticles, setSavedArticles] = useState<NewsArticle[]>([]);
    const [savedResources, setSavedResources] = useState<ResourceFile[]>([]);
    const [savedCodingTopics, setSavedCodingTopics] = useState<CodingTopic[]>([]);
    const [savedPracticeProblems, setSavedPracticeProblems] = useState<SavedPracticeProblem[]>([]);
    
    // UI State
    const [activeTab, setActiveTab] = useState<'news' | 'resource' | 'coding' | 'practiceProblem'>('news');
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOrder, setSortOrder] = useState('date-desc');

    // Filter states
    const [activeDateFilter, setActiveDateFilter] = useState('All');
    const [resourceYearFilter, setResourceYearFilter] = useState<'All' | Year>('All');
    const [resourceSemesterFilter, setResourceSemesterFilter] = useState<'All' | 1 | 2>('All');
    const [codingCategoryFilter, setCodingCategoryFilter] = useState<'all' | 'language' | 'concept'>('all');
    
    // State for modals and animations
    const [itemToRemove, setItemToRemove] = useState<{ type: 'news' | 'resource' | 'coding' | 'practiceProblem', id: number | string } | null>(null);
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    const [shareModalItem, setShareModalItem] = useState<NewsArticle | ResourceFile | null>(null);
    const [justRemovedId, setJustRemovedId] = useState<number | string | null>(null);

    // State for practice problem modal
    const [practiceModalProblem, setPracticeModalProblem] = useState<SavedPracticeProblem | null>(null);
    const [userCode, setUserCode] = useState<string>('');
    const [runResult, setRunResult] = useState<{ output: string; isLoading: boolean; error?: string } | null>(null);
    const [solution, setSolution] = useState<{ text: string; isLoading: boolean; error?: string } | null>(null);

    // Load saved items from localStorage on mount or when user changes
    useEffect(() => {
        if (!user.idNumber) {
            setSavedArticles([]);
            setSavedResources([]);
            setSavedCodingTopics([]);
            setSavedPracticeProblems([]);
            return;
        }
        setSavedArticles(allArticles.filter(article => getSavedNewsIdsForUser(user.idNumber).includes(article.id)));
        setSavedResources(allResources.filter(resource => getSavedResourceIdsForUser(user.idNumber).includes(resource.id)));
        setSavedCodingTopics(allCodingTopics.filter(topic => getSavedCodingTopicIdsForUser(user.idNumber).includes(topic.id)));
        setSavedPracticeProblems(getSavedPracticeProblemsForUser(user.idNumber));
    }, [allArticles, allResources, allCodingTopics, user.idNumber]);

    // Handlers for removing items
    const handleRemoveClick = (type: 'news' | 'resource' | 'coding' | 'practiceProblem', id: number | string) => {
        setItemToRemove({ type, id });
        setIsConfirmModalOpen(true);
    };

    const handleConfirmRemove = () => {
        if (!itemToRemove || !user.idNumber) return;
        const { type, id } = itemToRemove;

        setJustRemovedId(id); // Trigger fade-out animation
        setIsConfirmModalOpen(false);

        // Delay the actual state update to allow animation to complete
        setTimeout(() => {
            switch (type) {
                case 'news':
                    const newsIds = getSavedNewsIdsForUser(user.idNumber).filter(savedId => savedId !== id);
                    saveNewsIdsForUser(user.idNumber, newsIds);
                    setSavedArticles(prev => prev.filter(item => item.id !== id));
                    break;
                case 'resource':
                    const resourceIds = getSavedResourceIdsForUser(user.idNumber).filter(savedId => savedId !== id);
                    saveResourceIdsForUser(user.idNumber, resourceIds);
                    setSavedResources(prev => prev.filter(item => item.id !== id));
                    break;
                case 'coding':
                    const topicIds = getSavedCodingTopicIdsForUser(user.idNumber).filter(savedId => savedId !== id);
                    saveCodingTopicIdsForUser(user.idNumber, topicIds);
                    setSavedCodingTopics(prev => prev.filter(item => item.id !== id));
                    break;
                case 'practiceProblem':
                    const problems = getSavedPracticeProblemsForUser(user.idNumber).filter(p => p.id !== id);
                    savePracticeProblemsForUser(user.idNumber, problems);
                    setSavedPracticeProblems(prev => prev.filter(p => p.id !== id));
                    break;
            }
            setItemToRemove(null);
            setJustRemovedId(null);
        }, 400);
    };
    
    // Reset filters and sort when tab changes
    useEffect(() => {
        setSearchTerm('');
        switch (activeTab) {
            case 'news': setSortOrder('date-desc'); break;
            case 'resource': setSortOrder('name-asc'); break;
            case 'coding': setSortOrder('name-asc'); break;
            case 'practiceProblem': setSortOrder('topic-asc'); break;
        }
    }, [activeTab]);

    const filteredAndSortedItems = useMemo(() => {
        const lowercasedTerm = searchTerm.toLowerCase();

        const filterAndSort = (items: any[], filterFn: (item: any) => boolean, sortFn: (a: any, b: any) => number) => {
            return items.filter(filterFn).sort(sortFn);
        };
        
        switch (activeTab) {
            case 'news':
                const newsFilter = (article: NewsArticle) => {
                    const termMatch = article.title.toLowerCase().includes(lowercasedTerm) || article.excerpt.toLowerCase().includes(lowercasedTerm);
                    if (!termMatch) return false;

                    if (activeDateFilter === 'All') return true;
                    const articleDate = new Date(article.date);
                    const now = new Date();
                    switch (activeDateFilter) {
                        case 'This Week':
                            const oneWeekAgo = new Date();
                            oneWeekAgo.setDate(now.getDate() - 7);
                            return articleDate >= oneWeekAgo;
                        case 'This Month':
                            return articleDate.getMonth() === now.getMonth() && articleDate.getFullYear() === now.getFullYear();
                        case 'This Year':
                            return articleDate.getFullYear() === now.getFullYear();
                        default: return true;
                    }
                };
                const newsSort = (a: NewsArticle, b: NewsArticle) => {
                    switch (sortOrder) {
                        case 'date-asc': return new Date(a.date).getTime() - new Date(b.date).getTime();
                        case 'title-asc': return a.title.localeCompare(b.title);
                        case 'title-desc': return b.title.localeCompare(a.title);
                        default: return new Date(b.date).getTime() - new Date(a.date).getTime(); // date-desc
                    }
                };
                return filterAndSort(savedArticles, newsFilter, newsSort);
            
            case 'resource':
                 const resourceFilter = (resource: ResourceFile) => {
                    return resource.name.toLowerCase().includes(lowercasedTerm) &&
                           (resourceYearFilter === 'All' || resource.year === resourceYearFilter) &&
                           (resourceSemesterFilter === 'All' || resource.semester === resourceSemesterFilter);
                };
                const resourceSort = (a: ResourceFile, b: ResourceFile) => {
                    return sortOrder === 'name-desc' ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name);
                };
                return filterAndSort(savedResources, resourceFilter, resourceSort);

            case 'coding':
                const codingFilter = (topic: CodingTopic) => {
                    return topic.name.toLowerCase().includes(lowercasedTerm) &&
                           (codingCategoryFilter === 'all' || topic.category === codingCategoryFilter);
                };
                const codingSort = (a: CodingTopic, b: CodingTopic) => {
                     return sortOrder === 'name-desc' ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name);
                };
                return filterAndSort(savedCodingTopics, codingFilter, codingSort);
            
            case 'practiceProblem':
                 const practiceFilter = (problem: SavedPracticeProblem) => {
                    return problem.question.toLowerCase().includes(lowercasedTerm) ||
                           problem.topicName.toLowerCase().includes(lowercasedTerm);
                };
                const practiceSort = (a: SavedPracticeProblem, b: SavedPracticeProblem) => {
                    return sortOrder === 'topic-desc' ? b.topicName.localeCompare(a.topicName) : a.topicName.localeCompare(b.topicName);
                };
                return filterAndSort(savedPracticeProblems, practiceFilter, practiceSort);

            default: return [];
        }
    }, [
        searchTerm, sortOrder, activeTab, savedArticles, savedResources, savedCodingTopics, savedPracticeProblems,
        activeDateFilter, resourceYearFilter, resourceSemesterFilter, codingCategoryFilter
    ]);

    const handleOpenCodingTopic = (topicId: string) => {
        const topic = allCodingTopics.find(t => t.id === topicId);
        if (topic) {
            setSelectedCodingTopic(topic);
            setCurrentView('coding');
        }
    };
    
    const handleShowSolution = async () => {
        if (!practiceModalProblem) return;
        if (solution?.text || solution?.error) { setSolution(null); return; }

        trackEvent('featureUse', 'show_saved_problem_solution', { topic: practiceModalProblem.topicName, question: practiceModalProblem.question });
        setSolution({ text: '', isLoading: true });

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Provide a detailed code solution for the following programming problem. The language should be appropriate for the topic "${practiceModalProblem.topicName}". The problem is: "${practiceModalProblem.question}". Explain the logic and include a code example. Format the response with Markdown, using code blocks for code.`;

            const response = await ai.models.generateContent({ model: "gemini-2.5-pro", contents: prompt });
            const solutionText = response.text;
            if (!solutionText) throw new Error("Model returned empty solution.");
            setSolution({ text: solutionText, isLoading: false });
        } catch (e: any) {
            setSolution({ text: '', error: e.message || "Failed to generate solution.", isLoading: false });
        }
    };

    const tabClasses = (tabName: 'news' | 'resource' | 'coding' | 'practiceProblem') => `px-4 py-2 text-sm sm:text-base font-semibold rounded-lg transition-colors ${
        activeTab === tabName
            ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900'
            : 'bg-transparent text-gray-600 hover:bg-black/10 dark:text-gray-300 dark:hover:bg-white/10'
    }`;
    
    if (user.name === 'Guest') {
        return (
            <div className="min-h-[calc(100vh-280px)] container mx-auto px-6 lg:px-8 py-12 flex flex-col items-center justify-center text-center">
                <BookmarkIcon className="w-24 h-24 text-gray-300 dark:text-gray-600 mb-6" />
                <h1 className="text-4xl font-bold text-gray-800 dark:text-white">Your Saved Items Live Here</h1>
                <p className="mt-4 max-w-md mx-auto text-gray-600 dark:text-gray-400">
                    Create a free profile to save content, access your personal collection from anywhere, and get personalized recommendations.
                </p>
                <button onClick={() => setCurrentView('profile')} className="mt-8 glass-button primary">
                    Create Profile
                </button>
            </div>
        );
    }
    
    return (
        <div className="min-h-[calc(100vh-280px)]">
            <section className="py-16">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl font-bold text-gray-800 dark:text-white">Saved Items</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">
                        Your personal collection of resources, articles, and coding topics.
                    </p>
                </div>
            </section>
            
            <section className="py-12">
                <div className="container mx-auto px-6 lg:px-8">
                    <div className="mb-8 flex justify-center">
                        <div className="flex flex-wrap justify-center gap-2 p-1 glass-effect rounded-lg">
                            <button onClick={() => setActiveTab('news')} className={tabClasses('news')}>News ({savedArticles.length})</button>
                            <button onClick={() => setActiveTab('resource')} className={tabClasses('resource')}>Resources ({savedResources.length})</button>
                            <button onClick={() => setActiveTab('coding')} className={tabClasses('coding')}>Coding ({savedCodingTopics.length})</button>
                            <button onClick={() => setActiveTab('practiceProblem')} className={tabClasses('practiceProblem')}>Practice ({savedPracticeProblems.length})</button>
                        </div>
                    </div>
                    
                    <div className="glass-effect p-6 rounded-xl">
                        {/* Search and Sort Controls */}
                        <div className="flex flex-col md:flex-row gap-4 mb-6">
                            <input
                                type="text"
                                placeholder={`Search in saved ${activeTab === 'resource' ? 'resources' : activeTab === 'practiceProblem' ? 'practice problems' : activeTab}...`}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full md:flex-grow glass-effect rounded-lg py-2 px-4 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            />
                            <select
                                value={sortOrder}
                                onChange={(e) => setSortOrder(e.target.value)}
                                className="w-full md:w-auto glass-effect rounded-lg py-2 px-4 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                            >
                                {sortOptions[activeTab].map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                            </select>
                        </div>

                        {/* Filter Controls */}
                        <div className="flex flex-wrap gap-2 mb-6 pb-6 border-b border-black/10 dark:border-white/10">
                            {activeTab === 'news' && dateFilterOptions.map(f => <button key={f} onClick={() => setActiveDateFilter(f)} className={`px-3 py-1 text-xs rounded-full ${activeDateFilter === f ? 'bg-purple-600 text-white' : 'glass-button'}`}>{f}</button>)}
                            {activeTab === 'resource' && (
                                <>
                                    {yearOptions.map(y => <button key={y} onClick={() => setResourceYearFilter(y)} className={`px-3 py-1 text-xs rounded-full ${resourceYearFilter === y ? 'bg-purple-600 text-white' : 'glass-button'}`}>{y}</button>)}
                                    <div className="w-px h-6 bg-black/10 dark:bg-white/10 mx-2"></div>
                                    {semesterOptions.map(s => <button key={s} onClick={() => setResourceSemesterFilter(s)} className={`px-3 py-1 text-xs rounded-full ${resourceSemesterFilter === s ? 'bg-purple-600 text-white' : 'glass-button'}`}>{s === 'All' ? 'All Semesters' : `Sem ${s}`}</button>)}
                                </>
                            )}
                             {activeTab === 'coding' && codingCategoryOptions.map(c => <button key={c} onClick={() => setCodingCategoryFilter(c)} className={`px-3 py-1 text-xs rounded-full capitalize ${codingCategoryFilter === c ? 'bg-purple-600 text-white' : 'glass-button'}`}>{c}</button>)}
                        </div>

                        <div className="min-h-[300px]">
                            {filteredAndSortedItems.length > 0 ? (
                                <ul className="space-y-4">
                                    {filteredAndSortedItems.map((item: any) => (
                                        <li key={item.id} className={`flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 rounded-lg bg-black/5 dark:bg-white/5 transition-all duration-300 ${justRemovedId === item.id ? 'animate-fade-out' : ''}`}>
                                            <div className="flex-grow">
                                                {activeTab === 'practiceProblem' && <p className="text-xs font-semibold text-purple-600 dark:text-purple-400"><Highlight text={item.topicName} highlight={searchTerm} /></p>}
                                                <p className="font-bold text-gray-800 dark:text-white">
                                                    <Highlight text={item.name || item.title || item.question} highlight={searchTerm} />
                                                </p>
                                                {activeTab !== 'practiceProblem' && <p className="text-sm text-gray-600 dark:text-gray-400"><Highlight text={item.excerpt || item.description || item.subjectName} highlight={searchTerm} /></p>}
                                            </div>
                                            <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center">
                                                {activeTab === 'news' && <button onClick={() => setCurrentView('news')} className="glass-button">Read</button>}
                                                {activeTab === 'resource' && <a href={item.link} target="_blank" rel="noopener noreferrer" className="glass-button">Download</a>}
                                                {activeTab === 'coding' && <button onClick={() => handleOpenCodingTopic(item.id)} className="glass-button">View</button>}
                                                {activeTab === 'practiceProblem' && <button onClick={() => setPracticeModalProblem(item)} className="glass-button">Practice</button>}
                                                <button onClick={() => setShareModalItem(item)} className="p-2 glass-button" aria-label="Share"><ShareIcon className="w-5 h-5"/></button>
                                                <button onClick={() => handleRemoveClick(activeTab, item.id)} className="p-2 glass-button" aria-label="Remove"><TrashIcon className="w-5 h-5"/></button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="text-center text-gray-500 dark:text-gray-400 py-12">
                                    <BookmarkIcon className="w-16 h-16 mx-auto mb-4 opacity-30" />
                                    <h3 className="text-xl font-semibold">No Saved Items Found</h3>
                                    <p>Your saved items will appear here. Try adjusting your filters.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </section>
            
            <ConfirmationModal
                isOpen={isConfirmModalOpen}
                onClose={() => setIsConfirmModalOpen(false)}
                onConfirm={handleConfirmRemove}
                title="Confirm Removal"
                message="Are you sure you want to remove this item from your saved list?"
                confirmButtonText="Remove"
            />
            {shareModalItem && (
                <ShareModal 
                    item={shareModalItem}
                    onClose={() => setShareModalItem(null)}
                />
            )}
             {practiceModalProblem && (
                <Modal 
                    isOpen={!!practiceModalProblem} 
                    onClose={() => {
                        setPracticeModalProblem(null);
                        setSolution(null);
                        setRunResult(null);
                        setUserCode('');
                    }} 
                    title={practiceModalProblem.topicName}
                    maxWidthClass="max-w-3xl"
                >
                    <p className="font-semibold text-lg mb-4">{practiceModalProblem.question}</p>
                    <textarea value={userCode} onChange={(e) => setUserCode(e.target.value)} placeholder="Write your code here..." rows={8} className="w-full glass-effect rounded-lg p-3 font-mono text-sm" />
                    <div className="mt-4 flex justify-end">
                        <button onClick={handleShowSolution} disabled={solution?.isLoading} className="glass-button primary flex items-center gap-2">
                             {solution?.isLoading ? <SpinnerIcon className="w-5 h-5" /> : <SparklesIcon className="w-5 h-5" />}
                             {solution?.isLoading ? 'Loading...' : (solution?.text || solution?.error) ? 'Hide Solution' : 'Show Solution'}
                        </button>
                    </div>
                     {solution && (
                        <div className="mt-4 glass-effect p-4 rounded-lg">
                            <h4 className="font-bold text-gray-800 dark:text-white mb-2">AI-Generated Solution</h4>
                            {solution.error && <p className="text-red-500">{solution.error}</p>}
                            {solution.text && <div className="prose dark:prose-invert max-w-none text-sm" dangerouslySetInnerHTML={{ __html: renderMarkdown(solution.text) }} />}
                        </div>
                    )}
                </Modal>
            )}
        </div>
    );
};