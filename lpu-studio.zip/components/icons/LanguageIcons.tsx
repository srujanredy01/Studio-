import React from 'react';

export const PythonIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12.24 12.83c.3-.3.3-.78 0-1.08l-2.6-2.6c-.3-.3-.78-.3-1.08 0L6 11.76c-.3.3-.3.78 0 1.08l2.6 2.6c.3.3.78.3 1.08 0l2.56-2.61zm-1.08 2.6l-2.6 2.6c-.3.3-.3.78 0 1.08L11.17 21c.3.3.78.3 1.08 0l2.6-2.6c.3-.3.3-.78 0-1.08l-2.6-2.6c-.3-.3-.78-.3-1.08 0zm2.6-1.08l2.6-2.6c.3-.3.78-.3 1.08 0L18 11.17c.3.3.3.78 0 1.08l-2.6 2.6c-.3.3-.78.3-1.08 0l-2.6-2.6c-.3-.3-.3-.78 0-1.08zm1.08-2.6l2.6-2.6c.3-.3.3-.78 0-1.08L12.24 3c-.3-.3-.78-.3-1.08 0l-2.6 2.6c-.3.3-.3.78 0 1.08l2.6 2.6c.3.3.78.3 1.08 0z"/>
    </svg>
);

export const JavaScriptIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M3 3h18v18H3V3zm16 16V5H5v14h14zm-4-4h-2v-4h2V9h-4v2h2v4H9v2h6v-2zm-6-8h4v2h-4V7z"/>
    </svg>
);

export const JavaIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12.83 3.08c-1.3-.5-2.68-.5-3.98 0l-4.5 1.76C3.32 5.25 3 6.31 3 7.28v7.44c0 .97.32 2.03.85 2.44l4.5 1.76c1.3.5 2.68.5 3.98 0l4.5-1.76c.53-.41.85-1.47.85-2.44V7.28c0-.97-.32-2.03-.85-2.44l-4.5-1.76zM11 13H9v2H7v-6h4v2h2v2h-2v-2H9v2h2v2zm4-1c0-.55-.45-1-1-1s-1 .45-1 1 .45 1 1 1 1-.45 1-1z"/>
    </svg>
);

export const CppIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M14 11h-2v2h2v-2zm4-2h-2v2h2V9zm-2 2h-2v2h2v-2zm4-2h-2v2h2V9zM12 9H8c-1.1 0-2 .9-2 2v2c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2zm0 4H8v-2h4v2z"/>
    </svg>
);

export const WebDevIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-5 14H4v-4h11v4zm0-5H4V9h11v4zm5 5h-4V9h4v10z"/>
    </svg>
);

export const DSAIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12,2C9.24,2,7,4.24,7,7v2H5v2h2v2c0,2.76,2.24,5,5,5s5-2.24,5-5v-2h2v-2h-2V7C17,4.24,14.76,2,12,2z M15,13 c0,1.66-1.34,3-3,3s-3-1.34,3-3v-2h6V13z M15,9H9V7c0-1.66,1.34-3,3-3s3,1.34,3,3V9z"/>
    </svg>
);

export const PracticeProblemsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zm0-2a7 7 0 100-14 7 7 0 000 14zm0-2a5 5 0 100-10 5 5 0 000 10zm0-2a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd"/>
    </svg>
);

export const CIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M15.2,18.21c1.24-1.12,2-2.64,2-4.21c0-2.26-1.29-4.26-3.23-5.22C13.23,6.2,11.3,5.5,9.2,5.5 c-3.29,0-6.11,2.03-7.2,4.86L4,10.25c0.91-2.14,3.08-3.5,5.5-3.5c1.78,0,3.37,0.61,4.6,1.7C20.4,10.7,21,14.4,21,14.5 c0,2.73-1.61,5.13-4,6.23L16.89,19C18.97,17.65,20.2,15.3,20.2,12.5c0-0.22-0.03-1.04-0.34-1.89l-1.9,0.47 C18.1,11.8,18.2,12.1,18.2,12.5c0,1.29-0.58,2.49-1.5,3.27C15.8,16.5,14.5,17,13.2,17c-1.54,0-2.93-0.75-3.8-1.95L7.85,15.8 C8.8,17.43,10.6,18.5,12.7,18.5c0.88,0,1.71-0.2,2.5-0.55V18.21z"/>
    </svg>
);

export const HTMLIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M1.5 0h21l-1.91 21.563L11.977 24l-8.564-2.438L1.5 0zM12 18.26l-4.63-1.287L7 15.31h2.4l-.2 2.22 2.8 1.04v-9.35H8.6l.2-2.22H15.4l-.3 2.22h-3.6v4.67l.01.01 2.8-1.04.3-4.44h2.4l-.5 4.633L12 18.26z"/>
    </svg>
);

export const CSSIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M1.5 0h21l-1.91 21.563L11.977 24l-8.564-2.438L1.5 0zM12 18.26l4.63-1.287.42-4.633H9.27l-.21-2.417h7.66l.21-2.417H6.64l.21 2.417h7.66l-.31 3.5-3.2 1.04-.01.01-3.2-1.05-.2-2.317h-2.4l.42 4.633L12 18.26z"/>
    </svg>
);

export const DataScienceIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z"/>
    </svg>
);

export const MachineLearningIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-1-5.95c-.32.03-.63.1-.94.19-1.74.55-2.92 2.21-2.58 4.04.25 1.35 1.4 2.45 2.78 2.68.1.02.19.03.29.04.1-.01.19-.02.29-.04 1.38-.23 2.53-1.33 2.78-2.68.34-1.83-.84-3.49-2.58-4.04-.31-.09-.62-.16-.94-.19zm1-2.05c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/>
    </svg>
);

export const CoursesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z"/>
    </svg>
);

export const LinuxIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12,2C6.47,2 2,6.47 2,12c0,5.53 4.47,10 10,10s10-4.47 10-10C22,6.47 17.53,2 12,2z M11.5,10.5 c0-0.83,0.67-1.5,1.5-1.5s1.5,0.67,1.5,1.5S13.83,12,13,12S11.5,11.33,11.5,10.5z M8.5,10.5C8.5,9.67,9.17,9,10,9 s1.5,0.67,1.5,1.5S10.83,12,10,12S8.5,11.33,8.5,10.5z M12,14c-2.33,0-4.31,1.46-5.11,3.5h10.22 C16.31,15.46,14.33,14,12,14z"/>
    </svg>
);

export const DevOpsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M16.5,7.5c-1.2,0-2.3,0.5-3.1,1.3L12,10.2l-1.4-1.4C9.8,8,8.7,7.5,7.5,7.5C5.6,7.5,4,9.1,4,11s1.6,3.5,3.5,3.5 c1.2,0,2.3-0.5,3.1-1.3L12,11.8l1.4,1.4c0.8,0.8,1.9,1.3,3.1,1.3c1.9,0,3.5-1.6,3.5-3.5S18.4,7.5,16.5,7.5z M7.5,12.5 c-0.8,0-1.5-0.7-1.5-1.5s0.7-1.5,1.5-1.5s1.5,0.7,1.5,1.5S8.3,12.5,7.5,12.5z M16.5,12.5c-0.8,0-1.5-0.7-1.5-1.5s0.7-1.5,1.5-1.5 s1.5,0.7,1.5,1.5S17.3,12.5,16.5,12.5z"/>
    </svg>
);

export const SQLIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.66 3.58 3 8 3s8-1.34 8-3V6c0 1.66-3.58 3-8 3s-8-1.34-8-3z"/>
    </svg>
);

export const SystemDesignIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M20 6h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2h4v5c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2v-5h4c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/>
    </svg>
);

export const AptitudeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M14 7h-4c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-4 6V9h4v4h-4zm10-6c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h2V7h-2zM4 7H2v10h2c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2z"/>
    </svg>
);
