
import React from 'react';
import type { User, ResourceFile, NewsArticle, TeamMember } from '../types';
import { AIRecommendations } from './AIRecommendations';
import { LockIcon } from './icons/LockIcon';
import { useAppContext } from '../context/DataContext';

// Icon Components
const BookIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
    </svg>
);

const CodeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" />
    </svg>
);

const NewsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5M6 7.5h3v3H6v-3z" />
    </svg>
);

const AboutUsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 12V10.332A48.36 48.36 0 0012 9.75c-2.551 0-5.056.2-7.5.582V21M3 21h18M12 6.75h.008v.008H12V6.75z" />
    </svg>
);

interface HomePageProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

export const HomePage: React.FC<HomePageProps> = ({ setCurrentView }) => {
    const { user, resources, newsArticles, teamMembers } = useAppContext();
    return (
        <div className="min-h-[calc(100vh-280px)]">
            {/* Hero Section */}
            <section className="relative py-20 sm:py-28 overflow-hidden">
                <div className="container mx-auto px-6 lg:px-8 relative z-10">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div className="text-center md:text-left">
                            <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold font-serif text-gray-800 dark:text-white leading-tight">
                                LPU Student Hub
                            </h1>
                            <p className="mt-6 max-w-xl mx-auto md:mx-0 text-lg text-gray-600 dark:text-gray-300">
                                Your one-stop resource for free PDFs, coding answers, and news.
                            </p>
                            <div className="mt-10">
                                <button onClick={() => setCurrentView('resources')} className="glass-button primary aurora-effect text-lg px-8 py-3.5">
                                    Get Started
                                </button>
                            </div>
                        </div>
                        <div className="hidden md:block">
                            <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop" alt="Student studying" className="rounded-2xl shadow-2xl" />
                        </div>
                    </div>
                </div>
            </section>

            {/* Quick Links Section */}
            <section className="py-24">
                <div className="container mx-auto px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-800 dark:text-white">Quick Links</h2>
                        <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">Jump right into the section you need.</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {/* Resources Card */}
                        <div className="glass-effect p-8 rounded-2xl aurora-effect text-center flex flex-col items-center">
                            <div className="inline-block p-4 bg-purple-100 dark:bg-purple-900/50 rounded-full mb-4">
                                <BookIcon className="w-8 h-8 text-purple-600 dark:text-purple-300" />
                            </div>
                            <h3 className="text-2xl font-bold font-serif text-gray-800 dark:text-white mb-2">Resources</h3>
                            <p className="text-gray-600 dark:text-gray-400 flex-grow mb-6">Access our extensive library of PDFs and study materials.</p>
                            <button onClick={() => setCurrentView('resources')} className="glass-button w-full mt-auto">Explore</button>
                        </div>
                        {/* Coding Card */}
                        <div className="glass-effect p-8 rounded-2xl aurora-effect text-center flex flex-col items-center">
                            <div className="inline-block p-4 bg-green-100 dark:bg-green-900/50 rounded-full mb-4">
                                <CodeIcon className="w-8 h-8 text-green-600 dark:text-green-300" />
                            </div>
                            <h3 className="text-2xl font-bold font-serif text-gray-800 dark:text-white mb-2">Coding</h3>
                            <p className="text-gray-600 dark:text-gray-400 flex-grow mb-6">Find curated solutions and resources for various programming languages.</p>
                            <button onClick={() => setCurrentView('coding')} className="glass-button w-full mt-auto">Explore</button>
                        </div>
                        {/* News Card */}
                        <div className="glass-effect p-8 rounded-2xl aurora-effect text-center flex flex-col items-center">
                            <div className="inline-block p-4 bg-blue-100 dark:bg-blue-900/50 rounded-full mb-4">
                                <NewsIcon className="w-8 h-8 text-blue-600 dark:text-blue-300" />
                            </div>
                            <h3 className="text-2xl font-bold font-serif text-gray-800 dark:text-white mb-2">News</h3>
                            <p className="text-gray-600 dark:text-gray-400 flex-grow mb-6">Stay updated with the latest news, events, and announcements on campus.</p>
                            <button onClick={() => setCurrentView('news')} className="glass-button w-full mt-auto">Explore</button>
                        </div>
                        {/* About Us Card */}
                        <div className="glass-effect p-8 rounded-2xl aurora-effect text-center flex flex-col items-center">
                             <div className="inline-block p-4 bg-pink-100 dark:bg-pink-900/50 rounded-full mb-4">
                                <AboutUsIcon className="w-8 h-8 text-pink-600 dark:text-pink-300" />
                            </div>
                            <h3 className="text-2xl font-bold font-serif text-gray-800 dark:text-white mb-2">About Us</h3>
                            <p className="text-gray-600 dark:text-gray-400 flex-grow mb-6">Learn more about our mission and the team behind LPU Studio.</p>
                            <button onClick={() => setCurrentView('about')} className="glass-button w-full mt-auto">Explore</button>
                        </div>
                    </div>
                </div>
            </section>
            
            {/* Why Choose LPU Studio? Section */}
            <section className="py-24 bg-black/5 dark:bg-white/5">
                <div className="container mx-auto px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-800 dark:text-white">Why Choose LPU Studio?</h2>
                        <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600 dark:text-gray-300">We're dedicated to making your academic life simpler and more productive.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                        <div className="glass-effect p-8 rounded-xl aurora-effect">
                             <div className="inline-block p-4 bg-purple-100 dark:bg-purple-900/50 rounded-full mb-4">
                                <BookIcon className="w-8 h-8 text-purple-600 dark:text-purple-300" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Comprehensive Resources</h3>
                            <p className="text-gray-600 dark:text-gray-400">Access a vast, curated library of notes, PYQs, and study materials for every subject, all in one place.</p>
                        </div>
                        <div className="glass-effect p-8 rounded-xl aurora-effect">
                            <div className="inline-block p-4 bg-green-100 dark:bg-green-900/50 rounded-full mb-4">
                                <CodeIcon className="w-8 h-8 text-green-600 dark:text-green-300" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Expert Coding Solutions</h3>
                            <p className="text-gray-600 dark:text-gray-400">From Python to Web Dev, find reliable code solutions and tutorials to help you ace your assignments and projects.</p>
                        </div>
                        <div className="glass-effect p-8 rounded-xl aurora-effect">
                            <div className="inline-block p-4 bg-blue-100 dark:bg-blue-900/50 rounded-full mb-4">
                                <NewsIcon className="w-8 h-8 text-blue-600 dark:text-blue-300" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Stay Informed</h3>
                            <p className="text-gray-600 dark:text-gray-400">Never miss an update. Get the latest campus news, event schedules, and important announcements instantly.</p>
                        </div>
                    </div>
                </div>
            </section>
            
            {/* AI Recommendations Section */}
            {user.name !== 'Guest' && (
                <AIRecommendations user={user} resources={resources} newsArticles={newsArticles} />
            )}
            
            {/* Built by Students Section */}
             <section className="py-24">
                <div className="container mx-auto px-6 lg:px-8">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div>
                            <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-800 dark:text-white">Built by Students, for Students</h2>
                            <p className="mt-6 text-gray-600 dark:text-gray-300 leading-relaxed">
                                LPU Studio was born from a simple idea: to make student life easier. We are a team of passionate developers and content creators dedicated to providing a centralized, modern, and accessible hub for all LPU students.
                            </p>
                            <button onClick={() => setCurrentView('about')} className="mt-8 font-semibold text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-300 transition-colors group">
                                Meet the Team <span className="inline-block transition-transform group-hover:translate-x-1">&rarr;</span>
                            </button>
                        </div>
                        <div className="flex gap-8 justify-center">
                            {teamMembers.slice(0, 2).map(member => (
                                <div key={member.id} className="glass-effect p-6 rounded-2xl text-center">
                                    <img src={member.imageUrl} alt={member.name} className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-white/50" />
                                    <h3 className="text-xl font-bold text-gray-800 dark:text-white">{member.name}</h3>
                                    <p className="font-semibold text-purple-600 dark:text-purple-400">{member.role}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>


             {/* Locked Content Teaser */}
            {user.name === 'Guest' && (
                <section className="py-24 bg-black/5 dark:bg-white/5">
                    <div className="container mx-auto px-6 lg:px-8 text-center">
                        <div className="max-w-2xl mx-auto">
                            <LockIcon className="w-12 h-12 mx-auto text-gray-400 dark:text-gray-500 mb-4" />
                            <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Unlock Your Full Potential</h2>
                            <p className="mt-4 text-gray-600 dark:text-gray-400">
                                Create a free profile to save content, access exclusive coding problems, and get personalized recommendations based on your year and interests.
                            </p>
                            <button onClick={() => setCurrentView('profile')} className="mt-8 glass-button primary aurora-effect">
                                Get Started
                            </button>
                        </div>
                    </div>
                </section>
            )}

        </div>
    );
};