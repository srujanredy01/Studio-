

import React, { useState } from 'react';
import type { NewsArticle, ResourceFile } from '../types';
import { MailIcon } from './icons/SocialIcons';
import { LinkIcon, TwitterIcon } from './icons/ShareIcons';
import { Modal } from './Modal';

interface ShareModalProps {
  item: NewsArticle | ResourceFile;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ item, onClose }) => {
  const [copyText, setCopyText] = useState('Copy Link');
  
  const title = 'title' in item ? item.title : item.name;
  const itemUrl = 'link' in item ? item.link : `https://lpustudio.app/news/${item.id}`;
  const shareText = `Check out this from LPU Studio: ${title}`;

  const twitterUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(itemUrl)}&text=${encodeURIComponent(shareText)}`;
  const mailUrl = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(shareText + '\n\n' + itemUrl)}`;

  const handleCopy = () => {
    if (copyText === 'Copied!') return;
    navigator.clipboard.writeText(itemUrl).then(() => {
      setCopyText('Copied!');
      setTimeout(() => {
        setCopyText('Copy Link');
      }, 2000);
    });
  };

  return (
    <Modal isOpen={true} onClose={onClose} title="Share Content" maxWidthClass="max-w-xs">
      <div className="space-y-3">
        <a href={twitterUrl} target="_blank" rel="noopener noreferrer" className="w-full flex items-center gap-3 px-4 py-3 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg text-gray-800 dark:text-white font-semibold transition-colors">
            <TwitterIcon className="w-5 h-5" />
            <span>Share on Twitter</span>
        </a>
        <a href={mailUrl} className="w-full flex items-center gap-3 px-4 py-3 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg text-gray-800 dark:text-white font-semibold transition-colors">
            <MailIcon className="w-5 h-5" />
            <span>Share via Email</span>
        </a>
        <button onClick={handleCopy} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-semibold transition-colors ${copyText === 'Copied!' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white'}`}>
            <LinkIcon className="w-5 h-5" />
            <span>{copyText}</span>
        </button>
      </div>
    </Modal>
  );
};
