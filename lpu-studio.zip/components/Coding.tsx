
import React, { useState, useEffect } from 'react';
import { 
    PythonIcon, JavaScriptIcon, JavaIcon, CppIcon, WebDevIcon, DSAIcon,
    PracticeProblemsIcon, CIcon, DataScienceIcon, MachineLearningIcon,
    CoursesIcon, LinuxIcon, DevOpsIcon, SQLIcon, SystemDesignIcon, AptitudeIcon,
    HTMLIcon, CSSIcon
} from './icons/LanguageIcons';
import { BookmarkIcon } from './icons/ActionIcons';
import type { CodingTopic, User } from '../types';
import { trackEvent } from '../analytics';
import { getSavedCodingTopicIdsForUser, saveCodingTopicIdsForUser } from '../data/userData';
import { useAppContext } from '../context/DataContext';

const iconMap: { [key: string]: React.ReactNode } = {
    'python': <PythonIcon className="w-12 h-12" />,
    'javascript': <JavaScriptIcon className="w-12 h-12" />,
    'java': <JavaIcon className="w-12 h-12" />,
    'cpp': <CppIcon className="w-12 h-12" />,
    'html': <HTMLIcon className="w-12 h-12" />,
    'css': <CSSIcon className="w-12 h-12" />,
    'webdev': <WebDevIcon className="w-12 h-12" />,
    'dsa': <DSAIcon className="w-12 h-12" />,
    'practice': <PracticeProblemsIcon className="w-12 h-12" />,
    'c': <CIcon className="w-12 h-12" />,
    'datascience': <DataScienceIcon className="w-12 h-12" />,
    'machinelearning': <MachineLearningIcon className="w-12 h-12" />,
    'courses': <CoursesIcon className="w-12 h-12" />,
    'linux': <LinuxIcon className="w-12 h-12" />,
    'devops': <DevOpsIcon className="w-12 h-12" />,
    'sql': <SQLIcon className="w-12 h-12" />,
    'systemdesign': <SystemDesignIcon className="w-12 h-12" />,
    'aptitude': <AptitudeIcon className="w-12 h-12" />,
};

const CodingTopicCardSkeleton: React.FC = () => (
    <div className="glass-effect rounded-xl p-6 flex flex-col items-center text-center animate-pulse">
        <div className="bg-gray-300 dark:bg-gray-700 rounded-full w-12 h-12 mb-4"></div>
        <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded-md w-3/4 mb-2"></div>
        <div className="space-y-2 flex-grow w-full mb-4">
            <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded-md w-full"></div>
            <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded-md w-5/6"></div>
        </div>
        <div className="h-5 bg-gray-300 dark:bg-gray-700 rounded-full w-20 mb-4"></div>
        <div className="h-10 bg-gray-300 dark:bg-gray-700 rounded-full w-full mt-auto"></div>
    </div>
);

interface CodingProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
    onTopicSelect: (topic: CodingTopic) => void;
}

type FilterCategory = 'all' | 'language' | 'concept';

export const Coding: React.FC<CodingProps> = ({ setCurrentView, onTopicSelect }) => {
    const { codingTopics, user } = useAppContext();
    const [isLoading, setIsLoading] = useState(true);
    
    // Persist filters in localStorage
    const [searchTerm, setSearchTerm] = useState<string>(() => {
        return localStorage.getItem('codingSearchTerm') || '';
    });
    const [activeFilter, setActiveFilter] = useState<FilterCategory>(() => {
        return (localStorage.getItem('codingActiveFilter') as FilterCategory) || 'all';
    });
    
    const [savedCodingTopicIds, setSavedCodingTopicIds] = useState<string[]>(() => getSavedCodingTopicIdsForUser(user.idNumber));
    
    // Effect for loading state on filter change and persisting filters
    useEffect(() => {
        setIsLoading(true);
        localStorage.setItem('codingSearchTerm', searchTerm);
        localStorage.setItem('codingActiveFilter', activeFilter);
        
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 500); // Simulate filtering/fetching delay
        
        return () => clearTimeout(timer);
    }, [searchTerm, activeFilter]);

    // Resync saved state when user changes
    useEffect(() => {
        setSavedCodingTopicIds(getSavedCodingTopicIdsForUser(user.idNumber));
    }, [user.idNumber]);


    const toggleSaveTopic = (e: React.MouseEvent, id: string) => {
        e.stopPropagation(); // Prevent topic selection when saving
        if (user.name === 'Guest' || !user.idNumber) {
            setCurrentView('profile');
            return;
        }

        const currentSaved = getSavedCodingTopicIdsForUser(user.idNumber);
        const isSaving = !currentSaved.includes(id);
        let updatedSaved;
        if (isSaving) {
            updatedSaved = [...currentSaved, id];
        } else {
            updatedSaved = currentSaved.filter(savedId => savedId !== id);
        }
        saveCodingTopicIdsForUser(user.idNumber, updatedSaved);
        setSavedCodingTopicIds(updatedSaved);
        const topic = codingTopics.find(t => t.id === id);
        trackEvent('featureUse', isSaving ? 'save_coding_topic' : 'unsave_coding_topic', { topicId: id, topicName: topic?.name });
    };

    const searchedTopics = codingTopics.filter(topic =>
        topic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        topic.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const topicCounts = {
        all: searchedTopics.length,
        language: searchedTopics.filter(t => t.category === 'language').length,
        concept: searchedTopics.filter(t => t.category === 'concept').length,
    };
    
    const displayedTopics = searchedTopics.filter(topic => {
        return activeFilter === 'all' || topic.category === activeFilter;
    });
    
    const filterButtons: { key: FilterCategory, label: string }[] = [
        { key: 'all', label: 'All Topics' },
        { key: 'language', label: 'Languages' },
        { key: 'concept', label: 'Concepts' },
    ];
    
    return (
        <div className="min-h-[calc(100vh-280px)]">
            <section className="py-16">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl font-bold text-gray-800 dark:text-white">Coding Hub</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">
                        Select a language or topic to find curated solutions and resources.
                    </p>
                </div>
            </section>
            
            <section className="py-12">
                <div className="container mx-auto px-6 lg:px-8">
                     {/* Search Bar */}
                    <div className="mb-8 max-w-2xl mx-auto">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <input
                                type="text"
                                placeholder="Search languages or topics..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="block w-full glass-effect rounded-full py-3 pl-12 pr-4 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            />
                        </div>
                    </div>

                    <div className="flex flex-wrap justify-center gap-3">
                        {filterButtons.map(({ key, label }) => (
                            <button
                                key={key}
                                onClick={() => setActiveFilter(key)}
                                className={`font-semibold py-2 px-6 rounded-full transition-all duration-300 flex items-center gap-2 glass-button aurora-effect ${
                                    activeFilter === key
                                        ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 border-transparent'
                                        : 'hover:bg-gray-800 dark:hover:bg-gray-200 hover:text-white dark:hover:text-gray-900'
                                }`}
                            >
                                {label}
                                <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${activeFilter === key ? 'bg-white/20 dark:bg-black/20' : 'bg-gray-200 dark:bg-gray-700'}`}>
                                    {topicCounts[key]}
                                </span>
                            </button>
                        ))}
                    </div>

                    <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                        {isLoading 
                            ? Array.from({ length: 12 }).map((_, index) => <CodingTopicCardSkeleton key={index} />)
                            : displayedTopics.map(topic => {
                                const isSaved = savedCodingTopicIds.includes(topic.id);
                                return (
                                    <div key={topic.id} className="relative glass-effect aurora-effect rounded-xl group transition-all duration-300 hover:scale-[1.03] hover:shadow-lg dark:hover:shadow-purple-500/25 p-6 flex flex-col items-center text-center">
                                        <div className="text-purple-600 dark:text-purple-400 mb-4">{iconMap[topic.id] || <PracticeProblemsIcon className="w-12 h-12" />}</div>
                                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{topic.name}</h3>
                                        <p className="text-gray-600 dark:text-gray-300 text-sm flex-grow mb-4">{topic.description}</p>
                                        <span className={`text-xs font-semibold px-2 py-1 rounded-full self-center mb-4 ${
                                            topic.difficulty === 'Beginner' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' :
                                            topic.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' :
                                            'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'
                                        }`}>
                                            {topic.difficulty}
                                        </span>
                                        <button 
                                            onClick={() => onTopicSelect(topic)}
                                            className="glass-button w-full mt-auto"
                                        >
                                            Open Questions
                                        </button>
                                        <button 
                                            onClick={(e) => toggleSaveTopic(e, topic.id)}
                                            className={`absolute top-3 right-3 p-2 rounded-full transition-all opacity-50 group-hover:opacity-100 ${isSaved ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300' : 'bg-black/5 text-gray-700 hover:bg-black/10 dark:bg-white/5 dark:text-gray-200 dark:hover:bg-white/10'}`}
                                            aria-label={isSaved ? 'Remove from saved' : 'Save for later'}
                                        >
                                            <BookmarkIcon className="w-5 h-5" filled={isSaved} />
                                        </button>
                                    </div>
                                );
                            })
                        }
                    </div>

                    {!isLoading && displayedTopics.length === 0 && (
                        <div className="text-center text-gray-500 dark:text-gray-400 mt-16">
                            <h3 className="text-2xl font-semibold mb-2">No Topics Found</h3>
                            <p>Try adjusting your search or filter criteria.</p>
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};