
import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import type { CodingTopic, CodingTopicDifficulty, User, SavedPracticeProblem } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/ProfileIcons';
import { BookmarkIcon } from './icons/ActionIcons';
import { trackEvent } from '../analytics';
import { getSavedPracticeProblemsForUser, savePracticeProblemsForUser } from '../data/userData';
import { useAppContext } from '../context/DataContext';

const ArrowLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
    </svg>
);

interface CodingTopicPageProps {
    topic: CodingTopic;
    onBack: () => void;
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

export const CodingTopicPage: React.FC<CodingTopicPageProps> = ({ topic, onBack, setCurrentView }) => {
    const { user } = useAppContext();
    const [questions, setQuestions] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [solutions, setSolutions] = useState<Record<number, { solution: string; isLoading: boolean; error?: string }>>({});
    const [selectedQuestionIndex, setSelectedQuestionIndex] = useState<number | null>(null);
    const [isSolutionVisible, setIsSolutionVisible] = useState(false);
    const [userCode, setUserCode] = useState<Record<number, string>>({});
    const [selectedDifficulty, setSelectedDifficulty] = useState<CodingTopicDifficulty>(topic.difficulty || 'Beginner');
    const [savedProblems, setSavedProblems] = useState<SavedPracticeProblem[]>(() => getSavedPracticeProblemsForUser(user.idNumber));

    // Resync saved state when user changes
    useEffect(() => {
        setSavedProblems(getSavedPracticeProblemsForUser(user.idNumber));
    }, [user.idNumber]);

    const fetchQuestions = useCallback(async (difficulty: CodingTopicDifficulty) => {
        setIsLoading(true);
        setError(null);
        setQuestions([]);
        setSolutions({});
        setSelectedQuestionIndex(null);
        setIsSolutionVisible(false);
        trackEvent('featureUse', 'generate_coding_questions', { topic: topic.name, difficulty });

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Generate 5 unique, ${difficulty.toLowerCase()} level programming practice problems for ${topic.name}.
For each problem, provide only a concise problem statement.
Do not include solutions, hints, difficulty levels, or any extra text.
Format the output as a simple list separated by newlines.
Example:
Write a function that reverses a string.
Given an array of integers, find the sum of all even numbers.`;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
            });
            const text = response.text;
            
            const parsedQuestions = text
                .split('\n')
                .map(q => q.trim().replace(/^(?:\d+\.\s*|-\s*|\*\s*)/, ''))
                .filter(q => q.length > 0);

            if (parsedQuestions.length === 0) {
                setError("Could not generate questions. The model returned an empty response.");
            } else {
                setQuestions(parsedQuestions);
            }
        } catch (e) {
            console.error("AI Question Generation Error:", e);
            setError("A temporary connection error occurred while generating questions. Please try again in a few moments.");
        } finally {
            setIsLoading(false);
        }
    }, [topic.name]);
    
    useEffect(() => {
        // Initial fetch, linter disabled to prevent re-fetching on difficulty state change, which is handled separately.
        fetchQuestions(selectedDifficulty);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fetchQuestions]);

    const toggleSaveProblem = (question: string) => {
        if (user.name === 'Guest' || !user.idNumber) {
            setCurrentView('profile');
            return;
        }

        const problemId = `${topic.id}:${question}`;
        const currentSaved = getSavedPracticeProblemsForUser(user.idNumber);
        const isSaved = currentSaved.some(p => p.id === problemId);
        let updatedSavedProblems;

        if (isSaved) {
            updatedSavedProblems = currentSaved.filter(p => p.id !== problemId);
            trackEvent('featureUse', 'unsave_practice_problem', { topic: topic.name, question });
        } else {
            const newProblem: SavedPracticeProblem = {
                id: problemId,
                topicId: topic.id,
                topicName: topic.name,
                question: question,
            };
            updatedSavedProblems = [...currentSaved, newProblem];
            trackEvent('featureUse', 'save_practice_problem', { topic: topic.name, question });
        }
        
        savePracticeProblemsForUser(user.idNumber, updatedSavedProblems);
        setSavedProblems(updatedSavedProblems);
    };

    const handleDifficultyChange = (difficulty: CodingTopicDifficulty) => {
        setSelectedDifficulty(difficulty);
        fetchQuestions(difficulty);
    };

    const handleSelectQuestion = (index: number) => {
        setSelectedQuestionIndex(index);
        setIsSolutionVisible(false);
    };

    const handleBackToLobby = () => {
        setSelectedQuestionIndex(null);
        setIsSolutionVisible(false);
    };

    const handleShowSolution = async () => {
        if (selectedQuestionIndex === null) return;

        if (isSolutionVisible) {
            setIsSolutionVisible(false);
            return;
        }

        trackEvent('featureUse', 'generate_coding_solution', { topic: topic.name, question: questions[selectedQuestionIndex] });

        if (solutions[selectedQuestionIndex]?.solution || solutions[selectedQuestionIndex]?.error) {
            setIsSolutionVisible(true);
            return;
        }

        setSolutions(prev => ({ ...prev, [selectedQuestionIndex]: { solution: '', isLoading: true } }));

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `Provide a detailed code solution for the following programming problem. The language should be appropriate for the topic "${topic.name}". The problem is: "${questions[selectedQuestionIndex]}". Explain the logic and include a code example. Format the response with Markdown, using code blocks for code.`;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-pro",
                contents: prompt,
            });
            const solutionText = response.text;
            
            if (!solutionText || solutionText.trim() === '') throw new Error("Model returned an empty solution.");

            setSolutions(prev => ({ ...prev, [selectedQuestionIndex]: { solution: solutionText, isLoading: false } }));
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : "Failed to generate solution.";
            setSolutions(prev => ({ ...prev, [selectedQuestionIndex]: { solution: '', error: errorMessage, isLoading: false } }));
        } finally {
            setIsSolutionVisible(true);
        }
    };
    
    const renderMarkdown = (text: string): string => {
        let processedText = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        const blocks = processedText.split(/(```[\s\S]*?```)/g).map(block => block.trim()).filter(Boolean);

        const htmlBlocks = blocks.map(block => {
            if (block.startsWith('```')) {
                const language = block.match(/```(\w*)/)?.[1] || '';
                const code = block.replace(/```\w*\n/, '').replace(/```$/, '').trim();
                return `<pre><code class="language-${language} p-4 block overflow-x-auto bg-gray-800 text-white rounded-md">${code.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code></pre>`;
            }
            
            const lines = block.split('\n');
            if (lines[0].startsWith('### ')) return `<h3>${lines[0].substring(4)}</h3>`;
            if (lines[0].startsWith('## ')) return `<h2>${lines[0].substring(3)}</h2>`;
            if (lines[0].startsWith('# ')) return `<h1>${lines[0].substring(2)}</h1>`;
            
            const isUnorderedList = lines.every(line => line.trim().startsWith('* ') || line.trim().startsWith('- '));
            if (isUnorderedList) {
                const listItems = lines.map(line => `<li>${line.trim().substring(2)}</li>`).join('');
                return `<ul>${listItems}</ul>`;
            }

            const isOrderedList = lines.every(line => line.trim().match(/^\d+\.\s/));
            if(isOrderedList) {
                const listItems = lines.map(line => `<li>${line.trim().replace(/^\d+\.\s/, '')}</li>`).join('');
                return `<ol>${listItems}</ol>`;
            }

            return `<p>${lines.join('<br />')}</p>`;
        });
    
        return htmlBlocks.join('');
    };

    const difficultyButtons: CodingTopicDifficulty[] = ['Beginner', 'Intermediate', 'Advanced'];
    const currentSolutionState = selectedQuestionIndex !== null ? solutions[selectedQuestionIndex] : null;

    return (
        <div className="min-h-[calc(100vh-280px)] container mx-auto px-6 lg:px-8 py-12">
            <div className="max-w-4xl mx-auto">
                <button
                    onClick={selectedQuestionIndex !== null ? handleBackToLobby : onBack}
                    className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 font-semibold transition-colors mb-8"
                >
                    <ArrowLeftIcon className="w-5 h-5" />
                    {selectedQuestionIndex !== null ? 'Back to Problems' : 'Back to Coding Hub'}
                </button>

                {selectedQuestionIndex !== null ? (
                    // Practice View
                    <div className="animate-slide-in-bottom">
                        <div className="glass-effect p-6 rounded-lg mb-6">
                            <h2 className="text-sm font-semibold text-purple-700 dark:text-purple-300 mb-2">Problem {selectedQuestionIndex + 1}</h2>
                            <p className="text-xl text-gray-800 dark:text-gray-100 font-medium">
                                {questions[selectedQuestionIndex]}
                            </p>
                        </div>
                        
                        <div className="glass-effect p-6 rounded-lg">
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-3">Your Workspace</h3>
                            <textarea
                                value={userCode[selectedQuestionIndex] || ''}
                                onChange={(e) => setUserCode(prev => ({ ...prev, [selectedQuestionIndex]: e.target.value }))}
                                placeholder="Write your code here..."
                                rows={10}
                                className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md p-4 text-gray-800 dark:text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all font-mono text-sm resize-y"
                                aria-label="Solution text area"
                            />
                            <div className="mt-4 flex justify-end">
                                <button
                                    onClick={handleShowSolution}
                                    disabled={currentSolutionState?.isLoading}
                                    className="glass-button primary flex items-center gap-2"
                                >
                                    {currentSolutionState?.isLoading ? <SpinnerIcon className="w-5 h-5" /> : <SparklesIcon className="w-5 h-5" />}
                                    {currentSolutionState?.isLoading ? 'Loading...' : isSolutionVisible ? 'Hide Solution' : 'Show Solution'}
                                </button>
                            </div>
                        </div>

                        {isSolutionVisible && (
                             <div className="mt-6 glass-effect p-6 rounded-lg animate-slide-in-bottom">
                                <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">AI-Generated Solution</h3>
                                {currentSolutionState?.isLoading && <div className="flex justify-center py-8"><SpinnerIcon className="w-8 h-8 text-purple-600"/></div>}
                                {currentSolutionState?.error && <div className="text-red-500 bg-red-50 dark:bg-red-900/20 p-4 rounded-md">{currentSolutionState?.error}</div>}
                                {currentSolutionState?.solution && (
                                    <div 
                                        className="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-200"
                                        dangerouslySetInnerHTML={{ __html: renderMarkdown(currentSolutionState.solution) }}
                                    />
                                )}
                            </div>
                        )}
                    </div>
                ) : (
                    // Question List View
                    <>
                        <div className="text-center mb-12">
                            <h1 className="text-5xl font-bold text-gray-800 dark:text-white">{topic.name}</h1>
                            <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">{topic.description}</p>
                        </div>

                        <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                             <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Practice Problems</h2>
                            <div className="flex items-center gap-2 glass-effect p-1 rounded-full">
                                {difficultyButtons.map(difficulty => (
                                    <button
                                        key={difficulty}
                                        onClick={() => handleDifficultyChange(difficulty)}
                                        className={`px-4 py-1.5 text-sm font-semibold rounded-full transition-colors ${
                                            selectedDifficulty === difficulty ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900' : 'text-gray-600 hover:bg-black/5 dark:text-gray-300 dark:hover:bg-white/5'
                                        }`}
                                    >
                                        {difficulty}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="min-h-[300px]">
                            {isLoading ? (
                                <div className="flex items-center justify-center h-full py-12"><SpinnerIcon className="w-12 h-12 text-purple-600" /></div>
                            ) : error ? (
                                <div className="text-center text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-6 rounded-lg"><p className="font-semibold">Error</p><p>{error}</p></div>
                            ) : (
                                <div className="space-y-4">
                                    {questions.map((question, index) => {
                                        const problemId = `${topic.id}:${question}`;
                                        const isSaved = savedProblems.some(p => p.id === problemId);
                                        return (
                                            <div
                                                key={index}
                                                className="glass-effect aurora-effect rounded-lg p-6 flex items-start justify-between gap-4 transition-transform duration-300 hover:-translate-y-1 animate-slide-in-bottom group"
                                                style={{ animationDelay: `${index * 75}ms` }}
                                            >
                                                <div 
                                                    className="flex items-start gap-4 flex-grow cursor-pointer"
                                                    onClick={() => handleSelectQuestion(index)}
                                                    role="button"
                                                    tabIndex={0}
                                                    onKeyDown={(e) => e.key === 'Enter' && handleSelectQuestion(index)}
                                                >
                                                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center font-bold text-purple-700 dark:text-purple-200 mt-1">
                                                        {index + 1}
                                                    </div>
                                                    <p className="text-gray-700 dark:text-gray-200 leading-relaxed pt-1 flex-grow">
                                                        {question}
                                                    </p>
                                                </div>
                                                <button 
                                                    onClick={() => toggleSaveProblem(question)}
                                                    className={`p-2 rounded-full transition-colors flex-shrink-0 ${
                                                        isSaved 
                                                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300' 
                                                            : 'bg-black/5 text-gray-700 hover:bg-black/10 dark:bg-white/5 dark:text-gray-200 dark:hover:bg-white/10'
                                                    }`}
                                                    aria-label={isSaved ? 'Unsave problem' : 'Save problem'}
                                                >
                                                    <BookmarkIcon className="w-5 h-5" filled={isSaved} />
                                                </button>
                                            </div>
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};