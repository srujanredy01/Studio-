
import React from 'react';
import { TwitterIcon } from './icons/ShareIcons';
import type { TeamMember } from '../types';
import { useAppContext } from '../context/DataContext';

interface AboutPageProps {}

const LinkedInIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14zm-12 6v8h3v-4.5c0-1.2.9-2.5 2.5-2.5s2.5 1.3 2.5 2.5V17h3v-8h-3v1.1c-.5-.8-1.4-1.6-2.5-1.6C8.9 8.5 7 9.8 7 12zM5 8v1h3V8H5z"/>
    </svg>
);


export const AboutPage: React.FC<AboutPageProps> = () => {
    const { teamMembers } = useAppContext();
    return (
        <div className="min-h-[calc(100vh-280px)]">
            {/* Hero Section */}
            <section className="py-20 bg-white dark:bg-gray-800">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl md:text-6xl font-bold text-gray-800 dark:text-white">Our Mission</h1>
                    <p className="mt-6 max-w-3xl mx-auto text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                        To provide a centralized, modern, and accessible hub for all LPU students, empowering them with the resources, coding solutions, and news they need to excel in their academic journey.
                    </p>
                </div>
            </section>

            {/* Our Story Section */}
            <section className="py-24">
                <div className="container mx-auto px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                    <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop" alt="Team collaborating" className="rounded-2xl shadow-xl w-full h-full object-cover" />
                    <div>
                        <h2 className="text-4xl font-bold text-gray-800 dark:text-white">The Story Behind LPU Studio</h2>
                        <p className="mt-4 text-gray-600 dark:text-gray-300 leading-relaxed">
                            LPU Studio was born from a simple idea: to make student life easier. As former students, we remember the challenge of searching across different platforms for notes, coding examples, and campus updates. We envisioned a single place where everything was organized, reliable, and easy to find.
                        </p>
                        <p className="mt-4 text-gray-600 dark:text-gray-300 leading-relaxed">
                            Starting as a small passion project, it quickly grew into the comprehensive resource hub you see today. Our team is dedicated to continuously improving the platform and adding new features that truly matter to students.
                        </p>
                    </div>
                </div>
            </section>

            {/* Meet the Team Section */}
            <section className="py-24 bg-white dark:bg-gray-800">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h2 className="text-4xl font-bold text-gray-800 dark:text-white">Meet the Team</h2>
                    <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">The passionate individuals dedicated to enhancing your student experience.</p>
                    <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                        {teamMembers.map(member => (
                            <div key={member.name} className="flex flex-col items-center">
                                <img src={member.imageUrl} alt={`Profile of ${member.name}`} className="w-32 h-32 rounded-full object-cover shadow-lg mb-4" />
                                <h3 className="text-2xl font-bold text-gray-800 dark:text-white">{member.name}</h3>
                                <p className="text-[#B5651D] font-semibold mb-2">{member.role}</p>
                                <p className="text-gray-600 dark:text-gray-400 max-w-xs">{member.bio}</p>
                                <div className="flex items-center gap-3 mt-4">
                                    <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-blue-500 transition-colors">
                                        <TwitterIcon className="w-6 h-6" />
                                    </a>
                                    <a href="#" aria-label="LinkedIn" className="text-gray-400 hover:text-blue-700 transition-colors">
                                        <LinkedInIcon className="w-6 h-6" />
                                    </a>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
};