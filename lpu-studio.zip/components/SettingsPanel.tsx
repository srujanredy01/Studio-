
import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import type { AspectRatio } from '../types';

interface SettingsPanelProps {
    prompt: string;
    setPrompt: (prompt: string) => void;
    aspectRatio: AspectRatio;
    setAspectRatio: (ratio: AspectRatio) => void;
    isLoading: boolean;
    onGenerate: () => void;
}

// FIX: Update aspect ratios to only include values supported by video generation API.
const aspectRatios: { label: string; value: AspectRatio }[] = [
    { label: '16 : 9 (Landscape)', value: '16:9' },
    { label: '9 : 16 (Portrait)', value: '9:16' },
];

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
    prompt,
    setPrompt,
    aspectRatio,
    setAspectRatio,
    isLoading,
    onGenerate
}) => {
    return (
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 flex flex-col gap-6 h-full">
            <div>
                <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">
                    Prompt
                </label>
                <textarea
                    id="prompt"
                    rows={6}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="A cinematic shot of a hamster in a space suit, walking on mars..."
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all resize-none"
                    disabled={isLoading}
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                    Aspect Ratio
                </label>
                {/* FIX: Update grid columns to match the number of available aspect ratios. */}
                <div className="grid grid-cols-2 gap-2">
                    {aspectRatios.map(({ label, value }) => (
                        <button
                            key={value}
                            onClick={() => setAspectRatio(value)}
                            disabled={isLoading}
                            className={`py-2 px-1 text-xs sm:text-sm font-semibold rounded-md transition-colors duration-200 disabled:opacity-50 ${
                                aspectRatio === value
                                    ? 'bg-purple-600 text-white'
                                    : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                            }`}
                        >
                            {label}
                        </button>
                    ))}
                </div>
            </div>

            <button
                onClick={onGenerate}
                disabled={isLoading || !prompt.trim()}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-purple-600/50 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
            >
                <SparklesIcon className="w-5 h-5" />
                <span>{isLoading ? 'Generating...' : 'Generate'}</span>
            </button>
        </div>
    );
};
