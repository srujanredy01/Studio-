

import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import type { User, ResourceFile, NewsArticle } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/ProfileIcons';

interface AIRecommendationsProps {
    user: User;
    resources: ResourceFile[];
    newsArticles: NewsArticle[];
}

type Recommendation = {
    type: 'resource' | 'news';
    name: string;
    reason: string;
};

type LoadingState = 'idle' | 'loading' | 'success' | 'error';

export const AIRecommendations: React.FC<AIRecommendationsProps> = ({ user, resources, newsArticles }) => {
    const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
    const [loadingState, setLoadingState] = useState<LoadingState>('idle');

    useEffect(() => {
        const hasProfile = user.year || (user.interests && user.interests.length > 0);
        if (user.name === 'Guest' || !hasProfile) {
            setRecommendations([]);
            setLoadingState('idle');
            return;
        }

        const fetchRecommendations = async () => {
            setLoadingState('loading');
            const cacheKey = `ai-recs-${JSON.stringify({ year: user.year, interests: user.interests })}`;
            
            try {
                const cachedData = localStorage.getItem(cacheKey);
                if (cachedData) {
                    setRecommendations(JSON.parse(cachedData));
                    setLoadingState('success');
                    return;
                }

                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

                const resourceNames = resources.map(r => `"${r.name}"`).join(', ');
                const newsTitles = newsArticles.map(n => `"${n.title}"`).join(', ');

                const systemInstruction = `You are a helpful assistant for LPU Studio, a website for university students. Your task is to provide personalized content recommendations from a provided list of resources and news articles.`;
                const userPrompt = `
                    Based on the following user profile, please recommend 3-4 relevant items from the lists provided.
                    
                    User Profile:
                    - Year: ${user.year || 'Not specified'}
                    - Interests: ${user.interests?.join(', ') || 'Not specified'}

                    Available Resources:
                    [${resourceNames}]

                    Available News Articles:
                    [${newsTitles}]

                    Your response must be in the specified JSON format.
                    The 'name' in your response must EXACTLY match a name or title from the lists provided.
                    The 'reason' should be a short, compelling explanation (max 15 words) for why the user would find it useful.
                `;
                
                const responseSchema = {
                    type: Type.OBJECT,
                    properties: {
                        recommendations: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    type: { type: Type.STRING, description: 'Either "resource" or "news".' },
                                    name: { type: Type.STRING, description: 'The exact name or title of the item from the provided lists.' },
                                    reason: { type: Type.STRING, description: 'A short reason for the recommendation (max 15 words).' }
                                },
                                required: ["type", "name", "reason"],
                            }
                        }
                    },
                    required: ["recommendations"]
                };

                const response = await ai.models.generateContent({
                    model: "gemini-2.5-flash",
                    contents: userPrompt,
                    config: {
                        systemInstruction,
                        responseMimeType: "application/json",
                        responseSchema,
                    },
                });

                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr);
                
                if (result.recommendations && result.recommendations.length > 0) {
                    setRecommendations(result.recommendations);
                    localStorage.setItem(cacheKey, JSON.stringify(result.recommendations));
                    setLoadingState('success');
                } else {
                   setLoadingState('error'); 
                }

            } catch (e) {
                console.error("AI Recommendation Error:", e);
                setLoadingState('error');
            }
        };

        fetchRecommendations();

    }, [user, resources, newsArticles]);

    if (loadingState === 'idle' || user.name === 'Guest') {
        return null; // Don't show the component if user is a guest or has no profile info
    }

    return (
        <section className="py-24">
            <div className="container mx-auto px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-4xl font-bold text-gray-800 dark:text-white flex items-center justify-center gap-3">
                        <SparklesIcon className="w-8 h-8 text-purple-600 dark:text-purple-300" />
                        AI Recommendations For You
                    </h2>
                    <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">Personalized suggestions based on your profile.</p>
                </div>

                {loadingState === 'loading' && (
                    <div className="flex justify-center items-center h-48">
                        <SpinnerIcon className="w-12 h-12 text-purple-600"/>
                    </div>
                )}
                
                {loadingState === 'error' && (
                     <div className="text-center text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-4 rounded-lg">
                        <p>Sorry, we couldn't generate recommendations at this time. Please try again later.</p>
                    </div>
                )}

                {loadingState === 'success' && recommendations.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {recommendations.map((rec, index) => (
                            <div key={index} className="glass-effect p-6 rounded-xl flex flex-col hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                                <span className={`text-xs font-bold uppercase px-2.5 py-1 rounded-full self-start mb-3 ${
                                    rec.type === 'resource' 
                                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300' 
                                    : 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300'
                                }`}>
                                    {rec.type}
                                </span>
                                <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{rec.name}</h3>
                                <p className="text-gray-600 dark:text-gray-400 flex-grow">"{rec.reason}"</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </section>
    );
};
