
import React, { useState, useEffect } from 'react';
import { InstagramIcon, WhatsAppIcon, MailIcon } from './icons/SocialIcons';
import { trackEvent } from '../analytics';
import { LockIcon } from './icons/LockIcon';
import { SpinnerIcon, CheckIcon } from './icons/ProfileIcons';
import { useAppContext } from '../context/DataContext';

interface FooterProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentView }) => {
    const { user } = useAppContext();
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

    useEffect(() => {
        if (localStorage.getItem('newsletterSubscribed') === 'true') {
            setStatus('success');
        }
    }, []);

    const validateEmail = (email: string) => {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    };

    const handleSubscribe = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!validateEmail(email)) {
            setError('Please enter a valid email address.');
            setStatus('error');
            return;
        }

        setStatus('submitting');
        trackEvent('featureUse', 'newsletter_subscribe', { email });

        // Simulate API call
        setTimeout(() => {
            localStorage.setItem('newsletterSubscribed', 'true');
            setStatus('success');
            setEmail('');
        }, 1500);
    };

    return (
        <footer className="glass-effect mt-24">
            <div className="container mx-auto px-6 lg:px-8 py-16">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
                    {/* Menu */}
                    <div className="lg:col-span-1">
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Menu</h3>
                        <nav className="flex flex-col gap-2">
                            <button onClick={() => setCurrentView('home')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors" title="Go to Home (Alt+1)">Home</button>
                            <button onClick={() => setCurrentView('resources')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors" title="Go to Resources (Alt+2)">Resources</button>
                            <button onClick={() => setCurrentView('coding')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors flex items-center gap-2" title="Go to Coding (Alt+3)">
                                Coding
                                {user.name === 'Guest' && <LockIcon className="w-3 h-3 text-gray-400" />}
                            </button>
                            <button onClick={() => setCurrentView('news')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors flex items-center gap-2" title="Go to News (Alt+4)">
                                News
                                {user.name === 'Guest' && <LockIcon className="w-3 h-3 text-gray-400" />}
                            </button>
                            <button onClick={() => setCurrentView('profile')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors" title="Go to Profile (Alt+8)">Profile</button>
                            <button onClick={() => setCurrentView('about')} className="text-left text-gray-600 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition-colors" title="Go to About (Alt+6)">About Us</button>
                            <button onClick={() => setCurrentView('admin')} className="text-left text-gray-500 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors mt-2" title="Go to Admin (Alt+7)">Admin</button>
                        </nav>
                    </div>

                    {/* Contacts & Socials */}
                    <div>
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Contacts</h3>
                        <p className="text-gray-600 dark:text-gray-300">lpustudio2005@gmail.com</p>
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mt-6 mb-4">Socials</h3>
                         <div className="flex items-center gap-3">
                            <a href="https://www.instagram.com/lpu.studio/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="w-10 h-10 rounded-full flex items-center justify-center glass-effect aurora-effect">
                                <InstagramIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                            </a>
                            <a href="https://whatsapp.com/channel/0029VajDVQo3WHTb3T23oE1I" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="w-10 h-10 rounded-full flex items-center justify-center glass-effect aurora-effect">
                                <WhatsAppIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                            </a>
                            <a href="mailto:lpustudio2005@gmail.com" aria-label="Email" className="w-10 h-10 rounded-full flex items-center justify-center glass-effect aurora-effect">
                                <MailIcon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                            </a>
                        </div>
                    </div>

                    {/* Newsletter */}
                    <div className="md:col-span-2 lg:col-span-2">
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Subscribe to our newsletter</h3>
                        {status === 'success' ? (
                            <div className="text-center bg-green-100 dark:bg-green-900/50 p-6 rounded-lg">
                                <CheckIcon className="w-10 h-10 mx-auto text-green-600 dark:text-green-300 mb-3" />
                                <h4 className="font-bold text-lg text-green-800 dark:text-green-200">Thank You for Subscribing!</h4>
                                <p className="text-sm text-green-700 dark:text-green-300">You're on the list. Look out for updates from us.</p>
                            </div>
                        ) : (
                            <form onSubmit={handleSubscribe} className="flex flex-col gap-4">
                                <div>
                                    <label htmlFor="email-address" className="block text-sm font-medium mb-1 text-gray-600 dark:text-gray-300">Email <span className="text-red-400">*</span></label>
                                    <input
                                        type="email"
                                        id="email-address"
                                        name="email-address"
                                        autoComplete="email"
                                        required
                                        className={`w-full glass-effect rounded-lg py-2 px-3 text-gray-800 dark:text-white focus:ring-1 placeholder-gray-500 dark:placeholder-gray-400 ${status === 'error' ? 'border-red-500 ring-red-500' : 'focus:ring-purple-500 focus:border-purple-500'}`}
                                        placeholder="your@email.com"
                                        value={email}
                                        onChange={(e) => {
                                            setEmail(e.target.value);
                                            if (status === 'error') {
                                                setStatus('idle');
                                                setError('');
                                            }
                                        }}
                                        disabled={status === 'submitting'}
                                    />
                                    {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                                </div>
                                <button
                                    type="submit"
                                    className={`glass-button aurora-effect w-full transition-all flex items-center justify-center`}
                                    disabled={status === 'submitting'}
                                >
                                    {status === 'submitting' ? (
                                        <>
                                            <SpinnerIcon className="w-5 h-5 mr-2" />
                                            Subscribing...
                                        </>
                                    ) : 'Subscribe'}
                                </button>
                            </form>
                        )}
                    </div>
                </div>
            </div>
            <div className="border-t border-white/20 dark:border-white/10">
                <div className="container mx-auto px-6 lg:px-8 py-6 text-center text-gray-500 dark:text-gray-400 text-sm">
                     <div className="flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-4">
                        <p>&copy; {new Date().getFullYear()} LPU Studio. All rights reserved.</p>
                        <button onClick={() => setCurrentView('about')} className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors" title="Go to About (Alt+6)">About Us</button>
                    </div>
                </div>
            </div>
        </footer>
    );
};