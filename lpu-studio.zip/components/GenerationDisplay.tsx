
import React from 'react';
import { VideoIcon } from './icons/VideoIcon';

interface GenerationDisplayProps {
    isLoading: boolean;
    loadingMessage: string;
    videoUrl: string | null;
    error: string | null;
}

const LoadingIndicator: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
        <div className="w-16 h-16 border-4 border-t-purple-500 border-gray-700 rounded-full animate-spin"></div>
        <p className="text-lg font-medium text-gray-300">{message}</p>
        <p className="text-sm text-gray-500">Video generation can take several minutes.</p>
    </div>
);

const Placeholder: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full gap-4 text-gray-600">
        <VideoIcon className="w-24 h-24" />
        <p className="text-xl font-medium">Your generation will appear here</p>
    </div>
);

const ErrorDisplay: React.FC<{ message: string }> = ({ message }) => (
     <div className="flex flex-col items-center justify-center h-full gap-4 text-center text-red-400">
        <p className="text-xl font-bold">Generation Failed</p>
        <p className="bg-red-900/50 border border-red-500 p-4 rounded-md">{message}</p>
    </div>
);

export const GenerationDisplay: React.FC<GenerationDisplayProps> = ({ isLoading, loadingMessage, videoUrl, error }) => {
    return (
        <div className="w-full h-full bg-gray-900/50 border border-gray-800 rounded-2xl p-4 flex items-center justify-center aspect-[16/9]">
            {isLoading ? (
                <LoadingIndicator message={loadingMessage} />
            ) : error ? (
                <ErrorDisplay message={error} />
            ) : videoUrl ? (
                <video src={videoUrl} controls autoPlay loop className="w-full h-full object-contain rounded-lg">
                    Your browser does not support the video tag.
                </video>
            ) : (
                <Placeholder />
            )}
        </div>
    );
};