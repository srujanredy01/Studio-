
import React from 'react';

interface ApiKeySelectorProps {
    onSelectKey: () => void;
    error: string | null;
}

export const ApiKeySelector: React.FC<ApiKeySelectorProps> = ({ onSelectKey, error }) => {
    return (
        <div className="bg-black min-h-screen flex flex-col items-center justify-center text-white p-4">
            <div className="w-full max-w-md bg-gray-900 border border-gray-700 rounded-lg p-8 text-center shadow-2xl">
                <h1 className="text-2xl font-bold mb-4">Welcome to LPU Studio Clone</h1>
                <p className="text-gray-400 mb-6">To start generating videos, you need to select a Google AI API key. Your key will be used for all requests.</p>
                {error && <p className="bg-red-900/50 border border-red-500 text-red-300 p-3 rounded-md mb-6">{error}</p>}
                <button
                    onClick={onSelectKey}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-colors text-lg"
                >
                    Select API Key
                </button>
                <p className="text-xs text-gray-500 mt-6">
                    By using this service, you agree to the terms and conditions. Please be aware that usage of the Gemini API may incur costs. For more information on billing, visit{' '}
                    <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                        ai.google.dev/gemini-api/docs/billing
                    </a>.
                </p>
            </div>
        </div>
    );
};