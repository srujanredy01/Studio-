import React, { useState, useEffect, useRef } from 'react';
import type { User, Year, ResourceFile, NewsArticle, CodingTopic } from '../types';
import { UserIcon, IdCardIcon, CalendarIcon, CheckIcon, SpinnerIcon, HeartIcon, CameraIcon } from './icons/ProfileIcons';
import { TrashIcon } from './icons/ActionIcons';
import { trackEvent } from '../analytics';
import { ConfirmationModal } from './ConfirmationModal';
import {
    getSavedNewsIdsForUser,
    saveNewsIdsForUser,
    getSavedResourceIdsForUser,
    saveResourceIdsForUser,
    getSavedCodingTopicIdsForUser,
    saveCodingTopicIdsForUser,
} from '../data/userData';
import { useAppContext } from '../context/DataContext';

interface UserProfileProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

const DownloadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24" strokeWidth={2} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);


const yearOptions: Year[] = ['1st year', '2nd year', '3rd year', '4th year'];
const availableInterests = ['AI/ML', 'Web Development', 'Cyber Security', 'Data Science', 'Cloud Computing', 'Project Management', 'Programming', 'Algorithms'];

type SaveState = 'idle' | 'saving' | 'saved';

export const UserProfile: React.FC<UserProfileProps> = ({ setCurrentView }) => {
    const { user, setUser, resources, newsArticles, codingTopics, allUsers, setAllUsers } = useAppContext();
    const [name, setName] = useState(user.name === 'Guest' ? '' : user.name);
    const [idNumber, setIdNumber] = useState(user.idNumber || '');
    const [year, setYear] = useState<Year | null>(user.year);
    const [interests, setInterests] = useState(user.interests || []);
    const [profilePicture, setProfilePicture] = useState(user.profilePicture || null);
    const [saveState, setSaveState] = useState<SaveState>('idle');
    const [idError, setIdError] = useState('');
    const [savedResources, setSavedResources] = useState<ResourceFile[]>([]);
    const [savedNews, setSavedNews] = useState<NewsArticle[]>([]);
    const [savedCodingTopics, setSavedCodingTopics] = useState<CodingTopic[]>([]);
    const [isRemovePictureModalOpen, setIsRemovePictureModalOpen] = useState(false);
    
    // State for confirmation modals
    const [itemToRemove, setItemToRemove] = useState<{type: 'resource' | 'news' | 'coding', id: number | string} | null>(null);
    const [isUnsaveConfirmModalOpen, setIsUnsaveConfirmModalOpen] = useState(false);
    const [justRemovedId, setJustRemovedId] = useState<number | string | null>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const isGuest = user.name === 'Guest';

    useEffect(() => {
        if (!user.idNumber) {
            setSavedResources([]);
            setSavedNews([]);
            setSavedCodingTopics([]);
            return;
        };
        const resourceIds = getSavedResourceIdsForUser(user.idNumber);
        setSavedResources(resources.filter(r => resourceIds.includes(r.id)));
        
        const newsIds = getSavedNewsIdsForUser(user.idNumber);
        setSavedNews(newsArticles.filter(a => newsIds.includes(a.id)));

        const codingIds = getSavedCodingTopicIdsForUser(user.idNumber);
        setSavedCodingTopics(codingTopics.filter(c => codingIds.includes(c.id)));
    }, [resources, newsArticles, codingTopics, user.idNumber]);

    const handleUnsaveResource = (id: number) => {
        if (!user.idNumber) return;
        const resource = savedResources.find(r => r.id === id);
        trackEvent('featureUse', 'unsave_resource_from_profile', { resourceId: id, resourceName: resource?.name });
        
        const currentSavedIds = getSavedResourceIdsForUser(user.idNumber);
        const updatedSavedIds = currentSavedIds.filter(savedId => savedId !== id);
        saveResourceIdsForUser(user.idNumber, updatedSavedIds);
        
        setSavedResources(prev => prev.filter(r => r.id !== id));
    };

    const handleUnsaveNews = (id: number) => {
        if (!user.idNumber) return;
        const article = savedNews.find(a => a.id === id);
        trackEvent('featureUse', 'unsave_article_from_profile', { articleId: id, articleTitle: article?.title });

        const currentSavedIds = getSavedNewsIdsForUser(user.idNumber);
        const updatedSavedIds = currentSavedIds.filter(savedId => savedId !== id);
        saveNewsIdsForUser(user.idNumber, updatedSavedIds);
        
        setSavedNews(prev => prev.filter(a => a.id !== id));
    };

    const handleUnsaveCodingTopic = (id: string) => {
        if (!user.idNumber) return;
        const topic = savedCodingTopics.find(t => t.id === id);
        trackEvent('featureUse', 'unsave_coding_topic_from_profile', { topicId: id, topicName: topic?.name });

        const currentSavedIds = getSavedCodingTopicIdsForUser(user.idNumber);
        const updatedSavedIds = currentSavedIds.filter(savedId => savedId !== id);
        saveCodingTopicIdsForUser(user.idNumber, updatedSavedIds);
        
        setSavedCodingTopics(prev => prev.filter(t => t.id !== id));
    };

    const handleUnsaveClick = (type: 'resource' | 'news' | 'coding', id: number | string) => {
        setItemToRemove({ type, id });
        setIsUnsaveConfirmModalOpen(true);
    };
    
    const handleConfirmUnsave = () => {
        if (!itemToRemove) return;
        
        const { type, id } = itemToRemove;

        // Trigger animation
        setJustRemovedId(id);
        setIsUnsaveConfirmModalOpen(false);

        // Delay actual removal for animation
        setTimeout(() => {
            if (type === 'resource') {
                handleUnsaveResource(id as number);
            } else if (type === 'news') {
                handleUnsaveNews(id as number);
            } else if (type === 'coding') {
                handleUnsaveCodingTopic(id as string);
            }

            // Reset state after animation
            setItemToRemove(null);
            setJustRemovedId(null);
        }, 400); // Match animation duration in index.html
    };

    // Sync local state with user prop to prevent inconsistencies
    useEffect(() => {
        setName(user.name === 'Guest' ? '' : user.name);
        setIdNumber(user.idNumber || '');
        setYear(user.year);
        setInterests(user.interests || []);
        setProfilePicture(user.profilePicture || null);
    }, [user]);

    const handleInterestToggle = (interest: string) => {
        setInterests(prev => 
            prev.includes(interest) 
                ? prev.filter(i => i !== interest) 
                : [...prev, interest]
        );
    };

     const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfilePicture(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemovePictureClick = () => {
        setIsRemovePictureModalOpen(true);
    };

    const handleConfirmRemovePicture = () => {
        setProfilePicture(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = ""; // Reset file input
        }
        setIsRemovePictureModalOpen(false);
    };

    useEffect(() => {
        // Handle the save state transitions and redirection with cleanup.
        if (saveState === 'idle') return;

        let saveTimer: ReturnType<typeof setTimeout>;
        let redirectTimer: ReturnType<typeof setTimeout>;

        if (saveState === 'saving') {
            // Simulate API call delay
            saveTimer = setTimeout(() => {
                setSaveState('saved');
            }, 1000);
        } else if (saveState === 'saved') {
            // Redirect after showing "Saved!" message
            redirectTimer = setTimeout(() => {
                setCurrentView('home');
            }, 750);
        }

        // Cleanup function to clear timers if the component unmounts
        return () => {
            clearTimeout(saveTimer);
            clearTimeout(redirectTimer);
        };
    }, [saveState, setCurrentView]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIdError('');
        const newIdNumber = idNumber.trim();

        // Check for duplicates, excluding the current user's original ID
        if (newIdNumber && allUsers.some(u => u.idNumber === newIdNumber && u.idNumber !== user.idNumber)) {
            setIdError('This Student ID is already in use. Please enter a different one.');
            return;
        }

        trackEvent('featureUse', 'update_profile', { hasProfilePicture: !!profilePicture, interestCount: interests.length, yearSet: !!year });

        const updatedUser: User = {
            // Important to spread the original user object to keep loginCount/lastLogin
            ...user,
            name: name.trim() === '' ? 'Guest' : name,
            idNumber: newIdNumber,
            year,
            interests,
            profilePicture,
        };

        setUser(updatedUser);

        setAllUsers(prevUsers => {
            // Find user by their original ID number, if it existed.
            // This handles ID number changes.
            const userIndex = user.idNumber ? prevUsers.findIndex(u => u.idNumber === user.idNumber) : -1;
            
            if (userIndex > -1) {
                // Update existing user in the list
                const newAllUsers = [...prevUsers];
                newAllUsers[userIndex] = updatedUser;
                return newAllUsers;
            } else if (updatedUser.name !== 'Guest' && updatedUser.idNumber) {
                // Add new user if they are not a guest and have an ID
                // This handles the transition from Guest to a registered user
                return [...prevUsers, updatedUser];
            }
            // If no ID, don't add to the master list.
            return prevUsers;
        });

        setSaveState('saving');
    };


    const inputClasses = "w-full glass-effect rounded-lg py-3 pr-4 pl-12 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors";
    const iconClasses = "absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400";

    const getButtonContent = () => {
        switch (saveState) {
            case 'saving':
                return (
                    <>
                        <SpinnerIcon className="w-5 h-5 mr-2" />
                        Saving...
                    </>
                );
            case 'saved':
                return (
                    <>
                        <CheckIcon className="w-5 h-5 mr-2" />
                        Saved!
                    </>
                );
            case 'idle':
            default:
                return 'Save Profile';
        }
    }

    return (
        <div className="min-h-[calc(100vh-280px)]">
            <section className="py-16">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl font-bold text-gray-800 dark:text-white">
                        {isGuest ? 'Create Your Profile' : 'Your Profile'}
                    </h1>
                    <p className="mt-4 max-w-2xl mx-auto text-gray-600 dark:text-gray-300">
                        {isGuest 
                            ? 'Create a profile to download resources, save content, and get personalized recommendations.' 
                            : 'Customize your experience by saving your preferences.'}
                    </p>
                </div>
            </section>

            <section className="py-12">
                <div className="container mx-auto px-6 lg:px-8 max-w-2xl">
                    <div className="glass-effect p-6 sm:p-8 rounded-xl">
                        <div className="flex flex-col items-center mb-8">
                            <div className="relative">
                                <div className="relative w-28 h-28 p-1 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500">
                                    {profilePicture ? (
                                        <img src={profilePicture} alt="Profile" className="w-full h-full rounded-full object-cover border-4 border-white dark:border-gray-800" />
                                    ) : (
                                        <div className="w-full h-full bg-purple-100 dark:bg-gray-700 rounded-full flex items-center justify-center border-4 border-white dark:border-gray-800">
                                            <UserIcon className="w-14 h-14 text-purple-600 dark:text-purple-300" />
                                        </div>
                                    )}
                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        className="absolute bottom-0 right-0 w-9 h-9 bg-gray-700 text-white rounded-full flex items-center justify-center border-2 border-white dark:border-gray-800 hover:bg-gray-800 transition-colors"
                                        aria-label="Upload or change profile picture"
                                        title="Upload Picture"
                                    >
                                        <CameraIcon className="w-5 h-5" />
                                    </button>
                                    {profilePicture && (
                                        <button
                                            type="button"
                                            onClick={handleRemovePictureClick}
                                            className="absolute top-0 right-0 w-9 h-9 bg-red-600 text-white rounded-full flex items-center justify-center border-2 border-white dark:border-gray-800 hover:bg-red-700 transition-colors"
                                            aria-label="Remove profile picture"
                                            title="Remove Picture"
                                        >
                                            <TrashIcon className="w-5 h-5" />
                                        </button>
                                    )}
                                </div>
                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    onChange={handleFileChange}
                                    accept="image/png, image/jpeg"
                                    className="hidden"
                                />
                            </div>
                            <div className="flex items-center gap-4 mt-4">
                                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                                    {name.trim() === '' ? 'Guest' : name}
                                </h2>
                            </div>
                        </div>


                        <form onSubmit={handleSubmit} className="space-y-6">
                            {/* Name Input */}
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Display Name</label>
                                <div className="relative">
                                    <UserIcon className={iconClasses} />
                                    <input
                                        type="text"
                                        id="name"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                        className={inputClasses}
                                        placeholder="Enter your name"
                                        required
                                    />
                                </div>
                            </div>

                            {/* ID Number Input */}
                             <div>
                                <label htmlFor="idNumber" className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Student ID Number</label>
                                 <div className="relative">
                                    <IdCardIcon className={iconClasses} />
                                    <input
                                        type="text"
                                        id="idNumber"
                                        value={idNumber}
                                        onChange={(e) => setIdNumber(e.target.value)}
                                        className={inputClasses}
                                        placeholder="e.g., 12345678"
                                    />
                                </div>
                                {idError && <p className="text-red-500 text-xs mt-2">{idError}</p>}
                            </div>
                           
                             {/* Year Select */}
                             <div>
                                <label htmlFor="year" className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Your Academic Year</label>
                                <div className="relative">
                                    <CalendarIcon className={iconClasses} />
                                    <select
                                        id="year"
                                        value={year || ''}
                                        onChange={(e) => setYear(e.target.value as Year)}
                                        className={`${inputClasses} appearance-none`}
                                    >
                                        <option value="">-- Select Your Year --</option>
                                        {yearOptions.map(y => <option key={y} value={y}>{y}</option>)}
                                    </select>
                                </div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Selecting your year will personalize the Resources page for you.</p>
                            </div>

                             {/* Interests Select */}
                             <div>
                                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Your Interests</label>
                                <div className="relative">
                                    <HeartIcon className={iconClasses} />
                                    <div className="w-full glass-effect rounded-lg p-3 pl-12 min-h-[50px] flex items-center">
                                        <div className="flex flex-wrap gap-2">
                                            {availableInterests.map(interest => (
                                                <button
                                                    type="button"
                                                    key={interest}
                                                    onClick={() => handleInterestToggle(interest)}
                                                    className={`px-3 py-1 text-xs sm:text-sm font-semibold rounded-full transition-all duration-200 border-2 ${
                                                        interests.includes(interest) 
                                                            ? 'bg-purple-600 text-white border-transparent' 
                                                            : 'bg-black/5 text-gray-700 hover:bg-black/10 dark:bg-white/5 dark:text-gray-200 dark:hover:bg-white/10 border-transparent'
                                                    }`}
                                                >
                                                    {interest}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Selecting interests will help us recommend relevant content for you.</p>
                            </div>


                            {/* Save Button */}
                            <div className="flex items-center justify-end pt-4">
                                <button 
                                    type="submit" 
                                    disabled={saveState === 'saving' || saveState === 'saved'}
                                    className={`inline-flex items-center justify-center min-w-[140px] glass-button primary disabled:opacity-70 disabled:cursor-not-allowed ${saveState === 'saved' ? '!bg-green-600' : ''}`}
                                >
                                   {getButtonContent()}
                                </button>
                            </div>
                        </form>
                    </div>

                    <div className="glass-effect p-6 sm:p-8 rounded-xl mt-8">
                        <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Saved Resources</h3>
                        {savedResources.length > 0 ? (
                            <ul className="space-y-3">
                                {savedResources.map(resource => (
                                    <li key={resource.id} className={`flex flex-wrap gap-2 justify-between items-center bg-black/5 dark:bg-white/5 p-4 rounded-lg transition-all duration-300 ${justRemovedId === resource.id ? 'animate-fade-out' : ''}`}>
                                        <span className="font-medium text-gray-700 dark:text-gray-200">{resource.name}</span>
                                        <div className="flex items-center gap-2 flex-shrink-0">
                                            <a href={resource.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                <DownloadIcon className="w-4 h-4" />
                                                Download
                                            </a>
                                            <button onClick={() => handleUnsaveClick('resource', resource.id)} className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                <TrashIcon className="w-4 h-4"/>
                                                Remove
                                            </button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500 dark:text-gray-400 py-4">You haven't saved any resources yet. Visit the Resources page to add some!</p>
                        )}
                    </div>
                    
                    <div className="glass-effect p-6 sm:p-8 rounded-xl mt-8">
                        <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Saved News Articles</h3>
                        {savedNews.length > 0 ? (
                            <ul className="space-y-3">
                                {savedNews.map(article => (
                                    <li key={article.id} className={`flex flex-wrap gap-2 justify-between items-center bg-black/5 dark:bg-white/5 p-4 rounded-lg transition-all duration-300 ${justRemovedId === article.id ? 'animate-fade-out' : ''}`}>
                                        <span className="font-medium text-gray-700 dark:text-gray-200">{article.title}</span>
                                        <div className="flex items-center gap-2 flex-shrink-0">
                                            <button onClick={() => setCurrentView('news')} className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                Read
                                            </button>
                                            <button onClick={() => handleUnsaveClick('news', article.id)} className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                <TrashIcon className="w-4 h-4"/>
                                                Remove
                                            </button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500 dark:text-gray-400 py-4">You haven't saved any news articles yet. Visit the News page to add some!</p>
                        )}
                    </div>

                    <div className="glass-effect p-6 sm:p-8 rounded-xl mt-8">
                        <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Saved Coding Topics</h3>
                        {savedCodingTopics.length > 0 ? (
                            <ul className="space-y-3">
                                {savedCodingTopics.map(topic => (
                                    <li key={topic.id} className={`flex flex-wrap gap-2 justify-between items-center bg-black/5 dark:bg-white/5 p-4 rounded-lg transition-all duration-300 ${justRemovedId === topic.id ? 'animate-fade-out' : ''}`}>
                                        <span className="font-medium text-gray-700 dark:text-gray-200">{topic.name}</span>
                                        <div className="flex items-center gap-2 flex-shrink-0">
                                            <button onClick={() => setCurrentView('coding')} className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                View
                                            </button>
                                            <button onClick={() => handleUnsaveClick('coding', topic.id)} className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-lg glass-button">
                                                <TrashIcon className="w-4 h-4"/>
                                                Remove
                                            </button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500 dark:text-gray-400 py-4">You haven't saved any coding topics yet. Visit the Coding Hub to add some!</p>
                        )}
                    </div>
                </div>
            </section>
            <ConfirmationModal
                isOpen={isRemovePictureModalOpen}
                onClose={() => setIsRemovePictureModalOpen(false)}
                onConfirm={handleConfirmRemovePicture}
                title="Confirm Picture Removal"
                message="Are you sure you want to remove your profile picture?"
                confirmButtonText="Remove"
                confirmButtonClass="bg-red-600 text-white hover:bg-red-700"
            />
             <ConfirmationModal
                isOpen={isUnsaveConfirmModalOpen}
                onClose={() => setIsUnsaveConfirmModalOpen(false)}
                onConfirm={handleConfirmUnsave}
                title="Confirm Removal"
                message="Are you sure you want to remove this item from your saved list?"
                confirmButtonText="Remove"
                confirmButtonClass="bg-red-600 text-white hover:bg-red-700"
            />
        </div>
    );
};