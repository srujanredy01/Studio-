
import React, { useState, useEffect, useMemo } from 'react';
import type { ResourceFile, Year, User, FileType, Subject } from '../types';
import { SpinnerIcon, CheckIcon } from './icons/ProfileIcons';
import { XIcon, ShareIcon } from './icons/ShareIcons';
import { BookmarkIcon } from './icons/ActionIcons';
import { ShareModal } from './ShareModal';
import { trackEvent } from '../analytics';
import { PdfFileIcon, PresentationFileIcon, DocumentFileIcon, SpreadsheetFileIcon } from './FileIcons';
import { getSavedResourceIdsForUser, saveResourceIdsForUser } from '../data/userData';
import { useAppContext } from '../context/DataContext';

const yearButtons: Year[] = ['1st year', '2nd year', '3rd year', '4th year'];
const semesterOptions: ('All' | 1 | 2)[] = ['All', 1, 2];
const fileTypeOptions: ('All' | FileType)[] = ['All', 'pdf', 'presentation', 'document', 'spreadsheet'];

const fileTypeLabels: Record<FileType | 'All', string> = {
    All: 'All Files',
    pdf: 'PDFs',
    presentation: 'Presentations',
    document: 'Documents',
    spreadsheet: 'Spreadsheets',
};

const getFileTypeIcon = (type: FileType | 'All') => {
    const props = { className: "w-4 h-4" };
    switch (type) {
        case 'pdf': return <PdfFileIcon {...props} />;
        case 'presentation': return <PresentationFileIcon {...props} />;
        case 'document': return <DocumentFileIcon {...props} />;
        case 'spreadsheet': return <SpreadsheetFileIcon {...props} />;
        default: return null;
    }
};

const DownloadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24" stroke="currentColor" strokeWidth={2} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

const getFileIcon = (type: ResourceFile['type']) => {
    switch (type) {
        case 'pdf': return <PdfFileIcon className="w-6 h-6 text-red-500" />;
        case 'presentation': return <PresentationFileIcon className="w-6 h-6 text-orange-500" />;
        case 'document': return <DocumentFileIcon className="w-6 h-6 text-blue-500" />;
        case 'spreadsheet': return <SpreadsheetFileIcon className="w-6 h-6 text-green-500" />;
        default: return <DocumentFileIcon className="w-6 h-6 text-gray-500" />;
    }
};

interface ResourcesProps {
    setCurrentView: (view: 'home' | 'resources' | 'coding' | 'news' | 'saved' | 'about' | 'admin' | 'profile') => void;
}

export const Resources: React.FC<ResourcesProps> = ({ setCurrentView }) => {
    const { resources, user } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedYear, setSelectedYear] = useState<Year | null>(null);
    const [selectedSemester, setSelectedSemester] = useState<'All' | 1 | 2>('All');
    const [selectedSubject, setSelectedSubject] = useState<'All' | string>('All');
    const [selectedFileType, setSelectedFileType] = useState<'All' | FileType>('All');
    const [downloadStatuses, setDownloadStatuses] = useState<Record<number, 'idle' | 'loading' | 'success' | string>>({});
    const [savedResourceIds, setSavedResourceIds] = useState<number[]>(() => getSavedResourceIdsForUser(user.idNumber));
    const [shareModalResource, setShareModalResource] = useState<ResourceFile | null>(null);

    useEffect(() => {
        if (user?.year && !selectedYear) {
            setSelectedYear(user.year);
        }
    }, [user, selectedYear]);
    
    // Resync saved state when user changes
    useEffect(() => {
        setSavedResourceIds(getSavedResourceIdsForUser(user.idNumber));
    }, [user.idNumber]);

    const toggleSaveResource = (id: number) => {
        if (user.name === 'Guest' || !user.idNumber) {
            setCurrentView('profile');
            return;
        }

        const currentSaved = getSavedResourceIdsForUser(user.idNumber);
        const isSaving = !currentSaved.includes(id);
        let updatedSaved;
        if (isSaving) {
            updatedSaved = [...currentSaved, id];
        } else {
            updatedSaved = currentSaved.filter(savedId => savedId !== id);
        }
        saveResourceIdsForUser(user.idNumber, updatedSaved);
        setSavedResourceIds(updatedSaved);
        const resource = resources.find(r => r.id === id);
        trackEvent('featureUse', isSaving ? 'save_resource' : 'unsave_resource', { resourceId: id, resourceName: resource?.name });
    };

    const handleDownloadClick = async (file: ResourceFile) => {
        if (user.name === 'Guest') {
            setCurrentView('profile');
            return;
        }

        setDownloadStatuses(prev => ({ ...prev, [file.id]: 'loading' }));
        trackEvent('featureUse', 'download_resource', { resourceId: file.id, resourceName: file.name });

        const showError = (message: string) => {
            setDownloadStatuses(prev => ({ ...prev, [file.id]: message }));
            setTimeout(() => setDownloadStatuses(prev => ({ ...prev, [file.id]: 'idle' })), 3000);
        };

        try {
            new URL(file.link);
        } catch (_) {
            showError('Invalid link format.');
            return;
        }

        try {
            await fetch(file.link, { mode: 'no-cors' });
            
            window.open(file.link, '_blank', 'noopener,noreferrer');
            setDownloadStatuses(prev => ({ ...prev, [file.id]: 'success' }));
            setTimeout(() => setDownloadStatuses(prev => ({ ...prev, [file.id]: 'idle' })), 2000);

        } catch (error) {
            console.error('Failed to initiate download:', error);
            showError('Resource not found or network error.');
        }
    };


    // Progressive filtering logic
    const searchedResources = useMemo(() =>
        resources.filter(file =>
            file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            file.subjectName.toLowerCase().includes(searchTerm.toLowerCase())
        ), [resources, searchTerm]);

    const yearCounts = useMemo(() =>
        yearButtons.reduce((acc, year) => {
            acc[year] = searchedResources.filter(file => file.year === year).length;
            return acc;
        }, {} as Record<Year, number>), [searchedResources]);

    const resourcesForSelectedYear = useMemo(() =>
        selectedYear
            ? searchedResources.filter(file => file.year === selectedYear)
            : [],
    [searchedResources, selectedYear]);

    const semesterCounts = useMemo(() => ({
        All: resourcesForSelectedYear.length,
        1: resourcesForSelectedYear.filter(file => file.semester === 1).length,
        2: resourcesForSelectedYear.filter(file => file.semester === 2).length,
    }), [resourcesForSelectedYear]);
    
    const resourcesAfterSemesterFilter = useMemo(() => {
        if (selectedSemester === 'All') return resourcesForSelectedYear;
        return resourcesForSelectedYear.filter(file => file.semester === selectedSemester);
    }, [resourcesForSelectedYear, selectedSemester]);

    const availableSubjects = useMemo(() => {
        const subjectNames = [...new Set(resourcesAfterSemesterFilter.map(file => file.subjectName))];
        // FIX: Explicitly type sort parameters to resolve 'unknown' type error.
        return subjectNames.sort((a: string, b: string) => a.localeCompare(b));
    }, [resourcesAfterSemesterFilter]);

    const subjectCounts = useMemo(() => {
        return availableSubjects.reduce((acc, subjectName) => {
            acc[subjectName] = resourcesAfterSemesterFilter.filter(file => file.subjectName === subjectName).length;
            return acc;
        }, {} as Record<string, number>);
    }, [availableSubjects, resourcesAfterSemesterFilter]);

    const resourcesAfterSubjectFilter = useMemo(() => {
        if (selectedSubject === 'All') return resourcesAfterSemesterFilter;
        return resourcesAfterSemesterFilter.filter(file => file.subjectName === selectedSubject);
    }, [resourcesAfterSemesterFilter, selectedSubject]);

    const fileTypeCounts = useMemo(() => {
        return fileTypeOptions.reduce((acc, type) => {
            if (type === 'All') {
                acc[type] = resourcesAfterSubjectFilter.length;
            } else {
                acc[type] = resourcesAfterSubjectFilter.filter(file => file.type === type).length;
            }
            return acc;
        }, {} as Record<'All' | FileType, number>);
    }, [resourcesAfterSubjectFilter]);

    const finalFilteredResources = useMemo(() => {
        if (selectedFileType === 'All') {
            return resourcesAfterSubjectFilter;
        }
        return resourcesAfterSubjectFilter.filter(file => file.type === selectedFileType);
    }, [resourcesAfterSubjectFilter, selectedFileType]);
    
    const groupedBySubject = useMemo(() => {
        return finalFilteredResources.reduce((acc, file) => {
            const subject = file.subjectName;
            if (!acc[subject]) {
                acc[subject] = [];
            }
            acc[subject].push(file);
            return acc;
        }, {} as Record<string, ResourceFile[]>);
    }, [finalFilteredResources]);

    const renderFileItem = (file: ResourceFile) => {
        const isRecommended = user.year && user.interests && user.interests.length > 0 &&
            file.year === user.year &&
            user.interests.some(interest => file.name.toLowerCase().includes(interest.split('/')[0].toLowerCase().trim()));
            
        const status = downloadStatuses[file.id] || 'idle';
        const isError = status !== 'idle' && status !== 'loading' && status !== 'success';
        const isSaved = savedResourceIds.includes(file.id);
        
        return (
            <div key={file.id} className="glass-effect aurora-effect p-4 rounded-lg flex flex-wrap justify-between items-center gap-4 transition-transform duration-300 hover:-translate-y-1">
                <div className="flex items-center gap-4 flex-grow min-w-0">
                    {getFileIcon(file.type)}
                    <div className="flex-grow min-w-0">
                        <span className="font-medium text-gray-700 dark:text-gray-200 block truncate" title={file.name}>{file.name}</span>
                        {isRecommended && (
                            <span className="text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 px-2.5 py-0.5 rounded-full whitespace-nowrap inline-block mt-1">Recommended</span>
                        )}
                    </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                     <button 
                        onClick={() => handleDownloadClick(file)}
                        disabled={status !== 'idle'}
                        className={`inline-flex items-center justify-center font-semibold py-2 px-4 rounded-full shadow-md transition-all duration-300 min-w-[150px] text-sm text-white ${
                            status === 'loading' ? 'bg-gray-500 dark:bg-gray-600 cursor-not-allowed' :
                            status === 'success' ? 'bg-green-600 cursor-not-allowed' :
                            isError ? 'bg-red-600 cursor-not-allowed' :
                            'bg-purple-600 hover:bg-purple-700'
                        }`}
                    >
                        {status === 'loading' && <><SpinnerIcon className="w-5 h-5 mr-2" />Downloading...</>}
                        {status === 'success' && <><CheckIcon className="w-5 h-5 mr-2" />Complete</>}
                        {isError && <>{status}</>}
                        {status === 'idle' && <><DownloadIcon className="w-4 h-4 mr-1.5" />Download</>}
                    </button>
                     <button 
                        onClick={() => toggleSaveResource(file.id)}
                        className={`group flex items-center gap-1.5 px-3 py-2 text-sm rounded-full font-semibold transition-colors ${
                            isSaved 
                                ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300' 
                                : 'bg-black/5 text-gray-700 hover:bg-black/10 dark:bg-white/5 dark:text-gray-200 dark:hover:bg-white/10'
                        }`}
                        aria-label={isSaved ? 'Remove from saved' : 'Save for later'}
                    >
                        <BookmarkIcon className="w-4 h-4 transition-transform duration-200 group-active:scale-125" filled={isSaved} />
                        {isSaved ? 'Saved' : 'Save'}
                    </button>
                     <button
                        onClick={() => setShareModalResource(file)}
                        className="p-2 rounded-full text-gray-500 hover:bg-black/10 hover:text-gray-800 dark:text-gray-400 dark:hover:bg-white/10 dark:hover:text-white transition-colors"
                        aria-label="Share resource"
                    >
                        <ShareIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="min-h-[calc(100vh-280px)]">
            <section className="py-16">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h1 className="text-5xl font-bold text-gray-800 dark:text-white">Resources</h1>
                    <div className="mt-8 max-w-2xl mx-auto">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                                </svg>
                            </div>
                            <input
                                type="text"
                                placeholder="Search resources by keyword or subject..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="block w-full glass-effect rounded-full py-3 pl-12 pr-4 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            />
                        </div>
                    </div>
                </div>
            </section>
            <section className="py-20 bg-black/5 dark:bg-white/5">
                <div className="container mx-auto px-6 lg:px-8 text-center">
                    <h2 className="text-4xl font-bold text-gray-800 dark:text-white">Select Your Year</h2>
                    <p className="mt-4 max-w-xl mx-auto text-gray-600 dark:text-gray-300">
                        Click a button to view and download all available files for the selected academic year.
                    </p>
                    <div className="mt-12 flex flex-wrap justify-center gap-4">
                        {yearButtons.map(year => (
                            <button 
                                key={year}
                                onClick={() => {
                                    setSelectedYear(year);
                                    setSelectedSemester('All');
                                    setSelectedSubject('All');
                                    setSelectedFileType('All');
                                }}
                                className={`font-semibold py-2 px-6 rounded-full transition-all duration-300 flex items-center gap-2 glass-button aurora-effect ${
                                    selectedYear === year 
                                        ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 border-transparent'
                                        : 'hover:bg-gray-800 dark:hover:bg-gray-200 hover:text-white dark:hover:text-gray-900'
                                }`}
                            >
                                {year}
                                <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${selectedYear === year ? 'bg-white/20 dark:bg-black/20' : 'bg-gray-200 dark:bg-gray-700'}`}>
                                    {yearCounts[year]}
                                </span>
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            {selectedYear && (
                 <section className="py-20">
                    <div className="container mx-auto px-6 lg:px-8">
                        <h3 className="text-3xl font-bold text-gray-800 dark:text-white text-center">{selectedYear} Resources</h3>
                        
                        <div className="mt-8 mb-12 flex flex-col items-center gap-4">
                            {/* Filter bar */}
                            <div className="flex flex-wrap items-center justify-center gap-3 glass-effect p-2 rounded-full">
                                {/* Semester Filter */}
                                {semesterOptions.map(sem => (
                                    <button
                                        key={sem}
                                        onClick={() => {
                                            setSelectedSemester(sem);
                                            setSelectedSubject('All');
                                            setSelectedFileType('All');
                                        }}
                                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 flex items-center gap-2 ${
                                            selectedSemester === sem
                                                ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 shadow-md'
                                                : 'hover:bg-black/5 dark:hover:bg-white/5'
                                        }`}
                                    >
                                        {sem === 'All' ? 'All Semesters' : `Semester ${sem}`}
                                        <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${selectedSemester === sem ? 'bg-white/20 dark:bg-black/20' : 'bg-gray-300 dark:bg-gray-600'}`}>
                                            {semesterCounts[sem]}
                                        </span>
                                    </button>
                                ))}
                                
                                <div className="w-px h-6 bg-black/10 dark:bg-white/10 mx-1"></div>

                                {/* Subject Filter */}
                                {availableSubjects.length > 0 && (
                                    <select
                                        value={selectedSubject}
                                        onChange={(e) => {
                                            setSelectedSubject(e.target.value);
                                            setSelectedFileType('All');
                                        }}
                                        className="bg-transparent text-sm font-semibold rounded-full transition-colors duration-200 flex items-center gap-2 focus:outline-none appearance-none cursor-pointer py-2 px-4 hover:bg-black/5 dark:hover:bg-white/5"
                                    >
                                        <option value="All" className="font-semibold">All Subjects ({resourcesAfterSemesterFilter.length})</option>
                                        {availableSubjects.map(subject => (
                                            <option key={subject} value={subject} className="font-semibold">
                                                {subject} ({subjectCounts[subject]})
                                            </option>
                                        ))}
                                    </select>
                                )}
                                
                                <div className="w-px h-6 bg-black/10 dark:bg-white/10 mx-1"></div>

                                {/* File Type Filter */}
                                {fileTypeOptions.map(type => (
                                    <button
                                        key={type}
                                        onClick={() => setSelectedFileType(type)}
                                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 flex items-center gap-2 ${
                                            selectedFileType === type
                                                ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900 shadow-md'
                                                : 'hover:bg-black/5 dark:hover:bg-white/5'
                                        }`}
                                    >
                                        {getFileTypeIcon(type)}
                                        {fileTypeLabels[type]}
                                        <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${selectedFileType === type ? 'bg-white/20 dark:bg-black/20' : 'bg-gray-300 dark:bg-gray-600'}`}>
                                            {fileTypeCounts[type]}
                                        </span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="max-w-4xl mx-auto min-h-[200px]">
                             {resourcesForSelectedYear.length > 0 ? (
                                <div className="space-y-12">
                                    {Object.keys(groupedBySubject).length > 0 ? (
                                        // FIX: Explicitly type map parameters to resolve 'unknown' type error on 'files'.
                                        Object.entries(groupedBySubject).map(([subjectName, files]: [string, ResourceFile[]]) => (
                                            <div key={subjectName}>
                                                <h4 className="text-2xl font-semibold text-gray-700 dark:text-gray-200 mb-4 border-b-2 border-purple-600/50 pb-2">{subjectName}</h4>
                                                <div className="space-y-4">{files.map(renderFileItem)}</div>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="text-center text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center h-full pt-8">
                                            <h4 className="text-xl font-semibold">No Files Found</h4>
                                            <p>No documents match your current filters for {selectedYear}.</p>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <div className="text-center text-gray-500 dark:text-gray-400 flex flex-col justify-center items-center h-full pt-8">
                                    <h4 className="text-xl font-semibold">No Files Found</h4>
                                    <p>Your search for "{searchTerm}" did not match any documents for {selectedYear}.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </section>
            )}

             <div className="container mx-auto px-6 lg:px-8">
                <div className="border-b border-gray-200 dark:border-gray-700 mt-20"></div>
            </div>

            {shareModalResource && (
                <ShareModal 
                    item={shareModalResource}
                    onClose={() => setShareModalResource(null)}
                />
            )}
        </div>
    );
};