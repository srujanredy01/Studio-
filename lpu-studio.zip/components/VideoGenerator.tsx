
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ApiKeySelector } from './ApiKeySelector';
import { SettingsPanel } from './SettingsPanel';
import { GenerationDisplay } from './GenerationDisplay';
import type { AspectRatio } from '../types';
import { trackEvent } from '../analytics';

const loadingMessages = [
    "Warming up the digital canvas...",
    "Teaching pixels to dance...",
    "Assembling cinematic sequences...",
    "Rendering your vision into reality...",
    "This can take a few minutes, hang tight!",
    "Polishing the final frames...",
];

export const VideoGenerator: React.FC = () => {
    const [hasKey, setHasKey] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const loadingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const videoUrlRef = useRef<string | null>(null);

    const checkApiKey = async () => {
        const keyStatus = await window.aistudio.hasSelectedApiKey();
        setHasKey(keyStatus);
    };

    useEffect(() => {
        checkApiKey();
        
        return () => {
            // Cleanup object URL on component unmount
            if (videoUrlRef.current) {
                URL.revokeObjectURL(videoUrlRef.current);
            }
        };
    }, []);
    
    useEffect(() => {
        if (isLoading) {
            loadingIntervalRef.current = setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    const nextIndex = (currentIndex + 1) % loadingMessages.length;
                    return loadingMessages[nextIndex];
                });
            }, 3000);
        } else {
            if (loadingIntervalRef.current) {
                clearInterval(loadingIntervalRef.current);
            }
        }
        return () => {
            if (loadingIntervalRef.current) {
                clearInterval(loadingIntervalRef.current);
            }
        };
    }, [isLoading]);

    const handleSelectKey = async () => {
        await window.aistudio.openSelectKey();
        // Assume success and update UI immediately to avoid race conditions
        setHasKey(true);
        setError(null);
    };

    const handleGenerate = async () => {
        if (!prompt.trim() || isLoading) return;
        
        setIsLoading(true);
        setError(null);
        if (videoUrlRef.current) {
            URL.revokeObjectURL(videoUrlRef.current);
            videoUrlRef.current = null;
        }
        setVideoUrl(null);
        setLoadingMessage(loadingMessages[0]);
        trackEvent('featureUse', 'generate_video', { promptLength: prompt.length, aspectRatio });

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: prompt,
                config: {
                    numberOfVideos: 1,
                    resolution: '720p',
                    aspectRatio: aspectRatio
                }
            });

            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

            if (!downloadLink) {
                throw new Error("Video generation completed, but no download link was provided.");
            }

            const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
            if (!videoResponse.ok) {
                throw new Error(`Failed to download the video. Status: ${videoResponse.status}`);
            }

            const videoBlob = await videoResponse.blob();
            const url = URL.createObjectURL(videoBlob);
            videoUrlRef.current = url;
            setVideoUrl(url);

        } catch (e: any) {
            console.error("Video Generation Error:", e);
            const errorMessage = e.message || "An unknown error occurred.";
            
            if (errorMessage.includes("Requested entity was not found.")) {
                setError("Your API key is invalid or has expired. Please select a new one.");
                setHasKey(false);
            } else {
                setError(`Video generation failed: ${errorMessage}`);
            }
        } finally {
            setIsLoading(false);
        }
    };

    if (!hasKey) {
        return <ApiKeySelector onSelectKey={handleSelectKey} error={error} />;
    }

    return (
        <div className="bg-black min-h-screen text-white p-4 sm:p-6 lg:p-8">
            <div className="container mx-auto">
                <header className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold mb-2">Video Hub</h1>
                    <p className="text-lg text-gray-400">Bring your ideas to life with AI-powered video generation.</p>
                </header>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <SettingsPanel
                        prompt={prompt}
                        setPrompt={setPrompt}
                        aspectRatio={aspectRatio}
                        setAspectRatio={setAspectRatio}
                        isLoading={isLoading}
                        onGenerate={handleGenerate}
                    />
                    <GenerationDisplay
                        isLoading={isLoading}
                        loadingMessage={loadingMessage}
                        videoUrl={videoUrl}
                        error={error}
                    />
                </div>
            </div>
        </div>
    );
};
