
import type { NewsArticle, CodingTopic, TeamMember, Subject, FileType, SubjectFile } from '../types';

// Initial data for news articles
export const initialNewsArticles: NewsArticle[] = [
    {
        id: 1,
        title: 'LPU Announces New AI & Machine Learning Course',
        date: new Date(new Date().setDate(new Date().getDate() - 45)).toISOString().split('T')[0], // ~1.5 months ago
        excerpt: 'In a major curriculum update, LPU has introduced a new specialized course focusing on Artificial Intelligence and Machine Learning, available to students starting next semester.',
    },
    {
        id: 2,
        title: 'Annual Tech Fest "Spectra" Dates Revealed',
        date: new Date(new Date().setDate(new Date().getDate() - 2)).toISOString().split('T')[0], // 2 days ago
        excerpt: 'The much-awaited annual tech fest, Spectra, is scheduled for next month. The event promises a lineup of coding competitions, workshops, and guest lectures from industry leaders.',
    },
    {
        id: 3,
        title: 'Campus Placement Drive Sees Record-Breaking Offers',
        date: new Date(new Date().setDate(new Date().getDate() - 10)).toISOString().split('T')[0], // 10 days ago
        excerpt: 'This year\'s placement drive concluded with a record number of students receiving offers from top multinational companies, with the highest package reaching an all-time high.',
    },
    {
        id: 4,
        title: 'New Student Hostel Facilities to Open',
        date: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0], // 1 month ago
        excerpt: 'To accommodate the growing number of students, a new state-of-the-art hostel complex will be inaugurated next month, featuring modern amenities and study areas.',
    },
    {
        id: 5,
        title: 'Sports Meet Concludes with CSE as Champions',
        date: new Date(new Date().setDate(new Date().getDate() - 4)).toISOString().split('T')[0], // 4 days ago
        excerpt: 'The inter-departmental sports meet concluded this week with the CSE department taking home the championship trophy after a thrilling final.',
    },
    {
        id: 6,
        title: 'Highlights from Last Year\'s Convocation',
        date: new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toISOString().split('T')[0], // 1 year ago
        excerpt: 'A look back at the memorable moments from last year\'s convocation ceremony as we prepare for the upcoming graduation.',
    },
    {
        id: 7,
        title: 'Library Announces Extended Hours for Final Exams',
        date: new Date().toISOString().split('T')[0], // Today
        excerpt: 'To support students during the upcoming final examination period, the central library will be open 24/7 for the next two weeks.',
    },
    {
        id: 8,
        title: 'Guest Lecture on Quantum Computing by Dr. Arin Zadeh',
        date: new Date(new Date().setDate(new Date().getDate() - 6)).toISOString().split('T')[0], // 6 days ago
        excerpt: 'The Department of Computer Science hosted a guest lecture on the future of quantum computing. A recording is now available on the university portal.',
    },
    {
        id: 9,
        title: 'Results for Mid-Term Examinations Declared',
        date: new Date(new Date().setDate(new Date().getDate() - 25)).toISOString().split('T')[0], // 25 days ago
        excerpt: 'The results for the recent mid-term examinations have been published on the university portal. Students can log in to view their grades.',
    },
    {
        id: 10,
        title: 'LPU Team Wins National Robotics Competition',
        date: new Date(new Date().setMonth(new Date().getMonth() - 2)).toISOString().split('T')[0], // 2 months ago
        excerpt: 'A team of engineering students from LPU has secured the first position in the National Robotics Challenge, showcasing their innovative autonomous robot design.',
    },
    {
        id: 11,
        title: 'Call for Papers: International Conference on Sustainable Energy',
        date: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().split('T')[0], // Yesterday
        excerpt: 'The university is inviting research paper submissions for its upcoming international conference on sustainable energy solutions. The deadline for submission is next month.',
    },
    {
        id: 12,
        title: 'New Cafeteria Opens in Block 32',
        date: new Date(new Date().setMonth(new Date().getMonth() - 3)).toISOString().split('T')[0], // 3 months ago
        excerpt: 'A new cafeteria has opened near Block 32, offering a wide range of international cuisines, healthy options, and late-night snacks for students.',
    }
];

const generateFiles = (subjectId: number, subjectName: string): SubjectFile[] => {
    const fileTypes: FileType[] = ['pdf', 'presentation', 'document', 'spreadsheet'];
    const files: SubjectFile[] = [];
    const count = 5 + Math.floor(Math.random() * 3); // Reduced from ~25 to ~6 to avoid localStorage quota issues
    for (let i = 1; i <= count; i++) {
        const type = fileTypes[i % 4];
        let name = '';
        switch(type) {
            case 'pdf': name = `${subjectName} - Notes ${Math.ceil(i/4)}`; break;
            case 'presentation': name = `${subjectName} - Lecture ${Math.ceil(i/4)} Slides`; break;
            case 'document': name = `${subjectName} - Assignment ${Math.ceil(i/4)}`; break;
            case 'spreadsheet': name = `${subjectName} - Lab Data ${Math.ceil(i/4)}`; break;
        }
        files.push({
            id: subjectId * 1000 + i,
            name: name,
            link: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', // dummy link
            type: type
        });
    }
    return files;
};

// Initial data for academic subjects with expanded files
export const initialSubjects: Subject[] = [
    // 1st Year, Sem 1
    { id: 101, name: 'Mathematics-I', year: '1st year', semester: 1, files: generateFiles(101, 'Mathematics-I') },
    { id: 102, name: 'Physics', year: '1st year', semester: 1, files: generateFiles(102, 'Physics') },
    { id: 103, name: 'Basic Electrical Engineering', year: '1st year', semester: 1, files: generateFiles(103, 'BEE') },
    { id: 104, name: 'Intro to Computer Science', year: '1st year', semester: 1, files: generateFiles(104, 'Intro to CS') },
    { id: 105, name: 'Environmental Science', year: '1st year', semester: 1, files: generateFiles(105, 'EVS') },
    { id: 106, name: 'Engineering Graphics', year: '1st year', semester: 1, files: generateFiles(106, 'Engg. Graphics') },
    { id: 107, name: 'Chemistry', year: '1st year', semester: 1, files: generateFiles(107, 'Chemistry') },
    { id: 108, name: 'Workshop Practice', year: '1st year', semester: 1, files: generateFiles(108, 'Workshop') },

    // 1st Year, Sem 2
    { id: 109, name: 'Mathematics-II', year: '1st year', semester: 2, files: generateFiles(109, 'Mathematics-II') },
    { id: 110, name: 'Communication Skills', year: '1st year', semester: 2, files: generateFiles(110, 'Comm Skills') },
    { id: 111, name: 'Programming in C', year: '1st year', semester: 2, files: generateFiles(111, 'Programming in C') },
    { id: 112, name: 'Digital Electronics', year: '1st year', semester: 2, files: generateFiles(112, 'Digital Electronics') },
    { id: 113, name: 'Mechanics', year: '1st year', semester: 2, files: generateFiles(113, 'Mechanics') },
    { id: 114, name: 'Economics for Engineers', year: '1st year', semester: 2, files: generateFiles(114, 'Economics') },
    { id: 115, name: 'Biology for Engineers', year: '1st year', semester: 2, files: generateFiles(115, 'Biology') },
    { id: 116, name: 'Ethics and Values', year: '1st year', semester: 2, files: generateFiles(116, 'Ethics') },

    // 2nd Year, Sem 1
    { id: 201, name: 'Data Structures & Algorithms', year: '2nd year', semester: 1, files: generateFiles(201, 'DSA') },
    { id: 202, name: 'Object-Oriented Programming', year: '2nd year', semester: 1, files: generateFiles(202, 'OOP') },
    { id: 203, name: 'Discrete Mathematics', year: '2nd year', semester: 1, files: generateFiles(203, 'Discrete Maths') },
    { id: 204, name: 'Computer Organization', year: '2nd year', semester: 1, files: generateFiles(204, 'COA') },
    { id: 205, name: 'Signals and Systems', year: '2nd year', semester: 1, files: generateFiles(205, 'Signals & Systems') },
    { id: 206, name: 'Probability and Statistics', year: '2nd year', semester: 1, files: generateFiles(206, 'Probability') },
    { id: 207, name: 'Management for Engineers', year: '2nd year', semester: 1, files: generateFiles(207, 'Management') },
    { id: 208, name: 'Automata Theory', year: '2nd year', semester: 1, files: generateFiles(208, 'Automata') },

    // 2nd Year, Sem 2
    { id: 209, name: 'Database Management Systems', year: '2nd year', semester: 2, files: generateFiles(209, 'DBMS') },
    { id: 210, name: 'Computer Networks', year: '2nd year', semester: 2, files: generateFiles(210, 'CN') },
    { id: 211, name: 'Design and Analysis of Algorithms', year: '2nd year', semester: 2, files: generateFiles(211, 'DAA') },
    { id: 212, name: 'Microprocessors', year: '2nd year', semester: 2, files: generateFiles(212, 'Microprocessors') },
    { id: 213, name: 'Web Development', year: '2nd year', semester: 2, files: generateFiles(213, 'Web Dev') },
    { id: 214, name: 'Linear Algebra', year: '2nd year', semester: 2, files: generateFiles(214, 'Linear Algebra') },
    { id: 215, name: 'Financial Management', year: '2nd year', semester: 2, files: generateFiles(215, 'Finance') },
    { id: 216, name: 'Numerical Methods', year: '2nd year', semester: 2, files: generateFiles(216, 'Numerical Methods') },
    
    // 3rd Year, Sem 1
    { id: 301, name: 'Operating Systems', year: '3rd year', semester: 1, files: generateFiles(301, 'OS') },
    { id: 302, name: 'Software Engineering', year: '3rd year', semester: 1, files: generateFiles(302, 'SE') },
    { id: 303, name: 'Computer Graphics', year: '3rd year', semester: 1, files: generateFiles(303, 'CG') },
    { id: 304, name: 'Cryptography', year: '3rd year', semester: 1, files: generateFiles(304, 'Cryptography') },
    { id: 305, name: 'Compiler Design', year: '3rd year', semester: 1, files: generateFiles(305, 'Compiler') },
    { id: 306, name: 'AI & Machine Learning', year: '3rd year', semester: 1, files: generateFiles(306, 'AI/ML') },
    { id: 307, name: 'Mobile App Development', year: '3rd year', semester: 1, files: generateFiles(307, 'App Dev') },
    { id: 308, name: 'Data Mining', year: '3rd year', semester: 1, files: generateFiles(308, 'Data Mining') },
    
    // 3rd Year, Sem 2
    { id: 309, name: 'Distributed Systems', year: '3rd year', semester: 2, files: generateFiles(309, 'Distributed Sys') },
    { id: 310, name: 'Cloud Computing', year: '3rd year', semester: 2, files: generateFiles(310, 'Cloud') },
    { id: 311, name: 'Information Security', year: '3rd year', semester: 2, files: generateFiles(311, 'InfoSec') },
    { id: 312, name: 'Natural Language Processing', year: '3rd year', semester: 2, files: generateFiles(312, 'NLP') },
    { id: 313, name: 'Big Data Analytics', year: '3rd year', semester: 2, files: generateFiles(313, 'Big Data') },
    { id: 314, name: 'Internet of Things', year: '3rd year', semester: 2, files: generateFiles(314, 'IoT') },
    { id: 315, name: 'Digital Image Processing', year: '3rd year', semester: 2, files: generateFiles(315, 'DIP') },
    { id: 316, name: 'Project Management', year: '3rd year', semester: 2, files: generateFiles(316, 'PM') },

    // 4th Year, Sem 1
    { id: 401, name: 'Deep Learning', year: '4th year', semester: 1, files: generateFiles(401, 'Deep Learning') },
    { id: 402, name: 'Cyber Security', year: '4th year', semester: 1, files: generateFiles(402, 'CyberSec') },
    { id: 403, name: 'Quantum Computing', year: '4th year', semester: 1, files: generateFiles(403, 'Quantum') },
    { id: 404, name: 'Blockchain Technology', year: '4th year', semester: 1, files: generateFiles(404, 'Blockchain') },
    { id: 405, name: 'Reinforcement Learning', year: '4th year', semester: 1, files: generateFiles(405, 'RL') },
    { id: 406, name: 'Software Testing', year: '4th year', semester: 1, files: generateFiles(406, 'Testing') },
    { id: 407, name: 'DevOps', year: '4th year', semester: 1, files: generateFiles(407, 'DevOps') },
    { id: 408, name: 'Human-Computer Interaction', year: '4th year', semester: 1, files: generateFiles(408, 'HCI') },

    // 4th Year, Sem 2
    { id: 409, name: 'Final Year Project', year: '4th year', semester: 2, files: generateFiles(409, 'FYP') },
    { id: 410, name: 'Professional Practice', year: '4th year', semester: 2, files: generateFiles(410, 'Professional Practice') },
    { id: 411, name: 'Entrepreneurship', year: '4th year', semester: 2, files: generateFiles(411, 'Entrepreneurship') },
    { id: 412, name: 'Robotics', year: '4th year', semester: 2, files: generateFiles(412, 'Robotics') },
    { id: 413, name: 'Computer Vision', year: '4th year', semester: 2, files: generateFiles(413, 'Computer Vision') },
    { id: 414, name: 'AR/VR', year: '4th year', semester: 2, files: generateFiles(414, 'AR/VR') },
    { id: 415, name: 'System Design', year: '4th year', semester: 2, files: generateFiles(415, 'System Design') },
    { id: 416, name: 'Technical Writing', year: '4th year', semester: 2, files: generateFiles(416, 'Tech Writing') },
];


// Initial data for coding topics
export const initialCodingTopics: CodingTopic[] = [
    { id: 'dsa', name: 'DSA', description: 'Master Data Structures and Algorithms, the foundation of efficient software.', category: 'concept', difficulty: 'Intermediate' },
    { id: 'c', name: 'C', description: 'The foundational language for system programming and embedded systems.', category: 'language', difficulty: 'Beginner' },
    { id: 'cpp', name: 'C++', description: 'A powerful language for system programming and game development.', category: 'language', difficulty: 'Intermediate' },
    { id: 'java', name: 'Java', description: 'A robust, object-oriented language for enterprise-scale applications.', category: 'language', difficulty: 'Intermediate' },
    { id: 'python', name: 'Python', description: 'A versatile language known for its readability and extensive libraries.', category: 'language', difficulty: 'Beginner' },
    { id: 'javascript', name: 'JavaScript', description: 'The language of the web, essential for interactive front-end development.', category: 'language', difficulty: 'Beginner' },
    { id: 'html', name: 'HTML', description: 'The standard markup language for creating web pages and web applications.', category: 'language', difficulty: 'Beginner' },
    { id: 'css', name: 'CSS', description: 'A style sheet language used for describing the presentation of a web page.', category: 'language', difficulty: 'Beginner' },
    { id: 'sql', name: 'SQL', description: 'Master the standard language for managing and querying relational databases.', category: 'language', difficulty: 'Beginner' },
    { id: 'datascience', name: 'Data Science', description: 'Explore techniques for data analysis, visualization, and interpretation.', category: 'concept', difficulty: 'Advanced' },
    { id: 'machinelearning', name: 'Machine Learning', description: 'Dive into algorithms that allow computers to learn from data.', category: 'concept', difficulty: 'Advanced' },
    { id: 'webdev', name: 'Web Development', description: 'Explore solutions for HTML, CSS, React, and other web technologies.', category: 'concept', difficulty: 'Intermediate' },
    { id: 'systemdesign', name: 'System Design', description: 'Learn how to design scalable and reliable software architectures.', category: 'concept', difficulty: 'Advanced' },
    { id: 'linux', name: 'Linux', description: 'Learn the fundamentals of the powerful, open-source operating system.', category: 'concept', difficulty: 'Intermediate' },
    { id: 'devops', name: 'DevOps', description: 'Explore practices that combine software development and IT operations.', category: 'concept', difficulty: 'Advanced' },
    { id: 'aptitude', name: 'Aptitude', description: 'Sharpen your logical reasoning and quantitative skills for placements.', category: 'concept', difficulty: 'Beginner' },
    { id: 'courses', name: 'Courses', description: 'Structured learning paths and materials for various tech domains.', category: 'concept', difficulty: 'Beginner' }
];

// Initial data for team members
export const initialTeamMembers: TeamMember[] = [
    {
        id: 1,
        name: 'Alex Johnson',
        role: 'Founder & Lead Developer',
        bio: 'Alex is the visionary behind LPU Studio, driven by a passion for creating tools that simplify and enrich the student learning experience.',
        imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
    },
    {
        id: 2,
        name: 'Maria Garcia',
        role: 'Head of Content',
        bio: 'Maria curates all the educational resources and news, ensuring everything is accurate, relevant, and up-to-date for LPU students.',
        imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop',
    },
    {
        id: 3,
        name: 'Sam Lee',
        role: 'UI/UX Designer',
        bio: 'Sam is the creative mind who designed the clean and intuitive interface of LPU Studio, focusing on a seamless user experience.',
        imageUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=200&auto=format&fit=crop',
    },
];
