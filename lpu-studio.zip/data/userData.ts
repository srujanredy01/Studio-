
import type { SavedPracticeProblem } from '../types';

type UserSavedData = {
    news?: number[];
    resources?: number[];
    codingTopics?: string[];
    practiceProblems?: SavedPracticeProblem[];
}

const STORAGE_KEY = 'userSavedData';

function getAllSavedData(): Record<string, UserSavedData> {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.error("Error reading user saved data from localStorage", e);
        return {};
    }
}

function getUserSavedData(userId: string): UserSavedData {
    return getAllSavedData()[userId] || {};
}

function updateUserSavedData(userId: string, data: UserSavedData) {
    const allData = getAllSavedData();
    allData[userId] = data;
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(allData));
    } catch (e) {
        console.error("Error saving user data to localStorage", e);
    }
}

// News Articles
export const getSavedNewsIdsForUser = (userId?: string): number[] => {
    if (!userId) return [];
    return getUserSavedData(userId).news || [];
};

export const saveNewsIdsForUser = (userId: string, ids: number[]) => {
    const data = getUserSavedData(userId);
    data.news = ids;
    updateUserSavedData(userId, data);
};

// Resources
export const getSavedResourceIdsForUser = (userId?: string): number[] => {
    if (!userId) return [];
    return getUserSavedData(userId).resources || [];
};

export const saveResourceIdsForUser = (userId: string, ids: number[]) => {
    const data = getUserSavedData(userId);
    data.resources = ids;
    updateUserSavedData(userId, data);
};

// Coding Topics
export const getSavedCodingTopicIdsForUser = (userId?: string): string[] => {
    if (!userId) return [];
    return getUserSavedData(userId).codingTopics || [];
};

export const saveCodingTopicIdsForUser = (userId: string, ids: string[]) => {
    const data = getUserSavedData(userId);
    data.codingTopics = ids;
    updateUserSavedData(userId, data);
};

// Practice Problems
export const getSavedPracticeProblemsForUser = (userId?: string): SavedPracticeProblem[] => {
    if (!userId) return [];
    return getUserSavedData(userId).practiceProblems || [];
};

export const savePracticeProblemsForUser = (userId: string, problems: SavedPracticeProblem[]) => {
    const data = getUserSavedData(userId);
    data.practiceProblems = problems;
    updateUserSavedData(userId, data);
};
