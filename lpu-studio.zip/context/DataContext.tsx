import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import type { NewsArticle, CodingTopic, User, TeamMember, Subject, ResourceFile } from '../types';
import { initialNewsArticles, initialCodingTopics, initialTeamMembers, initialSubjects } from '../data/initialData';

// Custom hook for state that persists to localStorage and syncs across tabs
function usePersistentState<T>(key: string, defaultValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
    const [state, setState] = useState<T>(() => {
        try {
            const storedValue = window.localStorage.getItem(key);
            return storedValue ? JSON.parse(storedValue) : defaultValue;
        } catch (error) {
            console.error(`Error reading localStorage key "${key}":`, error);
            return defaultValue;
        }
    });

    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(`Error setting localStorage key "${key}":`, error);
        }
    }, [key, state]);

    useEffect(() => {
        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === key) {
                try {
                    if (e.newValue) {
                        setState(JSON.parse(e.newValue));
                    } else {
                        // Value was removed from localStorage
                        setState(defaultValue);
                    }
                } catch (error) {
                    console.error(`Error parsing stored value for key "${key}" on storage event:`, error);
                }
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, [key, defaultValue]);

    return [state, setState];
}


interface AppContextType {
    newsArticles: NewsArticle[];
    setNewsArticles: React.Dispatch<React.SetStateAction<NewsArticle[]>>;
    subjects: Subject[];
    setSubjects: React.Dispatch<React.SetStateAction<Subject[]>>;
    codingTopics: CodingTopic[];
    setCodingTopics: React.Dispatch<React.SetStateAction<CodingTopic[]>>;
    teamMembers: TeamMember[];
    setTeamMembers: React.Dispatch<React.SetStateAction<TeamMember[]>>;
    user: User;
    setUser: React.Dispatch<React.SetStateAction<User>>;
    allUsers: User[];
    setAllUsers: React.Dispatch<React.SetStateAction<User[]>>;
    resources: ResourceFile[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    // Centralized data state
    const [newsArticles, setNewsArticles] = usePersistentState<NewsArticle[]>('newsArticles', initialNewsArticles);
    const [subjects, setSubjects] = usePersistentState<Subject[]>('subjects', initialSubjects);
    const [codingTopics, setCodingTopics] = usePersistentState<CodingTopic[]>('codingTopics', initialCodingTopics);
    const [teamMembers, setTeamMembers] = usePersistentState<TeamMember[]>('teamMembers', initialTeamMembers);
    const [user, setUser] = usePersistentState<User>('userProfile', { name: 'Guest', year: null, idNumber: '', interests: [] });
    const [allUsers, setAllUsers] = usePersistentState<User[]>('allUsers', []);

    // Create a flattened array of ResourceFile objects with subject context.
    const resources: ResourceFile[] = useMemo(() => {
        return subjects.flatMap(subject => 
            subject.files.map(file => ({
                ...file,
                year: subject.year,
                semester: subject.semester,
                subjectName: subject.name,
            }))
        );
    }, [subjects]);
    
    const value = {
        newsArticles, setNewsArticles,
        subjects, setSubjects,
        codingTopics, setCodingTopics,
        teamMembers, setTeamMembers,
        user, setUser,
        allUsers, setAllUsers,
        resources
    };

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};
